const ArticlePage = () => {
    return (
        <h1>This is the article page!</h1>
    );
}

export default ArticlePage;