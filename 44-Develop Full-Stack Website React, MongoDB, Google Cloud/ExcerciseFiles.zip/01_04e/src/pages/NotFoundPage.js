const NotFoundPage = () => {
    return (
        <h1>This is the not found page!</h1>
    );
}

export default NotFoundPage;