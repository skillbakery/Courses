import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>My Awesome Blog</h1>
      <div id="page-body">
        Welcome to my blog!
      </div>
    </div>
  );
}

export default App;
