"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./components/nav.js":
/*!***************************!*\
  !*** ./components/nav.js ***!
  \***************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ \"./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _context_user__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../context/user */ \"./context/user.js\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_user__WEBPACK_IMPORTED_MODULE_2__]);\n_context_user__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\nconst Nav = ()=>{\n    const { user: userPromise } = (0,_context_user__WEBPACK_IMPORTED_MODULE_2__.useUser)();\n    const [user, setUser] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(null);\n    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{\n        const fetchData = async ()=>{\n            try {\n                const { data: { user } } = await userPromise;\n                console.log(\"Resolved User:\", user);\n                setUser(user); // Set the user state\n            } catch (error) {\n                console.error(\"Error fetching data:\", error.message);\n            }\n        };\n        fetchData();\n    }, [\n        userPromise\n    ]);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"nav\", {\n        className: \"flex py-4 px-6 border-b border-gray-200\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                href: \"/\",\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    children: \"Home\"\n                }, void 0, false, {\n                    fileName: \"D:\\\\Youtube\\\\Youtube-Mini-Series\\\\Javascript\\\\Supabase-NextJS\\\\project\\\\components\\\\nav.js\",\n                    lineNumber: 24,\n                    columnNumber: 9\n                }, undefined)\n            }, void 0, false, {\n                fileName: \"D:\\\\Youtube\\\\Youtube-Mini-Series\\\\Javascript\\\\Supabase-NextJS\\\\project\\\\components\\\\nav.js\",\n                lineNumber: 23,\n                columnNumber: 7\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                href: \"/pricing\",\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    className: \"ml-2\",\n                    children: \"Pricing\"\n                }, void 0, false, {\n                    fileName: \"D:\\\\Youtube\\\\Youtube-Mini-Series\\\\Javascript\\\\Supabase-NextJS\\\\project\\\\components\\\\nav.js\",\n                    lineNumber: 27,\n                    columnNumber: 9\n                }, undefined)\n            }, void 0, false, {\n                fileName: \"D:\\\\Youtube\\\\Youtube-Mini-Series\\\\Javascript\\\\Supabase-NextJS\\\\project\\\\components\\\\nav.js\",\n                lineNumber: 26,\n                columnNumber: 7\n            }, undefined),\n            !!user && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                href: \"/dashboard\",\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    className: \"ml-2\",\n                    children: \"Dashboard\"\n                }, void 0, false, {\n                    fileName: \"D:\\\\Youtube\\\\Youtube-Mini-Series\\\\Javascript\\\\Supabase-NextJS\\\\project\\\\components\\\\nav.js\",\n                    lineNumber: 31,\n                    columnNumber: 11\n                }, undefined)\n            }, void 0, false, {\n                fileName: \"D:\\\\Youtube\\\\Youtube-Mini-Series\\\\Javascript\\\\Supabase-NextJS\\\\project\\\\components\\\\nav.js\",\n                lineNumber: 30,\n                columnNumber: 9\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                href: user ? \"/logout\" : \"/login\",\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    className: \"ml-2\",\n                    children: user ? \"Logout\" : \"Login\"\n                }, void 0, false, {\n                    fileName: \"D:\\\\Youtube\\\\Youtube-Mini-Series\\\\Javascript\\\\Supabase-NextJS\\\\project\\\\components\\\\nav.js\",\n                    lineNumber: 35,\n                    columnNumber: 9\n                }, undefined)\n            }, void 0, false, {\n                fileName: \"D:\\\\Youtube\\\\Youtube-Mini-Series\\\\Javascript\\\\Supabase-NextJS\\\\project\\\\components\\\\nav.js\",\n                lineNumber: 34,\n                columnNumber: 7\n            }, undefined)\n        ]\n    }, void 0, true, {\n        fileName: \"D:\\\\Youtube\\\\Youtube-Mini-Series\\\\Javascript\\\\Supabase-NextJS\\\\project\\\\components\\\\nav.js\",\n        lineNumber: 22,\n        columnNumber: 5\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Nav);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL25hdi5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBNkI7QUFDYTtBQUNFO0FBRTVDLE1BQU1JLE1BQU07SUFDVixNQUFNLEVBQUVDLE1BQU1DLFdBQVcsRUFBRSxHQUFHTCxzREFBT0E7SUFDckMsTUFBTSxDQUFDSSxNQUFNRSxRQUFRLEdBQUdKLCtDQUFRQSxDQUFDO0lBQ2pDRCxnREFBU0EsQ0FBQztRQUNSLE1BQU1NLFlBQVk7WUFDaEIsSUFBSTtnQkFDRixNQUFNLEVBQUNDLE1BQUssRUFBQ0osSUFBSSxFQUFDLEVBQUMsR0FBRyxNQUFNQztnQkFDNUJJLFFBQVFDLEdBQUcsQ0FBQyxrQkFBa0JOO2dCQUM5QkUsUUFBUUYsT0FBTyxxQkFBcUI7WUFDdEMsRUFBRSxPQUFPTyxPQUFPO2dCQUNkRixRQUFRRSxLQUFLLENBQUMsd0JBQXdCQSxNQUFNQyxPQUFPO1lBQ3JEO1FBQ0Y7UUFDQUw7SUFDRixHQUFHO1FBQUNGO0tBQVk7SUFFaEIscUJBQ0UsOERBQUNRO1FBQUlDLFdBQVU7OzBCQUNiLDhEQUFDZixrREFBSUE7Z0JBQUNnQixNQUFLOzBCQUNULDRFQUFDQzs4QkFBSTs7Ozs7Ozs7Ozs7MEJBRVAsOERBQUNqQixrREFBSUE7Z0JBQUNnQixNQUFLOzBCQUNULDRFQUFDQztvQkFBSUYsV0FBVTs4QkFBTzs7Ozs7Ozs7Ozs7WUFFdkIsQ0FBQyxDQUFDVixzQkFDRCw4REFBQ0wsa0RBQUlBO2dCQUFDZ0IsTUFBSzswQkFDVCw0RUFBQ0M7b0JBQUlGLFdBQVU7OEJBQU87Ozs7Ozs7Ozs7OzBCQUcxQiw4REFBQ2Ysa0RBQUlBO2dCQUFDZ0IsTUFBTVgsT0FBTSxZQUFZOzBCQUM1Qiw0RUFBQ1k7b0JBQUlGLFdBQVU7OEJBQVFWLE9BQU8sV0FBVzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJakQ7QUFFQSxpRUFBZUQsR0FBR0EsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3Byb2plY3QvLi9jb21wb25lbnRzL25hdi5qcz81MzcwIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBMaW5rIGZyb20gXCJuZXh0L2xpbmtcIjtcclxuaW1wb3J0IHsgdXNlVXNlciB9IGZyb20gXCIuLi9jb250ZXh0L3VzZXJcIjtcclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5cclxuY29uc3QgTmF2ID0gKCkgPT4ge1xyXG4gIGNvbnN0IHsgdXNlcjogdXNlclByb21pc2UgfSA9IHVzZVVzZXIoKTtcclxuICBjb25zdCBbdXNlciwgc2V0VXNlcl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hEYXRhID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHtkYXRhOnt1c2VyfX0gPSBhd2FpdCB1c2VyUHJvbWlzZTtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIlJlc29sdmVkIFVzZXI6XCIsIHVzZXIpO1xyXG4gICAgICAgIHNldFVzZXIodXNlcik7IC8vIFNldCB0aGUgdXNlciBzdGF0ZVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBkYXRhOlwiLCBlcnJvci5tZXNzYWdlKTtcclxuICAgICAgfSBcclxuICAgIH07XHJcbiAgICBmZXRjaERhdGEoKTtcclxuICB9LCBbdXNlclByb21pc2VdKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxuYXYgY2xhc3NOYW1lPVwiZmxleCBweS00IHB4LTYgYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwXCI+XHJcbiAgICAgIDxMaW5rIGhyZWY9XCIvXCI+XHJcbiAgICAgICAgPGRpdj5Ib21lPC9kaXY+XHJcbiAgICAgIDwvTGluaz5cclxuICAgICAgPExpbmsgaHJlZj1cIi9wcmljaW5nXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtbC0yXCI+UHJpY2luZzwvZGl2PlxyXG4gICAgICA8L0xpbms+XHJcbiAgICAgIHshIXVzZXIgJiYgKFxyXG4gICAgICAgIDxMaW5rIGhyZWY9XCIvZGFzaGJvYXJkXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1sLTJcIj5EYXNoYm9hcmQ8L2Rpdj5cclxuICAgICAgICA8L0xpbms+XHJcbiAgICAgICl9XHJcbiAgICAgIDxMaW5rIGhyZWY9e3VzZXI/IFwiL2xvZ291dFwiIDogXCIvbG9naW5cIn0+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtbC0yXCI+e3VzZXIgPyBcIkxvZ291dFwiIDogXCJMb2dpblwifTwvZGl2PlxyXG4gICAgICA8L0xpbms+XHJcbiAgICA8L25hdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgTmF2OyJdLCJuYW1lcyI6WyJMaW5rIiwidXNlVXNlciIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiTmF2IiwidXNlciIsInVzZXJQcm9taXNlIiwic2V0VXNlciIsImZldGNoRGF0YSIsImRhdGEiLCJjb25zb2xlIiwibG9nIiwiZXJyb3IiLCJtZXNzYWdlIiwibmF2IiwiY2xhc3NOYW1lIiwiaHJlZiIsImRpdiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./components/nav.js\n");

/***/ }),

/***/ "./context/user.js":
/*!*************************!*\
  !*** ./context/user.js ***!
  \*************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   useUser: () => (/* binding */ useUser)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _utils_supabase__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/supabase */ \"./utils/supabase.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ \"./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! axios */ \"axios\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_4__]);\naxios__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\n\nconst Context = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();\n// Export the context and the useUser hook\nconst Provider = ({ children })=>{\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();\n    const [user, setUser] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(_utils_supabase__WEBPACK_IMPORTED_MODULE_2__.supabase.auth.getUser());\n    const [session, setSession] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);\n    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        const getUserProfile = async ()=>{\n            const { data: { session } } = await _utils_supabase__WEBPACK_IMPORTED_MODULE_2__.supabase.auth.getSession();\n            if (session?.user) {\n                const { data: profile } = await _utils_supabase__WEBPACK_IMPORTED_MODULE_2__.supabase.from(\"profile\").select(\"*\").eq(\"id\", session?.user.id) //\"4f232603-af4d-4260-9150-a7c6ee158cdf\"\n                .single();\n                console.log(\"calling session user\" + session?.user.id);\n                setUser({\n                    ...session?.user,\n                    ...profile\n                });\n                setSession(session);\n            }\n            setIsLoading(false);\n        };\n        getUserProfile();\n        _utils_supabase__WEBPACK_IMPORTED_MODULE_2__.supabase.auth.onAuthStateChange(()=>{\n            getUserProfile();\n        });\n    }, []);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        axios__WEBPACK_IMPORTED_MODULE_4__[\"default\"].post(\"/api/set-supabase-cookie\", {\n            event: user ? \"SIGNED_IN\" : \"SIGNED_OUT\",\n            user: user\n        });\n    }, [\n        user\n    ]);\n    const login = async ()=>{\n        _utils_supabase__WEBPACK_IMPORTED_MODULE_2__.supabase.auth.signInWithOAuth({\n            provider: \"github\"\n        });\n    };\n    const logout = async ()=>{\n        _utils_supabase__WEBPACK_IMPORTED_MODULE_2__.supabase.auth.signOut();\n        setUser(null);\n        router.push(\"/\");\n    };\n    const exposed = {\n        user,\n        login,\n        logout,\n        isLoading\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Context.Provider, {\n        value: exposed,\n        children: children\n    }, void 0, false, {\n        fileName: \"D:\\\\Youtube\\\\Youtube-Mini-Series\\\\Javascript\\\\Supabase-NextJS\\\\project\\\\context\\\\user.js\",\n        lineNumber: 70,\n        columnNumber: 12\n    }, undefined);\n};\nconst useUser = ()=>(0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(Context);\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Provider);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb250ZXh0L3VzZXIuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBdUU7QUFDMUI7QUFDTDtBQUNkO0FBRTFCLE1BQU1PLHdCQUFVUCxvREFBYUE7QUFDN0IsMENBQTBDO0FBQzFDLE1BQU1RLFdBQVksQ0FBQyxFQUFFQyxRQUFRLEVBQUU7SUFDM0IsTUFBTUMsU0FBU0wsc0RBQVNBO0lBQ3hCLE1BQU0sQ0FBQ00sTUFBTUMsUUFBUSxHQUFHWCwrQ0FBUUEsQ0FBQ0cscURBQVFBLENBQUNTLElBQUksQ0FBQ0MsT0FBTztJQUN0RCxNQUFNLENBQUNDLFNBQVNDLFdBQVcsR0FBR2YsK0NBQVFBLENBQUM7SUFDdkMsTUFBTSxDQUFDZ0IsV0FBV0MsYUFBYSxHQUFHakIsK0NBQVFBLENBQUM7SUFFM0NDLGdEQUFTQSxDQUFDO1FBQ1IsTUFBTWlCLGlCQUFpQjtZQUNyQixNQUFNLEVBQUNDLE1BQUssRUFBRUwsT0FBTyxFQUFFLEVBQUMsR0FBRyxNQUFNWCxxREFBUUEsQ0FBQ1MsSUFBSSxDQUFDUSxVQUFVO1lBRXpELElBQUlOLFNBQVNKLE1BQU07Z0JBRWpCLE1BQU0sRUFBRVMsTUFBTUUsT0FBTyxFQUFFLEdBQUcsTUFBTWxCLHFEQUFRQSxDQUNyQ21CLElBQUksQ0FBQyxXQUNMQyxNQUFNLENBQUMsS0FDUEMsRUFBRSxDQUFDLE1BQU1WLFNBQVNKLEtBQUtlLElBQUksd0NBQXdDO2lCQUNuRUMsTUFBTTtnQkFFUEMsUUFBUUMsR0FBRyxDQUFDLHlCQUF5QmQsU0FBU0osS0FBS2U7Z0JBQ3JEZCxRQUFRO29CQUNOLEdBQUdHLFNBQVNKLElBQUk7b0JBQ2hCLEdBQUdXLE9BQU87Z0JBQ1o7Z0JBQ0FOLFdBQVdEO1lBRWI7WUFDQUcsYUFBYTtRQUNmO1FBRUFDO1FBRUFmLHFEQUFRQSxDQUFDUyxJQUFJLENBQUNpQixpQkFBaUIsQ0FBQztZQUM5Qlg7UUFDRjtJQUNGLEdBQUcsRUFBRTtJQUVMakIsZ0RBQVNBLENBQUM7UUFDUkksa0RBQVUsQ0FBQyw0QkFBNEI7WUFDckMwQixPQUFPckIsT0FBTyxjQUFjO1lBQzVCQSxNQUFNQTtRQUNSO0lBQ0YsR0FBRztRQUFDQTtLQUFLO0lBRVQsTUFBTXNCLFFBQVE7UUFDYjdCLHFEQUFRQSxDQUFDUyxJQUFJLENBQUNxQixlQUFlLENBQUM7WUFDdkJDLFVBQVU7UUFDWjtJQUNKO0lBRUYsTUFBTUMsU0FBUztRQUNkaEMscURBQVFBLENBQUNTLElBQUksQ0FBQ3dCLE9BQU87UUFDbEJ6QixRQUFRO1FBQ1JGLE9BQU80QixJQUFJLENBQUM7SUFDZDtJQUVBLE1BQU1DLFVBQVU7UUFDZDVCO1FBQ0FzQjtRQUNBRztRQUNBbkI7SUFDRjtJQUVGLHFCQUFPLDhEQUFDVixRQUFRQyxRQUFRO1FBQUNnQyxPQUFPRDtrQkFBVTlCOzs7Ozs7QUFDOUM7QUFDTyxNQUFNZ0MsVUFBVSxJQUFNdEMsaURBQVVBLENBQUNJLFNBQVM7QUFFakQsaUVBQWVDLFFBQVFBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9wcm9qZWN0Ly4vY29udGV4dC91c2VyLmpzP2Y2MDAiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlQ29udGV4dCwgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlQ29udGV4dCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBzdXBhYmFzZSB9IGZyb20gXCIuLi91dGlscy9zdXBhYmFzZVwiO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xyXG5cclxuY29uc3QgQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQoKTtcclxuLy8gRXhwb3J0IHRoZSBjb250ZXh0IGFuZCB0aGUgdXNlVXNlciBob29rXHJcbmNvbnN0IFByb3ZpZGVyICA9ICh7IGNoaWxkcmVuIH0pID0+IHtcclxuICAgIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xyXG4gICAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUoc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCkpO1xyXG4gICAgY29uc3QgW3Nlc3Npb24sIHNldFNlc3Npb25dID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgY29uc3QgZ2V0VXNlclByb2ZpbGUgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgY29uc3Qge2RhdGE6eyBzZXNzaW9uIH19ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRTZXNzaW9uKCk7XHJcbiAgICAgICBcclxuICAgICAgICBpZiAoc2Vzc2lvbj8udXNlcikge1xyXG4gICAgICAgICBcclxuICAgICAgICAgIGNvbnN0IHsgZGF0YTogcHJvZmlsZSB9ID0gYXdhaXQgc3VwYWJhc2VcclxuICAgICAgICAgICAgLmZyb20oXCJwcm9maWxlXCIpXHJcbiAgICAgICAgICAgIC5zZWxlY3QoXCIqXCIpXHJcbiAgICAgICAgICAgIC5lcShcImlkXCIsIHNlc3Npb24/LnVzZXIuaWQpIC8vXCI0ZjIzMjYwMy1hZjRkLTQyNjAtOTE1MC1hN2M2ZWUxNThjZGZcIlxyXG4gICAgICAgICAgICAuc2luZ2xlKCk7XHJcbiAgICAgICAgICBcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJjYWxsaW5nIHNlc3Npb24gdXNlclwiICsgc2Vzc2lvbj8udXNlci5pZCk7XHJcbiAgICAgICAgICBzZXRVc2VyKHtcclxuICAgICAgICAgICAgLi4uc2Vzc2lvbj8udXNlcixcclxuICAgICAgICAgICAgLi4ucHJvZmlsZSxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgc2V0U2Vzc2lvbihzZXNzaW9uKTtcclxuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH07XHJcbiAgXHJcbiAgICAgIGdldFVzZXJQcm9maWxlKCk7XHJcbiAgXHJcbiAgICAgIHN1cGFiYXNlLmF1dGgub25BdXRoU3RhdGVDaGFuZ2UoKCkgPT4ge1xyXG4gICAgICAgIGdldFVzZXJQcm9maWxlKCk7XHJcbiAgICAgIH0pO1xyXG4gICAgfSwgW10pO1xyXG5cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgIGF4aW9zLnBvc3QoXCIvYXBpL3NldC1zdXBhYmFzZS1jb29raWVcIiwge1xyXG4gICAgICAgIGV2ZW50OiB1c2VyID8gXCJTSUdORURfSU5cIiA6IFwiU0lHTkVEX09VVFwiLFxyXG4gICAgICAgIHVzZXI6IHVzZXIsXHJcbiAgICAgIH0pO1xyXG4gICAgfSwgW3VzZXJdKTtcclxuXHJcbiAgICBjb25zdCBsb2dpbiA9IGFzeW5jICgpID0+IHtcclxuICAgICBzdXBhYmFzZS5hdXRoLnNpZ25JbldpdGhPQXV0aCh7XHJcbiAgICAgICAgICAgIHByb3ZpZGVyOiBcImdpdGh1YlwiLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgIH07XHJcblxyXG4gICAgY29uc3QgbG9nb3V0ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgIHN1cGFiYXNlLmF1dGguc2lnbk91dCgpO1xyXG4gICAgICAgIHNldFVzZXIobnVsbCk7XHJcbiAgICAgICAgcm91dGVyLnB1c2goXCIvXCIpO1xyXG4gICAgICB9O1xyXG5cclxuICAgICAgY29uc3QgZXhwb3NlZCA9IHtcclxuICAgICAgICB1c2VyLFxyXG4gICAgICAgIGxvZ2luLFxyXG4gICAgICAgIGxvZ291dCxcclxuICAgICAgICBpc0xvYWRpbmdcclxuICAgICAgfTtcclxuXHJcbiAgICByZXR1cm4gPENvbnRleHQuUHJvdmlkZXIgdmFsdWU9e2V4cG9zZWR9PntjaGlsZHJlbn08L0NvbnRleHQuUHJvdmlkZXI+O1xyXG59XHJcbmV4cG9ydCBjb25zdCB1c2VVc2VyID0gKCkgPT4gdXNlQ29udGV4dChDb250ZXh0KTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFByb3ZpZGVyOyJdLCJuYW1lcyI6WyJjcmVhdGVDb250ZXh0IiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VDb250ZXh0Iiwic3VwYWJhc2UiLCJ1c2VSb3V0ZXIiLCJheGlvcyIsIkNvbnRleHQiLCJQcm92aWRlciIsImNoaWxkcmVuIiwicm91dGVyIiwidXNlciIsInNldFVzZXIiLCJhdXRoIiwiZ2V0VXNlciIsInNlc3Npb24iLCJzZXRTZXNzaW9uIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwiZ2V0VXNlclByb2ZpbGUiLCJkYXRhIiwiZ2V0U2Vzc2lvbiIsInByb2ZpbGUiLCJmcm9tIiwic2VsZWN0IiwiZXEiLCJpZCIsInNpbmdsZSIsImNvbnNvbGUiLCJsb2ciLCJvbkF1dGhTdGF0ZUNoYW5nZSIsInBvc3QiLCJldmVudCIsImxvZ2luIiwic2lnbkluV2l0aE9BdXRoIiwicHJvdmlkZXIiLCJsb2dvdXQiLCJzaWduT3V0IiwicHVzaCIsImV4cG9zZWQiLCJ2YWx1ZSIsInVzZVVzZXIiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./context/user.js\n");

/***/ }),

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var tailwindcss_tailwind_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tailwindcss/tailwind.css */ \"./node_modules/tailwindcss/tailwind.css\");\n/* harmony import */ var tailwindcss_tailwind_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(tailwindcss_tailwind_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _context_user__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../context/user */ \"./context/user.js\");\n/* harmony import */ var _components_nav__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/nav */ \"./components/nav.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_user__WEBPACK_IMPORTED_MODULE_2__, _components_nav__WEBPACK_IMPORTED_MODULE_3__]);\n([_context_user__WEBPACK_IMPORTED_MODULE_2__, _components_nav__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\nfunction MyApp({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_context_user__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_nav__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {}, void 0, false, {\n                fileName: \"D:\\\\Youtube\\\\Youtube-Mini-Series\\\\Javascript\\\\Supabase-NextJS\\\\project\\\\pages\\\\_app.js\",\n                lineNumber: 8,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                ...pageProps\n            }, void 0, false, {\n                fileName: \"D:\\\\Youtube\\\\Youtube-Mini-Series\\\\Javascript\\\\Supabase-NextJS\\\\project\\\\pages\\\\_app.js\",\n                lineNumber: 9,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"D:\\\\Youtube\\\\Youtube-Mini-Series\\\\Javascript\\\\Supabase-NextJS\\\\project\\\\pages\\\\_app.js\",\n        lineNumber: 7,\n        columnNumber: 5\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBQWtDO0FBQ1M7QUFDUDtBQUVwQyxTQUFTRSxNQUFNLEVBQUVDLFNBQVMsRUFBRUMsU0FBUyxFQUFFO0lBQ3JDLHFCQUNFLDhEQUFDSixxREFBWUE7OzBCQUNYLDhEQUFDQyx1REFBR0E7Ozs7OzBCQUNKLDhEQUFDRTtnQkFBVyxHQUFHQyxTQUFTOzs7Ozs7Ozs7Ozs7QUFHOUI7QUFFQSxpRUFBZUYsS0FBS0EsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3Byb2plY3QvLi9wYWdlcy9fYXBwLmpzP2UwYWQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwidGFpbHdpbmRjc3MvdGFpbHdpbmQuY3NzXCI7XHJcbmltcG9ydCBVc2VyUHJvdmlkZXIgZnJvbSBcIi4uL2NvbnRleHQvdXNlclwiO1xyXG5pbXBvcnQgTmF2IGZyb20gXCIuLi9jb21wb25lbnRzL25hdlwiO1xyXG5cclxuZnVuY3Rpb24gTXlBcHAoeyBDb21wb25lbnQsIHBhZ2VQcm9wcyB9KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxVc2VyUHJvdmlkZXI+XHJcbiAgICAgIDxOYXYgLz5cclxuICAgICAgPENvbXBvbmVudCB7Li4ucGFnZVByb3BzfSAvPlxyXG4gICAgPC9Vc2VyUHJvdmlkZXI+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTXlBcHA7Il0sIm5hbWVzIjpbIlVzZXJQcm92aWRlciIsIk5hdiIsIk15QXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./utils/supabase.js":
/*!***************************!*\
  !*** ./utils/supabase.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   getServiceSupabase: () => (/* binding */ getServiceSupabase),\n/* harmony export */   supabase: () => (/* binding */ supabase)\n/* harmony export */ });\n/* harmony import */ var _supabase_supabase_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @supabase/supabase-js */ \"@supabase/supabase-js\");\n/* harmony import */ var _supabase_supabase_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_supabase_supabase_js__WEBPACK_IMPORTED_MODULE_0__);\n\nconsole.log(\"NEXT_PUBLIC_SUPABASE_URL:\", \"https://nmgioeeopdxlscikuyje.supabase.co\");\nconsole.log(\"NEXT_PUBLIC_SUPABASE_KEY:\", \"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5tZ2lvZWVvcGR4bHNjaWt1eWplIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDg1MjM1MzMsImV4cCI6MjAyNDA5OTUzM30.MyTRQ64GR_63MHEg5yy3c7FbfteW9Xm5TGoBI8fMIPM\");\nconst supabase = (0,_supabase_supabase_js__WEBPACK_IMPORTED_MODULE_0__.createClient)(\"https://nmgioeeopdxlscikuyje.supabase.co\", \"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5tZ2lvZWVvcGR4bHNjaWt1eWplIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDg1MjM1MzMsImV4cCI6MjAyNDA5OTUzM30.MyTRQ64GR_63MHEg5yy3c7FbfteW9Xm5TGoBI8fMIPM\");\nconst getServiceSupabase = ()=>(0,_supabase_supabase_js__WEBPACK_IMPORTED_MODULE_0__.createClient)(\"https://nmgioeeopdxlscikuyje.supabase.co\", process.env.SUPABASE_SERVICE_KEY);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi91dGlscy9zdXBhYmFzZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQXFEO0FBRXJEQyxRQUFRQyxHQUFHLENBQUMsNkJBQTZCQywwQ0FBb0M7QUFDN0VGLFFBQVFDLEdBQUcsQ0FBQyw2QkFBNkJDLGtOQUFvQztBQUV0RSxNQUFNSSxXQUFXUCxtRUFBWUEsQ0FDaENHLDBDQUFvQyxFQUNwQ0Esa05BQW9DLEVBQ3BDO0FBRUssTUFBTUsscUJBQXFCLElBQ2xDUixtRUFBWUEsQ0FDVkcsMENBQW9DLEVBQ3BDQSxRQUFRQyxHQUFHLENBQUNLLG9CQUFvQixFQUNoQyIsInNvdXJjZXMiOlsid2VicGFjazovL3Byb2plY3QvLi91dGlscy9zdXBhYmFzZS5qcz80MDZkIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJAc3VwYWJhc2Uvc3VwYWJhc2UtanNcIjtcclxuXHJcbmNvbnNvbGUubG9nKFwiTkVYVF9QVUJMSUNfU1VQQUJBU0VfVVJMOlwiLCBwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19TVVBBQkFTRV9VUkwpO1xyXG5jb25zb2xlLmxvZyhcIk5FWFRfUFVCTElDX1NVUEFCQVNFX0tFWTpcIiwgcHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfU1VQQUJBU0VfS0VZKTtcclxuXHJcbmV4cG9ydCBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudChcclxuICAgIHByb2Nlc3MuZW52Lk5FWFRfUFVCTElDX1NVUEFCQVNFX1VSTCxcclxuICAgIHByb2Nlc3MuZW52Lk5FWFRfUFVCTElDX1NVUEFCQVNFX0tFWVxyXG4gICk7XHJcblxyXG4gIGV4cG9ydCBjb25zdCBnZXRTZXJ2aWNlU3VwYWJhc2UgPSAoKSA9PlxyXG4gIGNyZWF0ZUNsaWVudChcclxuICAgIHByb2Nlc3MuZW52Lk5FWFRfUFVCTElDX1NVUEFCQVNFX1VSTCxcclxuICAgIHByb2Nlc3MuZW52LlNVUEFCQVNFX1NFUlZJQ0VfS0VZXHJcbiAgKTsiXSwibmFtZXMiOlsiY3JlYXRlQ2xpZW50IiwiY29uc29sZSIsImxvZyIsInByb2Nlc3MiLCJlbnYiLCJORVhUX1BVQkxJQ19TVVBBQkFTRV9VUkwiLCJORVhUX1BVQkxJQ19TVVBBQkFTRV9LRVkiLCJzdXBhYmFzZSIsImdldFNlcnZpY2VTdXBhYmFzZSIsIlNVUEFCQVNFX1NFUlZJQ0VfS0VZIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./utils/supabase.js\n");

/***/ }),

/***/ "@supabase/supabase-js":
/*!****************************************!*\
  !*** external "@supabase/supabase-js" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("@supabase/supabase-js");

/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("zlib");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc","vendor-chunks/tailwindcss"], () => (__webpack_exec__("./pages/_app.js")));
module.exports = __webpack_exports__;

})();