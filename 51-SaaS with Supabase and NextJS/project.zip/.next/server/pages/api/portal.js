"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/portal";
exports.ids = ["pages/api/portal"];
exports.modules = {

/***/ "@supabase/supabase-js":
/*!****************************************!*\
  !*** external "@supabase/supabase-js" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("@supabase/supabase-js");

/***/ }),

/***/ "cookie":
/*!*************************!*\
  !*** external "cookie" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("cookie");

/***/ }),

/***/ "next/dist/compiled/next-server/pages-api.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages-api.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/pages-api.runtime.dev.js");

/***/ }),

/***/ "stripe":
/*!*************************!*\
  !*** external "stripe" ***!
  \*************************/
/***/ ((module) => {

module.exports = import("stripe");;

/***/ }),

/***/ "(api)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Fportal&preferredRegion=&absolutePagePath=.%2Fpages%5Capi%5Cportal.js&middlewareConfigBase64=e30%3D!":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Fportal&preferredRegion=&absolutePagePath=.%2Fpages%5Capi%5Cportal.js&middlewareConfigBase64=e30%3D! ***!
  \******************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   config: () => (/* binding */ config),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   routeModule: () => (/* binding */ routeModule)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/pages-api/module.compiled */ \"(api)/./node_modules/next/dist/server/future/route-modules/pages-api/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"(api)/./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/build/templates/helpers */ \"(api)/./node_modules/next/dist/build/templates/helpers.js\");\n/* harmony import */ var _pages_api_portal_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages\\api\\portal.js */ \"(api)/./pages/api/portal.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_api_portal_js__WEBPACK_IMPORTED_MODULE_3__]);\n_pages_api_portal_js__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n// Import the userland code.\n\n// Re-export the handler (should be the default export).\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_api_portal_js__WEBPACK_IMPORTED_MODULE_3__, \"default\"));\n// Re-export config.\nconst config = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_api_portal_js__WEBPACK_IMPORTED_MODULE_3__, \"config\");\n// Create and export the route module that will be consumed.\nconst routeModule = new next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__.PagesAPIRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.PAGES_API,\n        page: \"/api/portal\",\n        pathname: \"/api/portal\",\n        // The following aren't used in production.\n        bundlePath: \"\",\n        filename: \"\"\n    },\n    userland: _pages_api_portal_js__WEBPACK_IMPORTED_MODULE_3__\n});\n\n//# sourceMappingURL=pages-api.js.map\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LXJvdXRlLWxvYWRlci9pbmRleC5qcz9raW5kPVBBR0VTX0FQSSZwYWdlPSUyRmFwaSUyRnBvcnRhbCZwcmVmZXJyZWRSZWdpb249JmFic29sdXRlUGFnZVBhdGg9LiUyRnBhZ2VzJTVDYXBpJTVDcG9ydGFsLmpzJm1pZGRsZXdhcmVDb25maWdCYXNlNjQ9ZTMwJTNEISIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUFzRztBQUN2QztBQUNMO0FBQzFEO0FBQ29EO0FBQ3BEO0FBQ0EsaUVBQWUsd0VBQUssQ0FBQyxpREFBUSxZQUFZLEVBQUM7QUFDMUM7QUFDTyxlQUFlLHdFQUFLLENBQUMsaURBQVE7QUFDcEM7QUFDTyx3QkFBd0IsZ0hBQW1CO0FBQ2xEO0FBQ0EsY0FBYyx5RUFBUztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLFlBQVk7QUFDWixDQUFDOztBQUVELHFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcHJvamVjdC8/NWY1NSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQYWdlc0FQSVJvdXRlTW9kdWxlIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvZnV0dXJlL3JvdXRlLW1vZHVsZXMvcGFnZXMtYXBpL21vZHVsZS5jb21waWxlZFwiO1xuaW1wb3J0IHsgUm91dGVLaW5kIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvZnV0dXJlL3JvdXRlLWtpbmRcIjtcbmltcG9ydCB7IGhvaXN0IH0gZnJvbSBcIm5leHQvZGlzdC9idWlsZC90ZW1wbGF0ZXMvaGVscGVyc1wiO1xuLy8gSW1wb3J0IHRoZSB1c2VybGFuZCBjb2RlLlxuaW1wb3J0ICogYXMgdXNlcmxhbmQgZnJvbSBcIi4vcGFnZXNcXFxcYXBpXFxcXHBvcnRhbC5qc1wiO1xuLy8gUmUtZXhwb3J0IHRoZSBoYW5kbGVyIChzaG91bGQgYmUgdGhlIGRlZmF1bHQgZXhwb3J0KS5cbmV4cG9ydCBkZWZhdWx0IGhvaXN0KHVzZXJsYW5kLCBcImRlZmF1bHRcIik7XG4vLyBSZS1leHBvcnQgY29uZmlnLlxuZXhwb3J0IGNvbnN0IGNvbmZpZyA9IGhvaXN0KHVzZXJsYW5kLCBcImNvbmZpZ1wiKTtcbi8vIENyZWF0ZSBhbmQgZXhwb3J0IHRoZSByb3V0ZSBtb2R1bGUgdGhhdCB3aWxsIGJlIGNvbnN1bWVkLlxuZXhwb3J0IGNvbnN0IHJvdXRlTW9kdWxlID0gbmV3IFBhZ2VzQVBJUm91dGVNb2R1bGUoe1xuICAgIGRlZmluaXRpb246IHtcbiAgICAgICAga2luZDogUm91dGVLaW5kLlBBR0VTX0FQSSxcbiAgICAgICAgcGFnZTogXCIvYXBpL3BvcnRhbFwiLFxuICAgICAgICBwYXRobmFtZTogXCIvYXBpL3BvcnRhbFwiLFxuICAgICAgICAvLyBUaGUgZm9sbG93aW5nIGFyZW4ndCB1c2VkIGluIHByb2R1Y3Rpb24uXG4gICAgICAgIGJ1bmRsZVBhdGg6IFwiXCIsXG4gICAgICAgIGZpbGVuYW1lOiBcIlwiXG4gICAgfSxcbiAgICB1c2VybGFuZFxufSk7XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXBhZ2VzLWFwaS5qcy5tYXAiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Fportal&preferredRegion=&absolutePagePath=.%2Fpages%5Capi%5Cportal.js&middlewareConfigBase64=e30%3D!\n");

/***/ }),

/***/ "(api)/./pages/api/portal.js":
/*!*****************************!*\
  !*** ./pages/api/portal.js ***!
  \*****************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _utils_supabase__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../utils/supabase */ \"(api)/./utils/supabase.js\");\n/* harmony import */ var stripe__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! stripe */ \"stripe\");\n/* harmony import */ var _utils_cookies__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../utils/cookies */ \"(api)/./utils/cookies.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([stripe__WEBPACK_IMPORTED_MODULE_1__]);\nstripe__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\nconst handler = async (req, res)=>{\n    const userCookie = (0,_utils_cookies__WEBPACK_IMPORTED_MODULE_2__.getUserCookie)(req);\n    if (!userCookie) {\n        return res.status(401).send(\"Unauthorized\");\n    }\n    const { data: { stripe_customer } } = await _utils_supabase__WEBPACK_IMPORTED_MODULE_0__.supabase.from(\"profile\").select(\"stripe_customer\").eq(\"id\", userCookie.id).single();\n    const stripe = (0,stripe__WEBPACK_IMPORTED_MODULE_1__[\"default\"])(process.env.STRIPE_SECRET_KEY);\n    const session = await stripe.billingPortal.sessions.create({\n        customer: stripe_customer,\n        return_url: \"http://localhost:3000/dashboard\"\n    });\n    res.send({\n        url: session.url\n    });\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvcG9ydGFsLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBZ0Q7QUFDaEI7QUFDb0I7QUFFcEQsTUFBTUcsVUFBVSxPQUFPQyxLQUFLQztJQUN4QixNQUFNQyxhQUFhSiw2REFBYUEsQ0FBQ0U7SUFFakMsSUFBSSxDQUFDRSxZQUFZO1FBQ2YsT0FBT0QsSUFBSUUsTUFBTSxDQUFDLEtBQUtDLElBQUksQ0FBQztJQUM5QjtJQUVBLE1BQU0sRUFDSkMsTUFBTSxFQUFFQyxlQUFlLEVBQUUsRUFDMUIsR0FBRyxNQUFNVixxREFBUUEsQ0FDZlcsSUFBSSxDQUFDLFdBQ0xDLE1BQU0sQ0FBQyxtQkFDUEMsRUFBRSxDQUFDLE1BQU1QLFdBQVdRLEVBQUUsRUFDdEJDLE1BQU07SUFFVCxNQUFNQyxTQUFTZixrREFBVUEsQ0FBQ2dCLFFBQVFDLEdBQUcsQ0FBQ0MsaUJBQWlCO0lBRXZELE1BQU1DLFVBQVUsTUFBTUosT0FBT0ssYUFBYSxDQUFDQyxRQUFRLENBQUNDLE1BQU0sQ0FBQztRQUN6REMsVUFBVWQ7UUFDVmUsWUFBWTtJQUNkO0lBRUFwQixJQUFJRyxJQUFJLENBQUM7UUFDUGtCLEtBQUtOLFFBQVFNLEdBQUc7SUFDbEI7QUFDRjtBQUVBLGlFQUFldkIsT0FBT0EsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3Byb2plY3QvLi9wYWdlcy9hcGkvcG9ydGFsLmpzPzg3OWYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgc3VwYWJhc2UgfSBmcm9tIFwiLi4vLi4vdXRpbHMvc3VwYWJhc2VcIjtcclxuaW1wb3J0IGluaXRTdHJpcGUgZnJvbSBcInN0cmlwZVwiO1xyXG5pbXBvcnQgeyBnZXRVc2VyQ29va2llIH0gZnJvbSAnLi4vLi4vdXRpbHMvY29va2llcyc7XHJcblxyXG5jb25zdCBoYW5kbGVyID0gYXN5bmMgKHJlcSwgcmVzKSA9PiB7XHJcbiAgICBjb25zdCB1c2VyQ29va2llID0gZ2V0VXNlckNvb2tpZShyZXEpO1xyXG4gIFxyXG4gICAgaWYgKCF1c2VyQ29va2llKSB7XHJcbiAgICAgIHJldHVybiByZXMuc3RhdHVzKDQwMSkuc2VuZChcIlVuYXV0aG9yaXplZFwiKTtcclxuICAgIH1cclxuICBcclxuICAgIGNvbnN0IHtcclxuICAgICAgZGF0YTogeyBzdHJpcGVfY3VzdG9tZXIgfSxcclxuICAgIH0gPSBhd2FpdCBzdXBhYmFzZVxyXG4gICAgICAuZnJvbShcInByb2ZpbGVcIilcclxuICAgICAgLnNlbGVjdChcInN0cmlwZV9jdXN0b21lclwiKVxyXG4gICAgICAuZXEoXCJpZFwiLCB1c2VyQ29va2llLmlkKVxyXG4gICAgICAuc2luZ2xlKCk7XHJcbiAgXHJcbiAgICBjb25zdCBzdHJpcGUgPSBpbml0U3RyaXBlKHByb2Nlc3MuZW52LlNUUklQRV9TRUNSRVRfS0VZKTtcclxuICBcclxuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBzdHJpcGUuYmlsbGluZ1BvcnRhbC5zZXNzaW9ucy5jcmVhdGUoe1xyXG4gICAgICBjdXN0b21lcjogc3RyaXBlX2N1c3RvbWVyLFxyXG4gICAgICByZXR1cm5fdXJsOiBcImh0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9kYXNoYm9hcmRcIixcclxuICAgIH0pO1xyXG4gIFxyXG4gICAgcmVzLnNlbmQoe1xyXG4gICAgICB1cmw6IHNlc3Npb24udXJsLFxyXG4gICAgfSk7XHJcbiAgfTtcclxuICBcclxuICBleHBvcnQgZGVmYXVsdCBoYW5kbGVyOyJdLCJuYW1lcyI6WyJzdXBhYmFzZSIsImluaXRTdHJpcGUiLCJnZXRVc2VyQ29va2llIiwiaGFuZGxlciIsInJlcSIsInJlcyIsInVzZXJDb29raWUiLCJzdGF0dXMiLCJzZW5kIiwiZGF0YSIsInN0cmlwZV9jdXN0b21lciIsImZyb20iLCJzZWxlY3QiLCJlcSIsImlkIiwic2luZ2xlIiwic3RyaXBlIiwicHJvY2VzcyIsImVudiIsIlNUUklQRV9TRUNSRVRfS0VZIiwic2Vzc2lvbiIsImJpbGxpbmdQb3J0YWwiLCJzZXNzaW9ucyIsImNyZWF0ZSIsImN1c3RvbWVyIiwicmV0dXJuX3VybCIsInVybCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./pages/api/portal.js\n");

/***/ }),

/***/ "(api)/./utils/cookies.js":
/*!**************************!*\
  !*** ./utils/cookies.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   getUserCookie: () => (/* binding */ getUserCookie),\n/* harmony export */   parseCookies: () => (/* binding */ parseCookies)\n/* harmony export */ });\n/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! cookie */ \"cookie\");\n/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(cookie__WEBPACK_IMPORTED_MODULE_0__);\n\nfunction parseCookies(req) {\n    return cookie__WEBPACK_IMPORTED_MODULE_0___default().parse(req.headers.cookie || \"\");\n}\nfunction getUserCookie(req) {\n    const cookies = parseCookies(req);\n    const userCookie = cookies.user || null;\n    try {\n        return userCookie ? JSON.parse(userCookie) : null;\n    } catch (error) {\n        console.error(\"Error parsing user cookie:\", error);\n        return null;\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi91dGlscy9jb29raWVzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBNEI7QUFFckIsU0FBU0MsYUFBYUMsR0FBRztJQUM5QixPQUFPRixtREFBWSxDQUFDRSxJQUFJRSxPQUFPLENBQUNKLE1BQU0sSUFBSTtBQUM1QztBQUVPLFNBQVNLLGNBQWNILEdBQUc7SUFDL0IsTUFBTUksVUFBVUwsYUFBYUM7SUFDN0IsTUFBTUssYUFBYUQsUUFBUUUsSUFBSSxJQUFJO0lBQ25DLElBQUk7UUFDRixPQUFPRCxhQUFhRSxLQUFLTixLQUFLLENBQUNJLGNBQWM7SUFDL0MsRUFDQSxPQUFPRyxPQUFPO1FBQ1pDLFFBQVFELEtBQUssQ0FBQyw4QkFBOEJBO1FBQzVDLE9BQU87SUFDVDtBQUNGIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcHJvamVjdC8uL3V0aWxzL2Nvb2tpZXMuanM/ZjVhMCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgY29va2llIGZyb20gJ2Nvb2tpZSc7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VDb29raWVzKHJlcSkge1xyXG4gIHJldHVybiBjb29raWUucGFyc2UocmVxLmhlYWRlcnMuY29va2llIHx8ICcnKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGdldFVzZXJDb29raWUocmVxKSB7XHJcbiAgY29uc3QgY29va2llcyA9IHBhcnNlQ29va2llcyhyZXEpO1xyXG4gIGNvbnN0IHVzZXJDb29raWUgPSBjb29raWVzLnVzZXIgfHwgbnVsbDtcclxuICB0cnkge1xyXG4gICAgcmV0dXJuIHVzZXJDb29raWUgPyBKU09OLnBhcnNlKHVzZXJDb29raWUpIDogbnVsbDtcclxuICB9IFxyXG4gIGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcignRXJyb3IgcGFyc2luZyB1c2VyIGNvb2tpZTonLCBlcnJvcik7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcbn0iXSwibmFtZXMiOlsiY29va2llIiwicGFyc2VDb29raWVzIiwicmVxIiwicGFyc2UiLCJoZWFkZXJzIiwiZ2V0VXNlckNvb2tpZSIsImNvb2tpZXMiLCJ1c2VyQ29va2llIiwidXNlciIsIkpTT04iLCJlcnJvciIsImNvbnNvbGUiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./utils/cookies.js\n");

/***/ }),

/***/ "(api)/./utils/supabase.js":
/*!***************************!*\
  !*** ./utils/supabase.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   getServiceSupabase: () => (/* binding */ getServiceSupabase),\n/* harmony export */   supabase: () => (/* binding */ supabase)\n/* harmony export */ });\n/* harmony import */ var _supabase_supabase_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @supabase/supabase-js */ \"@supabase/supabase-js\");\n/* harmony import */ var _supabase_supabase_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_supabase_supabase_js__WEBPACK_IMPORTED_MODULE_0__);\n\nconsole.log(\"NEXT_PUBLIC_SUPABASE_URL:\", \"https://nmgioeeopdxlscikuyje.supabase.co\");\nconsole.log(\"NEXT_PUBLIC_SUPABASE_KEY:\", \"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5tZ2lvZWVvcGR4bHNjaWt1eWplIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDg1MjM1MzMsImV4cCI6MjAyNDA5OTUzM30.MyTRQ64GR_63MHEg5yy3c7FbfteW9Xm5TGoBI8fMIPM\");\nconst supabase = (0,_supabase_supabase_js__WEBPACK_IMPORTED_MODULE_0__.createClient)(\"https://nmgioeeopdxlscikuyje.supabase.co\", \"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5tZ2lvZWVvcGR4bHNjaWt1eWplIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDg1MjM1MzMsImV4cCI6MjAyNDA5OTUzM30.MyTRQ64GR_63MHEg5yy3c7FbfteW9Xm5TGoBI8fMIPM\");\nconst getServiceSupabase = ()=>(0,_supabase_supabase_js__WEBPACK_IMPORTED_MODULE_0__.createClient)(\"https://nmgioeeopdxlscikuyje.supabase.co\", process.env.SUPABASE_SERVICE_KEY);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi91dGlscy9zdXBhYmFzZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQXFEO0FBRXJEQyxRQUFRQyxHQUFHLENBQUMsNkJBQTZCQywwQ0FBb0M7QUFDN0VGLFFBQVFDLEdBQUcsQ0FBQyw2QkFBNkJDLGtOQUFvQztBQUV0RSxNQUFNSSxXQUFXUCxtRUFBWUEsQ0FDaENHLDBDQUFvQyxFQUNwQ0Esa05BQW9DLEVBQ3BDO0FBRUssTUFBTUsscUJBQXFCLElBQ2xDUixtRUFBWUEsQ0FDVkcsMENBQW9DLEVBQ3BDQSxRQUFRQyxHQUFHLENBQUNLLG9CQUFvQixFQUNoQyIsInNvdXJjZXMiOlsid2VicGFjazovL3Byb2plY3QvLi91dGlscy9zdXBhYmFzZS5qcz80MDZkIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJAc3VwYWJhc2Uvc3VwYWJhc2UtanNcIjtcclxuXHJcbmNvbnNvbGUubG9nKFwiTkVYVF9QVUJMSUNfU1VQQUJBU0VfVVJMOlwiLCBwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19TVVBBQkFTRV9VUkwpO1xyXG5jb25zb2xlLmxvZyhcIk5FWFRfUFVCTElDX1NVUEFCQVNFX0tFWTpcIiwgcHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfU1VQQUJBU0VfS0VZKTtcclxuXHJcbmV4cG9ydCBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudChcclxuICAgIHByb2Nlc3MuZW52Lk5FWFRfUFVCTElDX1NVUEFCQVNFX1VSTCxcclxuICAgIHByb2Nlc3MuZW52Lk5FWFRfUFVCTElDX1NVUEFCQVNFX0tFWVxyXG4gICk7XHJcblxyXG4gIGV4cG9ydCBjb25zdCBnZXRTZXJ2aWNlU3VwYWJhc2UgPSAoKSA9PlxyXG4gIGNyZWF0ZUNsaWVudChcclxuICAgIHByb2Nlc3MuZW52Lk5FWFRfUFVCTElDX1NVUEFCQVNFX1VSTCxcclxuICAgIHByb2Nlc3MuZW52LlNVUEFCQVNFX1NFUlZJQ0VfS0VZXHJcbiAgKTsiXSwibmFtZXMiOlsiY3JlYXRlQ2xpZW50IiwiY29uc29sZSIsImxvZyIsInByb2Nlc3MiLCJlbnYiLCJORVhUX1BVQkxJQ19TVVBBQkFTRV9VUkwiLCJORVhUX1BVQkxJQ19TVVBBQkFTRV9LRVkiLCJzdXBhYmFzZSIsImdldFNlcnZpY2VTdXBhYmFzZSIsIlNVUEFCQVNFX1NFUlZJQ0VfS0VZIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./utils/supabase.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next"], () => (__webpack_exec__("(api)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Fportal&preferredRegion=&absolutePagePath=.%2Fpages%5Capi%5Cportal.js&middlewareConfigBase64=e30%3D!")));
module.exports = __webpack_exports__;

})();