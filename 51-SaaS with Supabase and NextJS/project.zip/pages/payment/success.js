const Success = () => {
    return <p>Payment successful</p>;
  };
  
  export default Success;