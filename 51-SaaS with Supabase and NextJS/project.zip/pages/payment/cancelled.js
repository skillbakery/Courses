const Cancelled = () => {
    return <p>Payment cancelled. You have not been charged!</p>;
  };
  
  export default Cancelled;