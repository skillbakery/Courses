cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/cordova-plugin-geolocation/www/android/geolocation.js",
        "id": "cordova-plugin-geolocation.geolocation",
        "clobbers": [
            "navigator.geolocation"
        ]
    },
    {
        "file": "plugins/cordova-plugin-geolocation/www/PositionError.js",
        "id": "cordova-plugin-geolocation.PositionError",
        "runs": true
    },
    {
        "file": "plugins/cordova-plugin-dialogs/www/notification.js",
        "id": "cordova-plugin-dialogs.notification",
        "merges": [
            "navigator.notification"
        ]
    },
    {
        "file": "plugins/cordova-plugin-dialogs/www/android/notification.js",
        "id": "cordova-plugin-dialogs.notification_android",
        "merges": [
            "navigator.notification"
        ]
    },
    {
        "file": "plugins/cordova-plugin-statusbar/www/statusbar.js",
        "id": "cordova-plugin-statusbar.statusbar",
        "clobbers": [
            "window.StatusBar"
        ]
    },
    {
        "file": "plugins/cordova-plugin-locationservices/www/Coordinates.js",
        "id": "cordova-plugin-locationservices.Coordinates",
        "clobbers": [
            "cordova.plugins.locationServices.Coordinates",
            "plugin.locationServices.Coordinates"
        ]
    },
    {
        "file": "plugins/cordova-plugin-locationservices/www/PositionError.js",
        "id": "cordova-plugin-locationservices.PositionError",
        "clobbers": [
            "cordova.plugins.locationServices.PositionError",
            "plugin.locationServices.PositionError"
        ]
    },
    {
        "file": "plugins/cordova-plugin-locationservices/www/Position.js",
        "id": "cordova-plugin-locationservices.Position",
        "clobbers": [
            "cordova.plugins.locationServices.PositionError",
            "plugin.locationServices.PositionError"
        ]
    },
    {
        "file": "plugins/cordova-plugin-locationservices/www/LocationServices.js",
        "id": "cordova-plugin-locationservices.LocationServices",
        "clobbers": [
            "cordova.plugins.locationServices.geolocation",
            "plugin.locationServices.geolocation"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-whitelist": "1.3.3",
    "cordova-plugin-compat": "1.2.0",
    "cordova-plugin-geolocation": "2.4.3",
    "cordova-plugin-dialogs": "1.3.4",
    "cordova-plugin-statusbar": "2.4.0",
    "cordova-plugin-locationservices": "2.1.0"
};
// BOTTOM OF METADATA
});