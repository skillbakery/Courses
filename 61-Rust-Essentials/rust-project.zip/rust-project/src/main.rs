#![allow(dead_code)]
#![allow(unused_variables)]
#![allow(warnings)]

use std::io;
use std::error;
use std::process;
use std::num::ParseIntError;

use std::sync::Arc;
use std::thread;

mod module;

//Exploring Macros
/*
//Macros are a way to extend the Rust language. They allow you to create new syntax and 
//abstractions that can be used in your code.
//Macros are defined using the `macro_rules!` keyword.
*/

//Understanding Option type in Rust
fn find_number(numbers: Vec<i32>, target: i32) -> Option<i32> {
    for num in numbers {
        if num == target {
            return Some(num); // We found the number
        }
    }
    None // The number was not found
}
fn get_user_age() -> Option<u32> {
    None  // No age provided, return None
}

//Understanding Box<dyn error::Error> in Rust
fn read_and_validate() -> Result<PositiveNonzeroInteger, Box<dyn error::Error>> {
    // Read input from stdin
    let mut line = String::new();
    io::stdin().read_line(&mut line)?;
    
    // Parse the input as an integer
    let num: i64 = line.trim().parse()?;
    
    // Create PositiveNonzeroInteger
    let answer = PositiveNonzeroInteger::new(num)?;
    
    Ok(answer)
}

#[derive(Debug)]
struct PositiveNonzeroInteger(i64);

impl PositiveNonzeroInteger {
    pub fn new(value: i64) -> Result<Self, String> {
        if value > 0 {
            Ok(PositiveNonzeroInteger(value))
        } else {
            Err(format!("{} is not a positive nonzero integer", value))
        }
    }
}

impl std::fmt::Display for PositiveNonzeroInteger {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.0)
    }
}

mod macros {
    #[macro_export]
    macro_rules! greet_macro {
        () => {
            println!("Hello, world!");
        };
        ($val:expr) =>{
            println!("Hello, {}!", $val);
        }
    }
    #[macro_export]
    macro_rules! param_macro {
        ($val:expr) =>{
            println!("Hello, {}!", $val);
        }
    }
}

pub fn total_cost(item_quantity: &str) -> Result<i32, ParseIntError> {
    let processing_fee = 1;
    let cost_per_item = 5;
    let qty = item_quantity.parse::<i32>()?;

    Ok(qty * cost_per_item + processing_fee)
}

fn main()-> Result<(), Box<dyn error::Error>> {

    module::run();
    /* Iterators in Rust */
    //Manually Calling .next()
    let numbers = vec![10, 20, 30];

    // Create an iterator for the vector using .iter().
    let mut iter = numbers.iter();
    
    for num in numbers.into_iter() {
        println!("{}", num);
    }

    // println!("{:?}", iter.next()); // Some(10)
    // println!("{:?}", iter.next()); // Some(20)
    // println!("{:?}", iter.next()); // Some(30)
    // println!("{:?}", iter.next()); // None (no more elements)

    let fruits = vec!["apple", "banana", "orange"];

    // Create an iterator and use it with a for loop
    for fruit in fruits.iter() {
        println!("I like {}!", fruit);
    }

    /*
    //Understanding ARC in Rust
    // Create an Arc that wraps a String, allowing it to be shared across threads.
    let greeting = Arc::new(String::from("Hello from multiple threads!"));

    // Create a vector to hold the thread handles.
    let mut handles = vec![];

    // Spawn 5 threads
    for i in 0..5 {
        // Clone the Arc for each thread (this increases the reference count).
        let greeting_clone = Arc::clone(&greeting);
        
        // Spawn a thread
        let handle = thread::spawn(move || {
            // Each thread can safely access the shared data.
            println!("Thread {}: {}", i, greeting_clone);
        });
        
        // Store the thread handle so we can wait for it later.
        handles.push(handle);
    }
    
    // Wait for all threads to finish.
    for handle in handles {
        handle.join().unwrap();
    }
    */
    
    // let numbers = vec![1, 2, 3, 4, 5];

    //  match find_number(numbers.clone(), 3) {
    //     Some(n) => println!("Found: {}", n),
    //     None => println!("Number not found"),
    // }

    // let age = get_user_age().unwrap_or(18); // Default age is 18 if None
    // println!("User's age is: {}", age);

    // match read_and_validate() {
    //     Ok(value) => {
    //         // Successfully obtained a PositiveNonzeroInteger
    //         println!("Valid positive integer: {}", value); //stdout
    //     }
    //     Err(e) => {
    //         // Handle the error
    //         eprintln!("Error: {}", e); //stderr
    //     }
    // }
    Ok(())

    // let mut connects = 100;
    // let pretend_user_input = "8";

    // let cost = total_cost(pretend_user_input)?;

    // if cost > connects {
    //     println!("You can't afford that many!");
    // } else {
    //     connects -= cost;
    //     println!("You now have {} connects.", connects);
    // }
    // Ok(())

    // match total_cost("10") {
    //     Ok(cost) => println!("Total cost is {}", cost),
    //     Err(e) => println!("Error calculating total cost: {}", e),
    // }

    /* Previous Code
        let name ="John".to_string();
        let lastname ="Doe".to_string() ;
        println!("{} {}",name,lastname);
        greet(&name,&lastname);
        greet(&name,&lastname);
        read input from user
        println!("Please enter your name: ");
        let mut student_name = String::new();
        io::stdin().read_line(&mut student_name).unwrap();
        println!("Hello, {}",student_name);
    */

    /*
    loop {
        println!("Please enter a first number");
        let num_one = read_user_input();
        println!("Please enter a second number");
        let num_two = read_user_input();
        //let result = sum(first_number,second_number);
        let result = sum(num_one,num_two);
        println!("The sum is: {}",result);
    }
    */

    //Type Inference
    /*
        let condition = true;
        let some_number = 10;
        let string_number = "10";
        let names = ["John", "May", "Sandy"];
        let number = string_number.parse::<u32>().unwrap();
    */

    /* Integer Types
        // Unsigned integer types:
        
        // u8:  0 to 2^8  (255)
        // u16: 0 to 2^16 (65,535)
        // u32: 0 to 2^32 (4,294,967,295)
        // u64: 0 to 2^64 (really big number)
        // usize: 0 to 2^32-1 or 2^64-1 


        // Signed integer types:
        
        // i8:  -2^7 to 2^7-1  (-128 to 127)
        // i16: -2^15 to 2^15-1 (-32,768 to 32,767)
        // i32: -2^31 to 2^31-1 (super negative to super positive)
        // i64: -2^63 to 2^63-1 (you get the idea)
        // isize: -2^31-1 or -2^63-1 to 2^31-1 or 2^63-1
        let number = 256;
    */

    /* Floating-Point types
        //
        // f32: -3.4 * 10^38 to +3.4 * 38
        // f64: -1.8 * 10^308 to +1.8 *10^308

        let f = -1.2345;

        let f2 = 2.;

        let f3 = 0.42;

        let f4 = 2e4;

        let f5 = 32f32;

        let f6 = 230.452e-29f64;
    */

    /*Boolean Type
        let wish_hello = false; //true, false;
        if wish_hello {
            println!("Hello");
        } else {
            println!("Goodbye");
        }
    */

    /*Char Type
        let char1 = '1';
        let char2 = 'a';
        
        let char3 = '🤯';
        
        let char4 = '\\';
        let char5 = '\'';
        let char6 = '\n';
        let char7 = '\r';
        let char8 = '\t';
        
        println!("{} {}", char3, char1);
    */

    /*Tuples 
        let mut point = ("A",32,34); // &str, i32,i32
        println!("Point {}: {} {}", point.0, point.1,point.2);

        point.0 = "B";
        //point.0 = 67;
        println!("Point {}: {} {}", point.0, point.1,point.2);

        let text = "Hello World!";
        let (head,tail) = text.split_at(5);
        println!("{} {}", head,tail);

        let single = ("A",); 
        println!("{}",single.0);
    */

    /*Unit Type
        //hello_world();
    */

    /*Reference Types
        let x = 10; //i32
        let y = &x; //&i32

        let name = String::from("Skillbakery"); //String
        let name_ref = &name; //&String
        say_hello(&name_ref);
        println!("Hello {}!",&name_ref);
    */
    //Arrays
    /*
        let names = ["James","Dave"];
        let numbers:[i8;4] = [1,2,3,4];
        
        let kilobyte = [0u8;1024];

        for name in &names {
            println!(" {} ", name);
        }
        for num in &numbers {
            println!(" {} ", num);
        }
    */
    //Vectors
    /*
        let vec_num =vec![1,2,3,4];
        
        let mut vec_num2 = Vec::new();
        vec_num2.push(5);
        vec_num2.push(6);

        for num in &vec_num2 {
            println!(" {} ", num);
        }
    */
    /*
    let messages = [
            Message::Move{x:10,y:10},
            Message::Echo(String::from("Hello World!!")),
            Message::ChangeColor(200,255,200),
            Message::Quit
    ];
    for message in &messages{
        message.call();
    }
    */

    /*println!("fav food {} and veggies {} ", fav_food::fruit, fav_food::veggie);*/
    // greet_macro!();
    // param_macro!(" Macro");
    // param_macro!(123456);

    // let name = String::from("John");
    // let empty_name = String::from("");

    // match generate_nametag(name) {
    //     Ok(nametag) => println!("{}", nametag),
    //     Err(error) => println!("Error: {}", error),
    // }
    // match generate_nametag(empty_name) {
    //    Ok(nametag) => println!("{}", nametag),
    //     Err(error) => println!("Error: {}", error),
    // }

}

//structs in rust
//1. Classic struct
struct ColorClassicStruct{
    name:String,
    hex:String,
}
//2. Tuple struct
struct ColorTupleStruct(String,String);

//3. Unit struct
#[derive(Debug)]
struct UnitStruct;

//enums in rust
#[derive(Debug)]
enum Message{
    Quit,
    Move {x:u32,y:u32},
    Echo (String),
    ChangeColor(u8,u8,u8)
}

struct Point {
    x:u32,
    y:u32
}
struct State{
    color: (u8, u8, u8),
    position: Point,
    quit: bool,
}

impl State {
    fn change_color(&mut self, color: (u8, u8, u8)) {
        self.color = color;
    }

    fn quit(&mut self) {
        self.quit = true;
    }

    fn move_position(&mut self, p: Point) {
        self.position = p;
    }

    fn echo(&self, s: String) {
        println!("{}", s);
    }

    fn process(&mut self, message: Message) {
        match message {
            Message::Quit => self.quit(),
            Message::Move { x, y } => self.move_position(Point { x, y }),
            Message::Echo(s) => self.echo(s),
            Message::ChangeColor(r, g, b) => self.change_color((r, g,b))
        }
    }

}

impl Message {
    fn call(&self) {
        println!("{:?}", &self);
    }
}

//Nested Modules and Constants
mod fav_food {
    pub use self::fruits::Apple as fruit;
    pub use self::veggies::Onion as veggie;

    mod fruits{
        pub const Apple:&'static str="Apple";
        pub const Orange:&'static str="Orange";
    }

    mod veggies {
        pub const Onion:&'static str="Onion";
        pub const Carrot:&'static str="Carrot";
    }
}

// Err, Ok and Result
pub fn generate_nametag(name: String) -> Result<String,String> {
    if name.len() > 0 {
        Ok(format!("Hi My name is {}", name))
    } else {
        Err(String::from("`name` was empty; it must be nonempty."))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    
    #[test]
    fn classic_c_structs(){
        let green = ColorClassicStruct {
            name: String::from("green"),
            hex: String::from("#00ff00"),
        };

        assert_eq!(green.name,"green");
        assert_eq!(green.hex,"#00ff00");
    }

    #[test]
    fn tuple_c_structs(){
        let green = ColorTupleStruct(String::from("green"),String::from("#00ff00"));
        assert_eq!(green.0,"green");
        assert_eq!(green.1,"#00ff00");
    }

    #[test]
    fn unit_c_structs(){
        let unit_struct = UnitStruct;
        let message = format!("{:?}s are fun",unit_struct);
        assert_eq!(message,"UnitStructs are fun");
    }

    #[test]
    fn slice_out_of_array() {
        let a = [1, 2, 3, 4, 5];
    
        let nice_slice = &a[1..4];
    
        assert_eq!([2, 3, 4], nice_slice)
    }

    #[test]
    fn enum_test(){
        let messages = [
            Message::Move{x:10,y:10},
            Message::Echo(String::from("Hello World!!")),
            Message::ChangeColor(200,255,200),
            Message::Quit
        ];
        for message in &messages{
            message.call();
        }
        // println!("{:?}",Message::Quit);
        // println!("{:?}",Message::Move);
        // println!("{:?}",Message::Echo);
        // println!("{:?}",Message::ChangeColor);
    }
    
    #[test]
    fn test_match_message_call() {
        let mut state = State {
            quit: false,
            position: Point { x: 0, y: 0 },
            color: (0, 0, 0),
        };

        state.process(Message::ChangeColor(255, 0, 255));
        state.process(Message::Echo(String::from("hello world")));
        state.process(Message::Move { x: 10, y: 15 });
        state.process(Message::Quit);

        assert_eq!(state.color, (255, 0, 255));
        assert_eq!(state.position.x, 10);
        assert_eq!(state.position.y, 15);
        assert_eq!(state.quit, true);
    }
}

fn say_hello(name: &String){
    println!("Hello {}!",name);
}

fn hello_world() {
    let hello = "Hello World!";
    println!("{}",hello);
    //hello
}

fn read_user_input() -> u32 {
    let mut input = String::new();
    io::stdin().read_line(&mut input).unwrap();
    //let first_number: u32 = first_number.trim().parse().expect("This is not a valid number");
    let digit:u32;
    match input.trim().parse() {
        Ok(num) => digit = num,
        Err(_err) => {
            println!("Please type a number!");
            process::exit(1);
        }
    }
    digit
}

fn sum(x:u32,y:u32) -> u32 {
    x+y
}

fn greet(first: &String,last: &String){
    println!("Hello {} {}",first,last);
}