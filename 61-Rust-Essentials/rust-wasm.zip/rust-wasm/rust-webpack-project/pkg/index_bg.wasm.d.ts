/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function __wbg_color_free(a: number, b: number): void;
export function __wbg_image_free(a: number, b: number): void;
export function image_new(): number;
export function image_pixels_ptr(a: number): number;
export function get_date_parts(a: number): void;
export function main_js(): void;
export function __wbindgen_add_to_stack_pointer(a: number): number;
export function __wbindgen_free(a: number, b: number, c: number): void;
export function __wbindgen_start(): void;
