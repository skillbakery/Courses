/* tslint:disable */
/* eslint-disable */
/**
* @returns {string}
*/
export function get_date_parts(): string;
/**
*/
export function main_js(): void;
/**
*/
export class Color {
  free(): void;
}
/**
*/
export class Image {
  free(): void;
/**
*/
  constructor();
/**
* @returns {number}
*/
  pixels_ptr(): number;
}
