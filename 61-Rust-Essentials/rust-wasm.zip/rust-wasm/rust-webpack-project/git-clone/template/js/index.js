import("../pkg/index.js").catch(console.error);
