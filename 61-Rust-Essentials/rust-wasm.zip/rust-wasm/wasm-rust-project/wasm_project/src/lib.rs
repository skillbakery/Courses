use wasm_bindgen::prelude::*;

#[wasm_bindgen]
pub fn greet(name: &str) -> String {
    format!("Hello, {}!", name)
}

#[wasm_bindgen]
extern "C" {
    fn js_function(input: &str) -> String;
}

#[wasm_bindgen]
pub fn invoke_js_function(name: &str) ->String{
    let result = js_function(name);
    format!("Javascript says: {}",result)
}