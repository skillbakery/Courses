/** @type {import('next').NextConfig} */
import graphqlLoader from 'graphql-tag/loader.js';

const nextConfig = {
  webpack: (config, { isServer }) => {
    // Add support for loading .graphql files
    config.module.rules.push({
      test: /\.(graphql|gql)$/,
      exclude: /node_modules/,
      use: [
        {
          loader: 'graphql-tag/loader',
        },
      ],
    });

    return config;
  },
};
export default nextConfig;
