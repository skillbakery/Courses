
export default function SuccessPage() {
    return (
      <div>
        <h1>Success</h1>
        <p>
          Thank you for your order. You will receive an email confirmation shortly.
        </p>
      </div>
    );
  }
  