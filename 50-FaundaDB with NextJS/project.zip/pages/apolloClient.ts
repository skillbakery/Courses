import { ApolloClient, InMemoryCache, gql, NormalizedCacheObject,HttpLink  } from '@apollo/client';
import {GetAllShops,GetAllProducts,GetShopsByOwner} from '../schema.graphql'

const link = new HttpLink({ 
  uri: `${process.env.NEXT_PUBLIC_API_BASE_URL}/api/faunaHandler`,
  useGETForQueries: true,
});

const client: ApolloClient<NormalizedCacheObject> = new ApolloClient({
  //uri: './api/faunaHandler', // Your serverless GraphQL endpoint
  link,
  cache: new InMemoryCache(),
});

// Define the GraphQL query for fetching all shops
// const GET_ALL_SHOPS = gql`
//   query GetAllShops($collectionName: String!) {
//     getAllShops(collectionName: $collectionName) {
//       name
//       description
//       coverImg
//       products {
//         name
//         description
//         price
//       }
//       ownerId
//     }
//   }
// `;

export const fetchAllShops = async (client: ApolloClient<NormalizedCacheObject>, collectionName: string) => {
  try {
    const response = await client.query({
      query: GetAllShops,
      variables: { collectionName },
      fetchPolicy: 'no-cache', // Optional: Set fetch policy
    });
    // Return the data
    return response.data;
  } catch (error) {
    console.error('Error fetching all shops:', error);
    throw new Error('Failed to fetch all shops');
  }
};
export const fetchShopsByOwnerId = async (client: ApolloClient<NormalizedCacheObject>, collectionName: string,ownerID:string) => {
  try {
    const response = await client.query({
      query: GetShopsByOwner,
      variables: { collectionName,ownerID },
      fetchPolicy: 'no-cache', // Optional: Set fetch policy
    });
    // Return the data
    return response.data;
  } catch (error) {
    console.error('Error fetching all shops:', error);
    throw new Error('Failed to fetch all shops');
  }
};
export const fetchAllProducts = async (client: ApolloClient<NormalizedCacheObject>, collectionName: string) => {
  try {
    const response = await client.query({
      query: GetAllProducts,
      variables: { collectionName },
      fetchPolicy: 'no-cache', // Optional: Set fetch policy
    });
    // Return the data
    console.log(response.data);
    
    const productDetails = response.data.map(item => {
      return {
          name: item.data.name,
          description: item.data.description,
          price: item.data.price,
          _id:item.ref['@ref'].id
      };
    });
    return productDetails;
  } catch (error) {
    console.error('Error fetching all shops:', error);
    throw new Error('Failed to fetch all shops');
  }
};
export default client;