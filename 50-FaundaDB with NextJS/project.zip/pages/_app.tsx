import '../styles/globals.css'
import { ApolloProvider } from '@apollo/client';
import client from './apolloClient';
import { AppProps } from 'next/app';
import Nav from '../components/Nav'
import { UserProvider } from '@auth0/nextjs-auth0/client';
import { Provider } from '../context'

function MyApp({ Component, pageProps }: AppProps) {
  return (
    <Provider>
    <UserProvider>
    <ApolloProvider client={client}>
      <Nav/>
      <Component {...pageProps} />
    </ApolloProvider>
    </UserProvider>
    </Provider>
  );
}

export default MyApp;