import NewShopForm from "../components/NewShopForm";
import { useApolloClient } from '@apollo/client';
import { fetchShopsByOwnerId } from './apolloClient';

import { useEffect, useState } from 'react';
import { useUser } from '@auth0/nextjs-auth0/client';
import ShopList from "../components/ShopList";

export default function ManageShops() {
  const apolloClient = useApolloClient();
  const { user } = useUser();
  const [shopData, setShopData] = useState<any>(null);

  useEffect(() => {
    const getShopByOwnerData = async () => {
      try {
        const collectionName = 'Shop'; // Pass your collection name here
        console.log(user?.sub);
        const shops = await fetchShopsByOwnerId(apolloClient, collectionName,user?.sub);
       
        console.log('All shops:', shops);
        // Extract the "data" field from each item in the response array
        //const shopDataArray = shops.map(shop => shop.data);
        const shopDataArray = shops.map(shop => ({
          ...shop.data,
          _id: shop.ref['@ref'].id
        }));
        // Set the shop data in the state
        setShopData(shopDataArray);
      } catch (error) {
        console.error('Error:', error);
      }
    };
    getShopByOwnerData();
  }, [apolloClient,user]);

  return (<>
  <NewShopForm />
  {
    shopData ?(
      <ShopList shops={shopData}/>
    ) : <div>Loading...</div>
  }
  </>)
}