import Image from "next/image";
import { useEffect, useState } from 'react';
import { useApolloClient } from '@apollo/client';
import { fetchAllShops,fetchAllProducts } from './apolloClient';
import ProductList from '../components/ProductList'

export default function Home() {
  const apolloClient = useApolloClient();
  const [shopData, setShopData] = useState<any>(null); // Change `any` to a more specific type if possible
  const [productData, setProductData] = useState<any>(null); 
  useEffect(() => {
    const getAllShopsData = async () => {
      try {
        const collectionName = 'Shop'; // Pass your collection name here
        const shops = await fetchAllShops(apolloClient, collectionName);
       
        console.log('All shops:', shops);
        // Extract the "data" field from each item in the response array
        //const shopDataArray = shops.map(shop => shop.data);
        const shopDataArray = shops.map(shop => ({
          ...shop.data,
          _id: shop.ref['@ref'].id
        }));
        // Set the shop data in the state
        setShopData(shopDataArray);
      } catch (error) {
        console.error('Error:', error);
      }
    };

    const getAllProductsData = async () => {
      try {
        const collectionName = 'Product'; // Pass your collection name here
        const products = await fetchAllProducts(apolloClient, collectionName);
       
        console.log('All products:', products);
        // Set the shop data in the state
        setProductData(products);
      } catch (error) {
        console.error('Error:', error);
      }
    };

    getAllShopsData();
    getAllProductsData();
  }, [apolloClient]);

  return (
    <div>
      <h1>Shop Data</h1>
      {shopData ? (
        <ul>
          {shopData.map((shop: any, index: number) => (
            <li key={index}>
              <h2>{shop.name}</h2>
              <p>Description: {shop.description}</p>
              <p>Owner ID: {shop.ownerId}</p>
              {/* Render other shop details as needed */}
            </li>
          ))}
        </ul>
      ) : (
        <p>Loading...</p>
      )}

      {productData ? (
         <ProductList products={productData} />
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
}