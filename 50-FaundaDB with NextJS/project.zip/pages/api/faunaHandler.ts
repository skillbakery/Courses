import { NextApiRequest, NextApiResponse } from 'next';
import faunadb, { query as q } from 'faunadb';

// Initialize FaunaDB Client
const client = new faunadb.Client({
  secret: process.env.NEXT_PUBLIC_FAUNA_KEY,
  domain: process.env.NEXT_PUBLIC_FAUNA_DOMAIN, // Change this to your region's domain
});

// FaunaDB handler function
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  console.log('faunaHandler called'); // Log when the handler is called
  
    try {
        if (req.method === 'GET') {
          let variables = req.query.variables;
          let result;
          if (Array.isArray(variables)) {
              // If it's an array, join the elements into a single string
              variables = variables.join('');
          }
          const parsedVariables = JSON.parse(variables || '{}');
          const { collectionName, ownerID, shopId } = parsedVariables; 
          // Retrieve documents from the Shop collection
          if (shopId) {
            console.log(shopId);
            // Query products by the given shop ID
            result = await client.query(
              q.Map(
                q.Paginate(q.Match(q.Index('products_by_shop'), shopId)),
                q.Lambda('X', q.Get(q.Var('X')))
              )
            );
          }
          else
          {
            result = await client.query(
              q.Map(
                ownerID ? q.Paginate(q.Match(q.Index('shopByOwner'), ownerID)) : q.Paginate(q.Documents(q.Collection(collectionName))),
                q.Lambda('X', q.Get(q.Var('X')))
              )
            );
          }
           
          res.status(200).json(result);
        } 
        if (req.method === 'POST') {
          try {
            console.log(req.body);
            if(req.body.operationName==='CreateShop'){
              const shop = await client.query(
              q.Create(q.Collection('Shop'), { data: { 
                name: req.body.variables.name,
                description: req.body.variables.description,
                coverImg:req.body.variables.coverImg,
                ownerId:req.body.variables.ownerId,
              } })
              );
              res.status(200).json(shop);
            }
            else if (req.body.operationName === 'CreateProduct') {
              const product = await client.query(
                q.Create(q.Collection('Product'), { data: { 
                  name: req.body.variables.name,
                  description: req.body.variables.description,
                  imageUrl:req.body.variables.imageUrl,
                  category:req.body.variables.category,
                  price: req.body.variables.price,
                  shopId: req.body.variables.shopID,
                } })
                );
                res.status(200).json(product);
            }
            else if (req.body.operationName === 'deleteShop') {
              const result = await client.query(
                q.Call(q.Function("deleteShop"), [req.body.variables.shopId])
              );
              // Wrapping the result in the specified format
                const formattedResult = {
                  data: {
                    data: result  // This static value can be replaced or extended with actual data if needed
                  }
                };
                res.status(200).json(formattedResult);
            }
          } catch (error) {
            res.status(500).json({ error: error });
          }
        }
        else {
          res.status(405).end(); // Method Not Allowed
        }
      } catch (error) {
        console.error('FaunaDB Error:', error);
        res.status(500).json({ error: 'An internal server error occurred' });
      }
}