import { useRouter } from 'next/router';
import NewProduct from '../../../components/NewProduct';

export default function ProductsPage(props: any) {
  
  const router = useRouter();
  const { id } = router.query;
 
  return(
    <div>
      <NewProduct shopId={id} />
    </div>
  )
}