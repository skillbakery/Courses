import { useRouter } from 'next/router';
import { gql } from '@apollo/client/core';
import { useQuery } from '@apollo/client';

const GET_SHOP_BY_ID = gql`
  query GetShop($shopId: ID!) {
    findShopByID(id: $shopId) {
      _id
      name
      description
      products {
        data {
          _id
          name
        }
      }
    }
  }
`

export default function Details() {
  const router = useRouter();
  const { id } = router.query;

  const { data: queryData, loading } = useQuery(
    GET_SHOP_BY_ID,
    {
      variables: { shopId: id }
    }
  )

  if(loading) {
    return <div>loading...</div>
  }
 // Make sure you access the nested data correctly and check its existence
 console.log(queryData);

  return (
    <div className="p-16">
      {
        queryData.map((product,index) => (
          <div key={index} className="rounded-lg bg-white shadow mb-1">
            <ul className="divide-y divide-gray-100">
              <li className="flex justify-between p-3">
                <div>
                  <p>{product.data.name}</p>
                </div>
                <div>
                  <button className="mr-2 underline pointer">Edit</button>
                  <button className="ml-1 underline pointer">Delete</button>
                </div>
              </li>
            </ul>
          </div>
        ))
      }
    </div>
  )
}