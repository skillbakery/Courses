export default function Canceled() {
    return (
      <div>
        <h1>Order Canceled</h1>
      </div>
    );
  }