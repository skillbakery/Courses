def main():
    tup=(2,4,6,8,10,45)
    varargs(*tup)

def varargs(*args):
    if len(args):
        for a in args:
            print(a)
    else: print('None')

if __name__ == '__main__':main()
