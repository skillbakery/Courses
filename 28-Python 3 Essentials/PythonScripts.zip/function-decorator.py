def greet(f):
    def decorator():
        print("Hi From Decorator")
        f()
        print("Bye from Decorator")
    return decorator

@greet
def demo():
    print("Hi from demo")

#demo=greet(demo)
demo()
