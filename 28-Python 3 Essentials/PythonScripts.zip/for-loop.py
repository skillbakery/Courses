for i in range(0,10):
    print(f'for loop {i}')

tup = (1,2,3,4,5)
for t in tup:
    print(f't is {t}')