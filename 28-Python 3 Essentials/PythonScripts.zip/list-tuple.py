num = [1,2,3,4,5]
num[0]=10
for i in num:
    print(f'i is {i}')

tup = (1,2,3,4,5)
#tup[0]=7
for t in tup:
    print(f't is {t}')

ran = list(range(1,10,2))
ran[0]=8
for r in ran:
    print(f'r is {r}')

dict = {'a':1,'b':2,'c':3}
dict['c']=5
for key,val in dict.items():
    print(f'key:{key} val:{val}')