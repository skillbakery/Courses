a=10
b=20
c=2345434
d=74854.2546
print('The numbers are {} {}'.format(a,b))
print('The numbers are {0} {1} {0}'.format(a,b))
print('The numbers are {a} {b}'.format(a=a,b=b))
print('The numbers are {:,}'.format(c))
print('The numbers are {:.3f}'.format(d))

print(f'The numbers are {d:.3f}') 