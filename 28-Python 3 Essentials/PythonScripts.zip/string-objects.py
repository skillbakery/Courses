class RevString(str):
	def __str__(self):
	    return self[::-1]

s=RevString('Hi There')
print(s)
print(s.upper())
print(s.swapcase())
print(f'{s} {10*2}')