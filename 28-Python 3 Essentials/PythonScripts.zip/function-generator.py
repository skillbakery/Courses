def main():
    for i in generate_even(20):
        print(i)

def generate_even(range):
    i=1
    while i <= range:
        if i%2==0:
            yield i
        i=i+1

if __name__=='__main__':main()