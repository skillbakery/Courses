i = (1,2,3,4,5,6)
j = i
k = reversed(i)
l = list(k)
m = len(l)
result = sum(l)
maxR = max(l)
minR = min(l)

print(i)
print(j)
print(k)
print(l)

print(m)
print(result)
print(maxR)
print(minR)

resultSet = (0,0,0)
print(all(resultSet))

a = (1,2,3)
b = (4,5,6)
z = zip(a,b)
for a,b in z: print(f'{a}-{b}')
enum = ('A','B','C')
for i,v in enumerate(enum): print(f'{i}:{v}')