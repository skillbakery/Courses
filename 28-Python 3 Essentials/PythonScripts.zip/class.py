#class and objects in python
class Student:
    name=""
    address=""

    def getName(self):
        print(self.name)
    
    def getAddress(self):
        print(self.address)

def main():
    student = Student()
    student.name="John"
    student.address="USA"
    student.getName()
    student.getAddress()

if __name__ =='__main__':main()