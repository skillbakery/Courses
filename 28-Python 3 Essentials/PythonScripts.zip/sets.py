def main():
    x = set("apple")
    y = set("mango")
    print_set(x)
    print_set(y)
    print_set(x-y) #data in set x not in set y
    print_set(x|y) #data in set x or in set y
    print_set(x^y) #Exclusive or set x and y but not both
    print_set(x&y) # in both sets

def print_set(obj):
    print('[', end='')
    for x in obj:
        print(x, end='')
    print(']')

if __name__ == '__main__':main()