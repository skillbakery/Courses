import platform
msg="Hello World {}".format("20")
x=50
print(msg)
print(platform.python_version()) 
print(f'{msg} {x}')
#Expressions and Statement

#Expression is any combination of literals, operators and identifiers
#Anything that returns a value can be treated as an expression in Python
# x=y, (x,y) f(), x, x*y

#Statement is a line of code it may be an expression
# break, or import statement
# does not require semi colon at the end 