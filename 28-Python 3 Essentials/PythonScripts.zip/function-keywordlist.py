def main():
    d = dict(fruit='apple',vegetable='Onion')
    varargs(**d)

def varargs(**kwargs):
    if len(kwargs):
        for a in kwargs:
            print(f'{a} {kwargs[a]}')
    else: print('None')

if __name__ == '__main__':main()
