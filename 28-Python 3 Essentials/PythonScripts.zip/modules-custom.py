import age
def main():
    age.age.getage(1983)

if __name__=='__main__':main()