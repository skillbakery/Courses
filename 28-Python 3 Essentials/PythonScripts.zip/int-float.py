from decimal import *


x=10
print(f'x is {x} {type(x)}')

y=10.0
print(f'y is {y} {type(y)}')

result = 22/7
print(f'result is {result} {type(result)}')

result = 8%3
print(f'result is {result} {type(result)}')

num = Decimal('.10')
print(f'result is {num} {type(num)}')