i=0
while(i < 10):
    print(i)
    i+=1

for i in range(0,10):
    print(f'for loop {i}')