i = 0x0a
j = 0x02
k = i >> j

print(f'(hex) i is {i:02x}, j is {j:02x}, k is {k:02x}')
print(f'(binary) i is {i:08b}, j is {j:08b}, k is {k:08b}')