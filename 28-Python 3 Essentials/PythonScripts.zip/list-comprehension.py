num = range(20)
even = [x for x in num if x%2==0]
dict = {x:x*2 for x in num }
for i in even:
    print(f'i is {i}')

for key,val in dict.items():
    print(f'key:{key} val:{val}')

# for i in num:
#     print(f'i is {i}')