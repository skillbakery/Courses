def main():
    src=open('python.png','rb')
    copy = open('python-copy.png','wb')
    while True:
        buf=src.read(10240)
        if buf:
            copy.write(buf)
            print('.',end='',flush=True)
        else: break
    copy.close()
    print('done')

if __name__ == '__main__': main()