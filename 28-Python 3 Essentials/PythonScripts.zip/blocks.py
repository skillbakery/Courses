import platform

x=10
def main():
    temp = greet()
    print(temp)

def greet(n=10):
    print(f"Hello World! {n}")
    print("Hi")
    if False:
        print("True")
    else:
        print("False")
    return n


if True:
    y=20
    print("True")




    print("This is true")
else:
    print("False")

print("Value of Y is {}".format(y))
main()