s='Hello World! Learning Python one chapter daily'
print(s.split('!'))
print(s.split())

strlst = s.split()
csv = ','.join(strlst)
print(csv)