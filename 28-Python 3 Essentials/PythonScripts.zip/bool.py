b=True
print(f'b is {b} {type(b)}')

result = 10>6
print(f'result is {b} {type(result)}')

x=1
if x:
    print("True")
else:
    print("False")

result = None
if result:
    print("True")
else:
    print("False")

x="x"
if x:
    print("True")
else:
    print("False")