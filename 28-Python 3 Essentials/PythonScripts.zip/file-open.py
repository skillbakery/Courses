def main():
    f = open('file-sample.txt') 
    #default is readonly 'w' for write mode, r for read, a for append
    #optinal + to make it rw for e.g. r+ (read and write)
    #t for text and b for binary mode - default is text mode
    for line in f:
        print(line.rstrip())

if __name__ == '__main__':main()