def main():
    x=[9]
    y=x
    #y[0]=5
    #print(f"Hi {x}")
    #print(f"Hi {y}")
    print(id(x))
    greet(x)
    print(f"Hi {x}")

def greet(n,o=0,p=1):
    n[0]=2
    print(id(n))
    print(f"Hi {n}")

if __name__ == '__main__':main()