num = [1,2,3,4,5]

for i in num:
    print(f'i is {i}')

#print selected
print(f'{num[1:4:2]}')
#search
pos = num.index(3)
print(f'Index position {pos}')
#append
num.append(6)
#insert
num.insert(3,7)
#remove
#num.remove(7)
#remove from end
#num.pop()
#remove from an index
#num.pop(2)
#del num[3]
#del num[1:3]
#join
print(', '.join(str(num)))
#count
print(len(num))
for i in num:
    print(f'i is {i}')


tup = (1,2,3,4,5)

for t in tup:
    print(f't is {t}')