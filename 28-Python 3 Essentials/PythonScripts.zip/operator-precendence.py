x = 2 + (3*5)
print(x)