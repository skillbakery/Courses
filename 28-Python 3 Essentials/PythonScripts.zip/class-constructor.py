class Person:
    def __init__(self,**kwargs):
        self.height=kwargs['height']
        self.age=kwargs['age']
        self.gender=kwargs['gender']

class Student(Person):
    listItem = [1,2,3]
    def __init__(self,**kwargs):
        self.name = kwargs['name'] if 'name' in kwargs else 'Matt'
        self.address = kwargs['address']
        super().__init__(**kwargs)

    def getName(self):
        print(self.name)
    
    def getAddress(self):
        print(self.address)

    def __str__(self): 
        return f'The student name is {self.name} and address is {self.address} and age is {self.age}'

def main():
    student = Student(name="John",address="USA",height="6ft",age=24,gender="male")
    student2 =  Student(name="Matt",address="USA",height="5ft",age=20,gender="male")
    #student.getName()
    #student.getAddress()
    student.listItem[0]=5
    print(student2.listItem)
    print(student)
    print(student2)

if __name__ =='__main__':main()