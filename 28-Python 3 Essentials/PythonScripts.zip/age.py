import datetime
class age():
    def getage(year):
        a = datetime.datetime.now().year - year
        print(a)