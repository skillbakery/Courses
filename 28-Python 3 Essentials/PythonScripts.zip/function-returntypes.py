def main():
    x=greet()
    print(type(x),x)

def greet():
    print('Hello')
    #return (1,2,3,4)

if __name__=='__main__':main()