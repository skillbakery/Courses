x=True
y='Print when True' if x else None
print(y)