def main():
    src=open('file-sample.txt','rt')
    copy = open('file-sample-copy.txt','wt')
    for line in src:
        print(line.rstrip(),file = copy)
        print('.',end='',flush=True)
    copy.close()
    print('done')

if __name__ == '__main__': main()