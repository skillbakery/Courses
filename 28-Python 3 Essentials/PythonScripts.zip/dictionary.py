#dict = {'a':1,'b':2,'c':3}
#or
dict = dict(a='1',b='2',c='3')
#keys are immutable but the values are not
dict['c']=5

for key,val in dict.items():
    print(f'key:{key} val:{val}')

for key in dict.keys():
    print(f'key:{key}')

for val in dict.values():
    print(f'val:{val}')

#search
print('a' in dict)
x=dict.get('a')
print(x)