import sqlite3

def main():
    print('Connecting to SQLLite Server')
    db = sqlite3.connect('pydb.db')
    cur = db.cursor()
    print('Create DB')
    cur.execute("DROP TABLE IF EXISTS user")
    cur.execute(""" CREATE TABLE user (id INTEGER PRIMARY KEY,firstname string,lastname string)""")
    print("Insert Records")
    cur.execute(""" INSERT INTO user (firstname,lastname) VALUES ('JOHN','DOE')""")
    print("Commit")
    db.commit()
    print("Total Rec Count")
    cur.execute("Select count(*) from user")
    count = cur.fetchone()[0]
    print(count)
    print('Select')
    for row in cur.execute("Select * from user"):
        print(row)
    print('drop')
    cur.execute("DROP TABLE user")
    db.close()

if __name__ =='__main__':main()

