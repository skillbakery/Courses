s='Hi There'
su = s.upper()

print(s)
print(s.capitalize())
print(s.upper())
print(s.lower())
print(s.title())
print(s.swapcase())
print(s.casefold()) 
#much aggresive than lower, 
#works on utf-8 as well and converts special char to lower case strings.
print(id(su))
print(id(s))
#concatenation
print(s+" "+su)