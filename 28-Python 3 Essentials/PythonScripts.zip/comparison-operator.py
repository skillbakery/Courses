x=10
y=5

if x != y:
    print('Yes X != Y')
else:
    print('Y is greater than X')