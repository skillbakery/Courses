x=10
y=10
# if, else elif
if x > y:
    print(f'x is greater than y x is {x} and y is {y}')
elif x < y:
    print(f'x is less than y x is {x} and y is {y}')
# elif x==y:
#     print(f'x is equal to y x is {x} and y is {y}')
else:
    print('some thing else')