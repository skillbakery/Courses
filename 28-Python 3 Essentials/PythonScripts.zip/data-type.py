x=10
print(f'x is {x} {type(x)}')

y=10.0
print(f'y is {y} {type(y)}')

n='Hello World'
print(f'n is {n} {type(n)}')

b=True
print(f'b is {b} {type(b)}')

z=None
print(f'z is {z} {type(z)}')