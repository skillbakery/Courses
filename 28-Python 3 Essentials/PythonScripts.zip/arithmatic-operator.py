x=10
y=5

result = x/y

x= -x
y= +y

print(f'result is {x}')
print(f'result is {y}')

print(f'result is {result}')
