import sys

def main():
    try:
        x=15
    except ValueError:
        print('Value Error Exception occurred')
    except:
        print(f'Exception Occurred : {sys.exc_info()[1]}')
    else:
        print('Execution Complete')

if __name__ =='__main__':main()
