x = '10'
y = int(x)

print(f'x is {type(x)}')
print(f'x is {x}')
print(f'y is {type(y)}')
print(f'y is {y}')

a = '10.0'
b = float(a)

print(f'a is {type(a)}')
print(f'a is {a}')
print(f'b is {type(b)}')
print(f'b is {b}')

d = -47
e = abs(d)

print(f'd is {type(d)}')
print(f'd is {d}')
print(f'e is {type(e)}')
print(f'e is {e}')

result = divmod(y,3)
print(f'e is {type(result)}')
print(f'e is {result}')