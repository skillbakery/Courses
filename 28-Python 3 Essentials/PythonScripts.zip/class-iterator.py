class inclusive_range:
    def __init__(self,*args):
        numargs=len(args)
        self._start=0
        self._step=1

        if numargs < 1:
            raise TypeError(f'At least 1 argument is required')
        elif numargs == 1:
            self._stop=args[0]

        self._next = self._start

    def __iter__(self):
        return self
    def __next__(self):
        if self._next > self._stop:
            raise StopIteration
        else:
            _r=self._next
            self._next += self._step
            return _r
def main():
    try:
        for n in inclusive_range(25):
            print(n,end=' ')
        print()
    except TypeError as e:
        print(f'Argument Missing')

if __name__ == '__main__' : main()