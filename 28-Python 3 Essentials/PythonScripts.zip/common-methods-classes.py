x = 42
y = type(x)

print(x)
print(y)

r=isinstance(x,int)
print(r)

print(id(x))