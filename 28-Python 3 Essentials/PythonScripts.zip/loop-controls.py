pwd='random'
inp=''
valid = False
count = 0
max_allowed = 3


while inp!=pwd:
    count = count+1
    if count > max_allowed: break
    if count ==2: continue
    inp = input(f"{count}:Enter Password")
else:
    valid = True

print ("Access Granted " if valid else "Access Denied")
    