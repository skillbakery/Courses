x=True
y=False
collection = ('Apple','Orange','Grapes','Mango')
fruit = 'Mango'

if fruit is not collection[0]:
    print('True')
else:
    print('False')