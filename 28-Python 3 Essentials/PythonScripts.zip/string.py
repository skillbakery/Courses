n="""
Hello World
This is a multi
line string
"""
a=9
b=11
print(f'n is {n} "{b:<09}" "{a:0>7}" {type(n)}')