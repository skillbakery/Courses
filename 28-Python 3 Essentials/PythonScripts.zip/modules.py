import sys
import os
import random
import datetime

def main():
    ver = sys.version_info
    platform = sys.platform
    print(f'{ver}')
    print(f'{platform}')

    name = os.name
    env = os.getenv('PATH')
    wd = os.getcwd()
    print(f'{name}')
    print(f'{env}')
    print(f'{wd}')
   
    x = random.randint(1,999)
    print(x)

    currentTime = datetime.datetime.now()
    print(currentTime.year, currentTime.month, currentTime.day, currentTime.hour, currentTime.minute, currentTime.second) 

if __name__ == '__main__':main()