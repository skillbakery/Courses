tup_1 = (1,2.0,'three',4,[5,'five'])
tup_2 = (1,2.0,'threex',4,[5,'five'])
#Usage of class introspection
print(f'tup_1 is {tup_1} type is {type(tup_1)}')
print(f'tup_1 is {tup_1[2]} type is {type(tup_1[2])}') #str
print(f'tup_1 is {tup_1[4]} type is {type(tup_1[4])}') #list

print(f'tup_1 is {tup_1[2]} id is {id(tup_1[2])}') #same id
print(f'tup_2 is {tup_2[2]} id is {id(tup_2[2])}') #same id

print(f'tup_1 is {tup_1} id is {id(tup_1)}')
print(f'tup_2 is {tup_2} id is {id(tup_2)}')


#is operator
if(tup_1[0] is tup_2[0]):
    print("True")
else:
    print("False")

#isinstance
if(isinstance(tup_1[4],list)):
    print("List")
else:
    print("Something else")