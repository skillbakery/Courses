var courseCount = function() { 
	var count = db.courses.count();
	print(count);
};

courseCount();