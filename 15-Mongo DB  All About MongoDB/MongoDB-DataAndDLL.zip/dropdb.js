DB.prototype.dropDatabase = function() {
 print("This functionality is disabled");
}

db.dropDatabase = DB.prototype.dropDatabase;