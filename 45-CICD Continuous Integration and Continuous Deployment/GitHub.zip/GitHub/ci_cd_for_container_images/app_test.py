def test_always_passes():
    assert True
