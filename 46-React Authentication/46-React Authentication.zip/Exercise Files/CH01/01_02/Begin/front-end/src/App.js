import { Routes } from './Routes';

export const App = () => {
    return (
        <div className="page-container">
            <Routes />
        </div>
    );
}
