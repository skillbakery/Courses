import { testRoute } from './testRoute';

export const routes = [
    testRoute,
];
