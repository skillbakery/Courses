import { signUpRoute } from './signUpRoute';
import { testRoute } from './testRoute';

export const routes = [
    signUpRoute,
    testRoute,
];
