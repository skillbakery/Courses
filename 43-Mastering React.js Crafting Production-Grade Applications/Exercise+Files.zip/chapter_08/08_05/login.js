const LogIn = () => {
     return (
      <button type="button" className="btn btn-warning" onClick={login}>
         Login
       </button>
     );
   };
 
   const LogOut = () => {
      return (
       <button type="button" className="btn btn-danger" onClick={logout}>
          LogOut
        </button>
      );
    };