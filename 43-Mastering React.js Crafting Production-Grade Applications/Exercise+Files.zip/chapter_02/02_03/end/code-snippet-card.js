function Card() {
    return(
        <div className="card" style={{width: "18rem"}}>
         <img src="https://via.placeholder.com/200" className="card-img-top" alt="..." />
        </div>
    )
}
export default Card;