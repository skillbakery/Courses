import './App.css';

//https://via.placeholder.com/200
function App() {
  return (
    <div className="container text-center mt-5">
      <h1>Gallery</h1>
    
    </div>
  );
}

export default App;
