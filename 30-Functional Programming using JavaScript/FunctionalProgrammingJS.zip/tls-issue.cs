public class NotificationWebClient : WebClient
    {
        protected override WebRequest GetWebRequest(Uri address)
        {
            ServicePointManager.Expect100Continue = true;

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            HttpWebRequest request = base.GetWebRequest(address) as HttpWebRequest;

            request.AutomaticDecompression = DecompressionMethods.Deflate 
            | DecompressionMethods.GZip;

            return request;
        }

    }