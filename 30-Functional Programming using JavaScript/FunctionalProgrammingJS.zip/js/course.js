const courses=[
    {
        title:'Master HTML5',
        author:'SkillBakery'
    },
    {
        title:'Master Javascript',
        author:'SkillBakery'
    }
]

const tableTemplate=`
<table>
    <thead>
    <tr>
        <th>Title</th>
        <th>Author</th>
    </tr>
    </thead>
    <tbody>
        <%
            _.each(courses,course => { %>
                <tr>
                    <td><%= course.title %></td>
                    <td><%= course.author %></td>
                </tr>
            <% }); %>
    </tbody>
</table>
`;

document.body.innerHTML=_.template(tableTemplate)(courses);