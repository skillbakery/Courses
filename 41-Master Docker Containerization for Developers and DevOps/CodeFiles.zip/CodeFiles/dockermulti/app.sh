#! /bin/bash
echo "hello World!"
if ! test -f /app/include/date.txt
then
date_str=$(curl -i -sS google.com | grep -E '^Date:' | sed 's/^Date: //')
date=$(date -d "$date_str")
else
  date=$(cat /app/include/date.txt)
fi
printf "\n\n  The date is: %s\n\n" "$date"
test "$#" -gt 0 && printf "\n\nWe  got some arguments: %s\n\n" "$@"
printf "\n\n %s arguments provided\n\n" "$#"
