﻿using Microsoft.EntityFrameworkCore;
using MvcToDoList.Data;

namespace MvcToDoList.Models
{
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new MvcToDoListContext(
                serviceProvider.GetRequiredService<
                DbContextOptions<MvcToDoListContext>>()))
            {
                // Look for an To-Do tasks
                if (context.ToDoList.Any())
                {
                    return; // DB has been seeded
                }

                context.ToDoList.AddRange(
                    new ToDoList
                    {
                        Task = "Learn Arabic",
                        Description = "Attend online Arabic course",
                        Status = "To do",
                        Priority = "Medium",
                        Assignee = "Yusuf Naheem",
                        Comments = "Revise lesson 3 notes before attending class.",
                        Created = DateTime.Parse("2022-01-05"),
                        CompletedBy = DateTime.Parse("2022-01-07")
                    },

                    new ToDoList
                    {
                        Task = "Go to the Gym",
                        Description = "Go to the Gym at 5pm and train legs.",
                        Status = "Planning",
                        Priority = "High",
                        Assignee = "Yusuf Naheem",
                        Comments = "Take a bottle of watter with you.",
                        Created = DateTime.Parse("2022-01-07"),
                        CompletedBy = DateTime.Parse("2022-01-07")
                    },

                    new ToDoList
                    {
                        Task = "Buy a new laptop",
                        Description = "Buy a new laptop for brother with good specs. (Budget of £500)",
                        Status = "Open",
                        Priority = "Low",
                        Assignee = "Yusuf Naheem",
                        Comments = "Minimum i5 processor.",
                        Created = DateTime.Parse("2022-01-06"),
                        CompletedBy = DateTime.Parse("2022-01-10")
                    },

                    new ToDoList
                    {
                        Task = "Grocery shopping",
                        Description = "Weekly grocery shopping",
                        Status = "To do",
                        Priority = "High",
                        Assignee = "Mum",
                        Comments = "Dont forget milk!",
                        Created = DateTime.Parse("2022-01-11"),
                        CompletedBy = DateTime.Parse("2022-01-11")
                    },

                    new ToDoList
                    {
                        Task = "Schedule a meeting for designing the website",
                        Description = "Download required Software and tools.",
                        Status = "Planning",
                        Priority = "High",
                        Assignee = "Mark Zuckerberg",
                        Comments = "",
                        Created = DateTime.Now,
                        CompletedBy = DateTime.Now.AddDays(2)
                    },

                    new ToDoList
                    {
                        Task = "Read 2 Pages of Atomic Habits",
                        Description = "Review what you had read once complete",
                        Status = "In progress",
                        Priority = "Low",
                        Assignee = "Yusuf Naheem",
                        Comments = "",
                        Created = DateTime.Now,
                        CompletedBy = DateTime.Now
                    },

                    new ToDoList
                    {
                        Task = "Renew Gym memberhsip",
                        Description = "",
                        Status = "To do",
                        Priority = "High",
                        Assignee = "Yusuf Naheem",
                        Comments = "",
                        Created = DateTime.Parse("2022-02-08"),
                        CompletedBy = DateTime.Parse("2022-02-11")
                    },

                    new ToDoList
                    {
                        Task = "Go for a walk",
                        Description = "At 5:45pm",
                        Status = "To-do",
                        Priority = "Medium",
                        Assignee = "Yusuf Naheem",
                        Comments = "",
                        Created = DateTime.Now,
                        CompletedBy = DateTime.Now
                    },

                    new ToDoList
                    {
                        Task = "Go for a walk",
                        Description = "At 5:45pm",
                        Status = "To-do",
                        Priority = "Medium",
                        Assignee = "Yusuf Naheem",
                        Comments = "",
                        Created = DateTime.Now,
                        CompletedBy = DateTime.Now
                    },

                    new ToDoList
                    {
                        Task = "Learn about Unit Tests",
                        Description = "Go over Microsoft Docs for C# xUnit",
                        Status = "Planning",
                        Priority = "High",
                        Assignee = "Yusuf Naheem",
                        Comments = "",
                        Created = DateTime.Now,
                        CompletedBy = DateTime.Now
                    },

                    new ToDoList
                    {
                        Task = "Book holiday",
                        Description = "Look at holidays deals for March",
                        Status = "To-do",
                        Priority = "Medium",
                        Assignee = "Dad",
                        Comments = "",
                        Created = DateTime.Now,
                        CompletedBy = DateTime.Now.AddDays(1)
                    },

                    new ToDoList
                    {
                        Task = "Book holiday",
                        Description = "Look at holidays deals for March",
                        Status = "To-do",
                        Priority = "Medium",
                        Assignee = "Dad",
                        Comments = "",
                        Created = DateTime.Now,
                        CompletedBy = DateTime.Now.AddDays(10)
                    },

                    new ToDoList
                    {
                        Task = "Get car serviced",
                        Description = "",
                        Status = "To-do",
                        Priority = "Medium",
                        Assignee = "Dad",
                        Comments = "",
                        Created = DateTime.Now,
                        CompletedBy = DateTime.Now.AddDays(6)
                    },

                    new ToDoList
                    {
                        Task = "Look at new Corsair desk chairs",
                        Description = "Budget £120",
                        Status = "Planned",
                        Priority = "Lowest",
                        Assignee = "Yusuf Naheem",
                        Comments = "",
                        Created = DateTime.Now.AddDays(3),
                        CompletedBy = DateTime.Now.AddDays(5)
                    },

                    new ToDoList
                    {
                        Task = "Look into the new updates in C# 10",
                        Description = "",
                        Status = "To-do",
                        Priority = "Medium",
                        Assignee = "Yusuf Naheem",
                        Comments = "",
                        Created = DateTime.Now,
                        CompletedBy = DateTime.Now.AddDays(6)
                    },

                    new ToDoList
                    {
                        Task = "Do some more DSA challenges",
                        Description = "Use resources like HackerRank or Leetcode",
                        Status = "Planned",
                        Priority = "High",
                        Assignee = "Yusuf Naheem",
                        Comments = "",
                        Created = DateTime.Now.AddDays(3),
                        CompletedBy = DateTime.Now.AddDays(5)
                    },

                    new ToDoList
                    {
                        Task = "Look at Linux/Ubuntu",
                        Description = "",
                        Status = "Planned",
                        Priority = "High",
                        Assignee = "Yusuf Naheem",
                        Comments = "",
                        Created = DateTime.Now.AddDays(3),
                        CompletedBy = DateTime.Now.AddDays(5)
                    },

                    new ToDoList
                    {
                        Task = "Look at Linux/Ubuntu",
                        Description = "",
                        Status = "Planned",
                        Priority = "High",
                        Assignee = "Yusuf Naheem",
                        Comments = "",
                        Created = DateTime.Now.AddDays(3),
                        CompletedBy = DateTime.Now.AddDays(5)
                    }
                    ); ;
                context.SaveChanges();
            }
        }
    }
}
