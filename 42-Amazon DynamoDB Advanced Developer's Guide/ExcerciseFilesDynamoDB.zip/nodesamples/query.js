import { DynamoDB, QueryCommand } from "@aws-sdk/client-dynamodb";

const dynamodb = new DynamoDB({
  region: 'us-east-1',
  endpoint: 'http://localhost:8000'
});

// Define the table name
const tableName = "ProductTable"; // Replace with your DynamoDB table name
const partitionKey = "ProductID"; // Replace with the name of your partition key

// Define the value of the partition key to query
const partitionKeyValue = "1"; // Replace with the specific partition key value you want to query

// Create a QueryCommand with the parameters
const queryParams = {
  TableName: tableName,
  KeyConditionExpression: `#pk = :pk`,
  ExpressionAttributeNames: {
    "#pk": partitionKey,
  },
  ExpressionAttributeValues: {
    ":pk": { N: partitionKeyValue },
  },
};

// Function to query items based on the partition key
async function queryItems() {
  try {
    const data = await dynamodb.send(new QueryCommand(queryParams));
    console.log("Query result:", data.Items);
    console.log("Query result:", data);
  } catch (error) {
    console.error("Error querying items:", error);
  }
}

queryItems();
