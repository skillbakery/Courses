import { DynamoDB, CreateTableCommand } from "@aws-sdk/client-dynamodb";

const dynamodb = new DynamoDB({ 
  region: 'us-east-1',
  endpoint:'http://localhost:8000'
 });

  const params = {
    TableName: 'ProductTable', // Replace with your desired table name
    KeySchema: [
      { AttributeName: 'ProductID', KeyType: 'HASH' }, // Partition key
      { AttributeName: 'ProductName', KeyType: 'RANGE' }, // Sort key
    ],
    AttributeDefinitions: [
      { AttributeName: 'ProductID', AttributeType: 'N' },
      { AttributeName: 'ProductName', AttributeType: 'S' },
    ],
    ProvisionedThroughput: {
      ReadCapacityUnits: 5,
      WriteCapacityUnits: 5,
    },
  };

  try{
        const data = await dynamodb.send(
            new CreateTableCommand(params));
        console.log('Created table. Table description JSON:', 
                    JSON.stringify(data, null, 2));
  } 
  catch (err) {
    console.error(err);
  }