import { DynamoDBStreams, ListStreamsCommand,GetShardIteratorCommand, GetRecordsCommand,DescribeStreamCommand  } from "@aws-sdk/client-dynamodb-streams";

// Create a DynamoDB Streams client
const dynamodbStreams = new DynamoDBStreams(
    {
        region: 'us-east-1', // Replace with your desired region
        credentials: {
            accessKeyId: 'LDKFGJKLDGJKLDFGJM',
            secretAccessKey: 'lfksdfjklllkdfgjkldfjg/ntZ+kjfgldfjglk',
        }
    });

    // Function to read records from the DynamoDB stream
async function readStream() {
  
  const listStreamsParams = {
    TableName:'Orders', // Extract the table name from the stream ARN
  };

  try {
    const streamListResponse = await dynamodbStreams.send(new ListStreamsCommand(listStreamsParams));
    const streamDescription = streamListResponse.Streams[0];
    // console.log(streamDescription);

    if (streamDescription) {
        const streamArn = streamDescription.StreamArn;
  
        // Use DescribeStream to get shard information
        const describeStreamParams = {
          StreamArn: streamArn,
        };
        const streamDetails = await dynamodbStreams.send(new DescribeStreamCommand(describeStreamParams));
        // console.log(streamDetails);

        // Extract shard information
        const shards = streamDetails.StreamDescription.Shards;
  
        for (const shard of shards) {
            
            const shardId = shard.ShardId;
            // Get ShardIterator for the shard
            const getShardIteratorParams = {
              StreamArn: streamArn,
              ShardId: shardId,
              ShardIteratorType: 'AT_SEQUENCE_NUMBER',
              SequenceNumber: shard.SequenceNumberRange.StartingSequenceNumber // You can use 'AT_SEQUENCE_NUMBER', 'TRIM_HORIZON' or 'LATEST' based on your requirements
            };
            const shardIteratorResponse = await dynamodbStreams.send(new GetShardIteratorCommand(getShardIteratorParams));
            let shardIterator = shardIteratorResponse.ShardIterator;
        
          while (shardIterator) {
            const getRecordsParams = {
              ShardIterator: shardIterator,
            };
            //console.log(shardIterator);

            const recordsResponse = await dynamodbStreams.send(new GetRecordsCommand(getRecordsParams));
            //console.log(recordsResponse);

            const records = recordsResponse.Records;
            console.log(records);

            if (records.length > 0) {
              // Process and print the records
              records.forEach((record) => {
                console.log('Record:', record);
                console.log(JSON.stringify(record, null, 2));
              });
  
              // Update the shard iterator for the next batch of records
              shardIterator = recordsResponse.NextShardIterator;
            } else {
              // No more records in the shard
              break;
            }
          }
        }
      } else {
        console.log('No stream found for the specified table.');
      }
    } catch (error) {
      console.error('Error reading the DynamoDB stream:', error);
    }
  }
  
  readStream();
