import { DynamoDB, PutItemCommand } from "@aws-sdk/client-dynamodb";

const dynamodb = new DynamoDB({
  region: 'us-east-1',
  endpoint: 'http://localhost:8000'
});

// Define the table name
const tableName = "ProductTable"; // Replace with your DynamoDB table name

const itemsToInsert = [
    {
      ProductID: { N: "1" },
      ProductName: { S: "Product 1" },
      ProductCost: { N: "10.99" },
      Manufacturer: { S: "Manufacturer A" },
    },
    {
      ProductID: { N: "2" },
      ProductName: { S: "Product 2" },
      ProductCost: { N: "19.99" },
      Manufacturer: { S: "Manufacturer B" },
    },
    // Add more items as needed
];
// Function to insert items into the DynamoDB table
async function insertItems() {
    for (const item of itemsToInsert) {
      const putItemParams = {
        TableName: tableName,
        Item: item,
      };
      try {
        const data = await dynamodb.send(new PutItemCommand(putItemParams));
        console.log("Item inserted successfully:", data);
      } catch (error) {
        console.error("Error inserting item:", error);
      }
    }
  }
  
  insertItems();