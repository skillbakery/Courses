import boto3

def update_book(book_id, title, dynamodb=None):
    dynamodb = boto3.resource('dynamodb',endpoint_url="http://localhost:8000")

    books_table = dynamodb.Table('Books')

    response = books_table.update_item(
        Key={
            'book_id' : book_id,
            'title': title
        },
        UpdateExpression="set isbn=:ISBN",
        ExpressionAttributeValues={':ISBN': "978-0-06-112008-5"},
        ReturnValues="UPDATED_NEW"
    )
    return response

if __name__ == '__main__':
    update_response = update_book(1, 'To Kill a Mockingbird')
    print(update_response)