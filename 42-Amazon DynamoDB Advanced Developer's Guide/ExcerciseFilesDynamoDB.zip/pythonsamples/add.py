import boto3

def add_book(books, dynamodb=None):
    dynamodb = boto3.resource('dynamodb',endpoint_url="http://localhost:8000")

    books_table = dynamodb.Table('Books')
    response = books_table.put_item(
        Item={
        "book_id": 6,
        "title": "Moby-Dick",
        "author": "Herman Melville",
        "isbn": "978-1-55563-515-3",
        "year_of_publication": 1851
        }
    )


    return response

if __name__ == '__main__':
    book_resp = add_book(books='Books')
    print(book_resp)