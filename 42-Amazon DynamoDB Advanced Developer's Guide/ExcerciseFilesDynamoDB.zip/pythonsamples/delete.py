import boto3

def delete_book(book_id, title, dynamodb=None):
    dynamodb = boto3.resource('dynamodb',endpoint_url="http://localhost:8000")

    books_table = dynamodb.Table('Books')

    response = books_table.delete_item(
        Key={
            'book_id' : book_id,
            'title': title
        },
    )
    return response

if __name__ == '__main__':
    delete_response = delete_book(5, 'The Great Gatsby')
    print(delete_response)