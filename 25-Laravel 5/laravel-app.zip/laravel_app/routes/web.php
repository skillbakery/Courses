<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', 'ContentController@index');
Route::get('/course/{course_id}', 'ContentController@show')->name('course');

Route::get('/', function () {

    $response_arr=[];
    $response_arr['author']='SB';
    $response_arr['course']='Laravel';
    return view('welcome',$response_arr);
});

Route::post('/', 'ContentController@post');

Route::get('/aboutus', function () {
    $response_arr=[];
    $response_arr['author']='SB';
    $response_arr['course']='Laravel';
    return view('welcome',$response_arr);
    //return $response_arr;//'<h2>About us</h2>';
});

Route::get('/dinj', 'UserController@dinj')->name('courses');
Route::post('/dinj', 'UserController@post');

Route::get('/facades/encrypt', function(){
    return Crypt::encrypt('1234abcx');
});
Route::get('/facades/decrypt', function(){
    return Crypt::decrypt('eyJpdiI6ImpCZkpqb0NnVzJOamNPRllPcGM0WXc9PSIsInZhbHVlIjoiNFpwd1dvaFdoU3FXcjgzZHhaTVdjUT09IiwibWFjIjoiNTQ5YjhjODgzNzg3YjViN2E3Y2IxMzc5ZTQ3MWE3ZTFhMDI1YzY0YjlkYzZjY2ZhNWNhNTFjZWE3OWZhZWQyOSJ9');
});