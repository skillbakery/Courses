<?php $__env->startSection('content'); ?>
<div class="content">
        <form method="POST">
            <ul>
            <li><input type="text" placeholder="First Name" name="name"/></li>
            <li><input type="text" placeholder="Last Name" name="lname" required/></li>
            <li><input type="email" placeholder="Email" name="email" required/></li>
            <li><input type="password" placeholder="Password" name="password" required/></li>
            <li><input type="submit" value="submit" /></li>
            </ul>
        </form>
        <div class="title m-b-md">
            <!-- <?php echo e(var_dump($course)); ?> -->
            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('course',['course_id'=>$title->course_name])); ?>"><?php echo e($title->course_name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
</div>                
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>