@extends('layouts.app')

@section('content')
<div class="content">
        <form method="POST">
            <ul>
            <li><input type="text" placeholder="First Name" name="name"/></li>
            <li><input type="text" placeholder="Last Name" name="lname" required/></li>
            <li><input type="email" placeholder="Email" name="email" required/></li>
            <li><input type="password" placeholder="Password" name="password" required/></li>
            <li><input type="submit" value="submit" /></li>
            </ul>
        </form>
        <div class="title m-b-md">
            <!-- {{ var_dump($course) }} -->
            @foreach($course as $title)
            <a href="{{ route('course',['course_id'=>$title->course_name]) }}">{{ $title->course_name }}</a>
            @endforeach
        </div>
</div>                
@endsection