@extends('layouts.app')

@section('content')
<div class="content">
                <div class="title m-b-md">
                    {{ $course }}
                    {{ $author }}
                </div>
</div>                
@endsection