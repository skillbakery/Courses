<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class SampleServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap the application services.
     *
     * @return void
     */
    public function boot()
    {
         //echo "Booted";
    }

    /**
     * Register the application services.
     *
     * @return void
     */
    public function register()
    {
        //echo "Registered";
    }
}
