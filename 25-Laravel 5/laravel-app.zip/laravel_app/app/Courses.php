<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Courses extends Model
{
    //
    public function getCourses(){
        // $courses = DB::table('courses as c')
        //                 ->select('c.id','c.course_name','c.cost','c.publisher','c.author')
        //                 ->whereRaw("c.cost>20")
        //                 ->orderBy('c.course_name')
        //                 ->get();
        // return $courses;

        $courses = DB::select("Select c.id,c.course_name,c.cost,c.publisher from courses as c where c.cost>20 order by c.course_name");
        return $courses;
    }

}
