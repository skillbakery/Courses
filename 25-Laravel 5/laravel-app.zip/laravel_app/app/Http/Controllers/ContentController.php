<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Courses as Course;
class ContentController extends Controller
{
    //
    public function __construct(Course $courses){
        $this->courses = $courses->all();
    }
    public function index(){

        return __METHOD__;
    }

    public function show($course_id){
        //return $course_id;
        $course_data = $this->courses->find($course_id);
         
        $response_arr=[];
        $response_arr['author']='SB';
        $response_arr['course']=$course_data['course_name'];//'Laravel '.$course_id;
        return view('contents.page',$response_arr);
    }

    public function post(Request $request, Course $course){
        $course_name = $request->input('name');
        /*
        $course->insert([
            'course_name'=>$course_name,
            'publisher'=>'SkillBakery',
            'author'=>'SkillBakery',
            'cost'=>45,
            'published_on'=>date('Y-m-d')
        ]);
        */
        
        //Let's update a record with id 1
        $course_data = $this->courses->find(1);
        $course_data['cost']=70;
        $course_data->save();

        return $request->input('name');
    }
}
