<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//use App\Bakery as Courses;

use App\Courses as Courses;

class UserController extends Controller
{
    //
    public function __construct(Courses $courses){
        $this->courses = $courses->getCourses();//$courses->all();
    }

    public function dinj(){
        $response_arr=[];
        $response_arr['course']=$this->courses;
        return view('contents.courses',$response_arr);
        //dd($this->courses); //dump and die - equivalent of print_r
    }

    public function post(Request $request){
        if($request->isMethod('post')){
            $this->validate($request,[
                'name'=>'required',
                'lname'=>'required',
                'email'=>'required',
                'password'=>'required',
            ]);
            $response_arr=[];
            $response_arr['course'][]=$request->input('name');
            return view('contents.courses',$response_arr);
        }
        
    }
}
