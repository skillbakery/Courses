<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
//class Bakery extends Model
class Bakery
{
    protected $courses_array = ['Laravel','Flutter','Cosmos DB'];

    public function all(){
        return $this->courses_array;
    }

    public function get($id){
        return $this->courses_array[$id];
    }
}
