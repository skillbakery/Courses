(function () {
    var app = angular.module('HelloWorld', []);
    app.controller('GreetController', function () {
        this.greetMessage = "Start Learning Today!";
        this.greetWorld = greetWorld();
        this.student = student;
    });
    var student = {};
    student.name = "John";
    student.subject = "AngularJS";

    function greetWorld() {
        console.log("Hello World");
    }
})();
