<?php
    
     $courses = array("courses"=>
        array(
         'title'=> "Master JavaScript & jQuery",
         'description'=> "Learn JavaScript & jQuery",
         'image'=> "Master-JavaScript.jpg",
         'price'=> 20,
         'author'=> "SkillBakery.com",
         'published'=> true,
         'courseUrl'=> "https=>//www.udemy.com/master-javascript-jquery/",
         'CourseID'=> 1
        ),
        array(
          'title'=> "Master KnockoutJS",
        'description'=> "Learn KnockoutJS",
        'image'=> "Master-Knockout.jpg",
        'price'=> 39,
        'author'=> "SkillBakery.com",
        'published'=> true,
        'courseUrl'=> "https=>//www.udemy.com/master-knockoutjs-javascript/",
        'CourseID'=> 2
        ),
        array(
        'title'=> "AWS LAMP Setup",
        'description'=> "Learn JavaScript & jQuery",
        'image'=> "AWS-LAMP.jpg",
        'price'=> 50,
        'author'=> "SkillBakery.com",
        'published'=> true,
        'courseUrl'=> "https=>//www.udemy.com/amazon-web-services-lamp-setup-step-by-step/",
        'CourseID'=> 3
        ),
        array(
        'title'=> "Advanced jQuery",
        'description'=> "Learn JavaScript & jQuery",
        'image'=> "Advanced-jQuery.jpg",
        'price'=> 10,
        'author'=> "SkillBakery.com",
        'published'=> true,
        'courseUrl'=> "https=>//www.udemy.com/advanced-jquery-tips-tricks-for-developers-designers/",
        'CourseID'=> 4
        ));
     echo json_encode($courses);
    
?>