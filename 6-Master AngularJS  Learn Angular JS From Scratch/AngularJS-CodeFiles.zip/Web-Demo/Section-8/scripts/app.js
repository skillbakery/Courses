(function () {
    var app = angular.module('CoursesModule', ['ngRoute', 'ngAnimate']);

    app.config(function ($routeProvider) {
        $routeProvider
        .when('/', {
            controller: 'CoursesController',
            templateUrl: 'views/Courses.html'
        })
        .when('/details/:courseId', {
            controller: 'DetailsController',
            templateUrl: 'views/details.html'
        })
        .otherwise({ redirectTo: '/' });
    });


    var CoursesController = function (e, coursesService) {
        e.orderBy = 'title';
        e.reverse = false;
        e.ActiveCourseID = 1;
        e.sortOnPrice = 'price';
        e.Courses = [];
        e.CourseCount = 0;
        function constructCourse() {
            //e.Courses = coursesService.getCourses();
            coursesService.getCourses()
                .success(function (courses) {
                    e.Courses = courses;
                    e.CourseCount = Object.size(e.Courses);
                }).error(function (data, status, header, configuration) {
                    //handle the error
                });
        }

        e.sortOn = function (attribute) {
            e.sortOnPrice = attribute;
            e.reverse = !e.reverse;
        };

        //Animation - Carousel

        e.direction = 'left';
        e.currentIndex = 0;

        e.setCurrentSlideIndex = function (index) {
            e.direction = (index > e.currentIndex) ? 'left' : 'right';
            e.currentIndex = index;
        };

        e.isCurrentSlideIndex = function (index) {
            console.log(e.currentIndex === index);
            return e.currentIndex === index;
        };

        e.prevSlide = function () {
            e.direction = 'left';
            e.currentIndex = (e.currentIndex < e.CourseCount - 1) ? ++e.currentIndex : 0;
            e.ActiveCourseID = e.currentIndex + 1;
        };

        e.nextSlide = function () {
            e.direction = 'right';
            e.currentIndex = (e.currentIndex > 0) ? --e.currentIndex : e.CourseCount - 1;
            e.ActiveCourseID = e.currentIndex + 1;
        };

        Object.size = function (obj) {
            var size = 0;
            for (key in obj) {
                if (obj.hasOwnProperty(key)) size++
            }
            return size;
        };
        constructCourse();
    }
    CoursesController.$inject = ['$scope', 'coursesService'];

    var DetailsController = function (e, f, courseFactory) {
        var courseId = f.courseId;
        var courseCounter = e.Courses.length;
        e.Course = null;
        e.Courses = [];
        function constructCourse() {
            e.Courses = courseFactory.getCourses();
        }
        constructCourse();

        function getCourse() {
            e.Course = courseFactory.getCourse(courseId);
        }
        getCourse();
    }

    DetailsController.$inject = ['$scope', '$routeParams', 'courseFactory'];
    app.controller('CoursesController', CoursesController);

    app.controller('DetailsController', DetailsController);

    app.directive('nav', function () {
        return {
            restrict: 'E', //E is for Element Directive & A is for Attribute Directive
            templateUrl: 'views/nav.html',
            controller: 'CoursesController'
        };
    })
    app.directive('reviewForm', function () {

        return {
            restrict: 'E', //E is for Element Directive & A is for Attribute Directive
            templateUrl: 'views/directive-with-ctrl.html',
            controller: function ($scope) {
                $scope.review = {};

                $scope.addReview = function (course) {
                    course.reviews.push($scope.review);
                    $scope.review = {};
                }
            }
            //,controllerAs:'ctrl'
        };

    })


})();
