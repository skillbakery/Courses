<template>
   
    <div id="appStatic" v-once>
      <h1>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean auctor laoreet nulla, nec volutpat tellus facilisis non. Nullam ultrices enim in sapien accumsan, eu auctor arcu maximus. Maecenas elementum massa quis tortor placerat, quis pulvinar dolor aliquam. In urna lectus, commodo eget sollicitudin ac, mollis a purus. Aliquam accumsan, urna et fringilla tempus, purus augue volutpat nulla, tincidunt rhoncus orci lacus nec risus. In commodo sapien sed sem tempor, vitae bibendum tellus sodales. Praesent blandit fermentum turpis, tempor tristique ligula gravida at. Integer bibendum tincidunt dui ut finibus. Ut nisi mi, hendrerit et lectus at, laoreet pellentesque velit. Fusce nec dui massa. Nullam id ipsum in ante porttitor tincidunt. Vestibulum faucibus congue erat, at dignissim nulla mattis in. Morbi egestas mi et urna cursus, nec ultricies nulla aliquam. Donec feugiat nisl a ipsum facilisis, sit amet bibendum dui ultricies. Morbi non mauris a lectus efficitur hendrerit. Aliquam nec hendrerit ligula.</h1>
  
    </div>
</template>
<script>
export default {
  name: 'staticOne',
  data () {
    return {
      message: 'static component'
    }
  }
}
</script>