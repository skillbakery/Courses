<template>
<div id="appB">
<input v-model="pState.dB">
<input v-model="hubState.message">
<pre>{{pState.dB}}</pre>
</div>
</template>
<script>
import hub from './hub'
export default {
  name: 'compB',
  components: {
    hub
  },
  data () {
    return {
      pState: {
        dB: 'hello B'
      },
      hubState: hub
    }
  }
}
</script>