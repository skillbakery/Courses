<template>
    <div id="appA">
    <input v-model="pState.dA">
    <input v-model="hubState.message">
    <pre>{{pState.dA}}</pre>
    </div>
</template>
<script>
import hub from './hub'
export default {
  name: 'compA',
  components: {
    hub
  },
  data () {
    return {
      pState: {
        dA: 'hello A'
      },
      subject: 'Hello From A',
      hubState: hub
    }
  }
}
</script>