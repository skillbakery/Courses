<script>
export default {
  name: 'hub',
  message: 'Hello!'
}
</script>