<template>
<div>
    <h2>I am Header Title</h2>
     <slot name="content">
       Content Default
    </slot>
    <slot>
        This will only be displayed if there is no content
        to be distributed.
    </slot>
    <slot text="I am scoped slot"></slot>
</div>
</template>    
<script>
export default {
  name: 'appheader',
  message: 'Hello!'
}
</script>
<!--
    <container>
        <header></header>
        <footer></footer>
    </container>
-->