<template>
    <div>
    <header>{{title}}</header>
    <div v-html='content'></div>
    <span v-bind:title='createdAt'>
       Title will appear on mouse hover
    </span>
    <div v-if="visible" v-bind:style="{color:color_green}">{{content | capitalize}}</div>    
    <div v-else>{{title}}</div>
    <div v-show="visible">{{content}}</div>
    <ul>
        <li v-for="course in courses">
            <span :class="{comp:visible}">{{ course.title }}</span>
        </li>
    </ul>
    <span>{{publisher}}</span>
    <input type="text" v-model="content" placeholder="Edit" v-on:keyup="captureKeyEvent" v-on:keyup.enter="captureEnter"/>
    <button @click="flashMessage">Flash Message</button>
    <button v-on:click="greet('Hello');">Greet</button>

    <div>Quantity is {{ quantity + 2 }}</div>
    <div>{{ reverseMessage }}</div>
    <div>{{ fullName }}</div>
    <div>{{ firstName }} </div>
    <div>{{ lastName }} </div>
    <ul>
      <li v-for="n in evenNumbers">{{ n }}</li>
    </ul>
    <ul>
      <li v-for="n in even(numbers)">{{ n }}</li>
    </ul>
    
    <!--Form Binding Textare,Checkbox,Radio and Drop downs -->
    <span>TextArea - MultiLine message is:</span>
    <p style="white-space: pre">{{ content }}</p>
    <br>
    <textarea v-model="content" placeholder="add multiple lines"></textarea>

    <br/>
    <input type="checkbox" id="checkbox" v-model="visible">
    <label for="checkbox">{{ visible }}</label>

    <br/>
    <input type="radio" id="one" value="One" v-model="choice">
    <label for="one">One</label>
    <br>
    <input type="radio" id="two" value="Two" v-model="choice">
    <label for="two">Two</label>
    <br>
    <span>Selected: {{ choice }}</span>
    
    <br/>
    <select v-model="selection">
      <option>1</option>
      <option>2</option>
      <option>3</option>
    </select>
    <span>Selected: {{ selection }}</span>

    <!-- Value Binding -->
    <br/>
    <input
      type="checkbox"
      v-model="toggle"
      v-bind:true-value="a"
      v-bind:false-value="b"
    >
    <label for="checkbox">{{ toggle }}</label>
    <br/>
    <input type="radio" v-model="toggle" v-bind:value="a">
    <br/>
    <select v-model="selected">
      <!-- inline object literal -->
      <option v-bind:value="{ number: 225 }">224</option>
    </select>
    <br/>
     <span>Selected: {{ selected.number }}</span>
     <br/>
     <!-- modifiers -->
     <input v-model.number="age" type="number">
     <input v-model.trim="content">
     <br/>
      <p>{{ content }}</p>
      <br/>
      <p>Price : {{ price }}<p>

      <button v-on:click="addup">{{ counter }}</button>
      <!-- Form Component -->
      <input ref="input" v-bind:price="currency" v-on:input="updateValue($event.target.value)" />
    </div>
</template>
<script>
export default {
  name: 'component',
  data () {
    return {
      title: 'Components',
      content: ' creating Components in Vue is easy ',
      createdAt: 'Accessed at ' + new Date(),
      visible: true,
      courses: [
              { title: 'Master JavaScript' },
              { title: 'Master Vue' },
              { title: 'Master MongoDB' }],
      color_green: 'green',
      quantity: 1,
      firstName: 'Sam',
      lastName: 'Guthrie',
      numbers: [1, 2, 3, 4, 5, 6],
      choice: '',
      selection: '',
      toggle: 'Checked',
      a: 'Checked',
      b: 'Unchecked',
      selected: '',
      age: 1,
      counter: 0,
      currency: 0
    }
  },
  computed: {
    reverseMessage: function () {
      return this.content.split('').reverse().join('')
    },
    fullName: {
      get: function () {
        return this.firstName + ' ' + this.lastName
      },
      set: function (newText) {
        var fName = newText.split(' ')
        this.firstName = fName[0]
        this.lastName = fName[fName.length - 1]
      }
    },
    evenNumbers: function () {
      return this.numbers.filter(function (number) {
        return number % 2 === 0
      })
    }
  },
  watch: {
    content: function (text) {
      this.title = text
    }
  },
  filters: {
    capitalize: function (value) {
      if (!value) return ''
      value = value.toString()
      return value.charAt(0).toUpperCase() + value.slice(1)
    }
  },
  methods: {
    flashMessage: function () { console.log(this.content) },
    captureKeyEvent: function (e) { console.log(e.target.value) },
    captureEnter: function () { console.log('Submitting Message on enter') },
    greet: function (greeting) { console.log(greeting) },
    even: function (numbers) {
      return numbers.filter(function (number) {
        return number % 2 === 0
      })
    },
    addup: function () {
      this.counter += 1
      this.$emit('addup')
    },
    updateValue: function (value) {
      var result = value * 2
      this.$refs.input.value = result
      this.$emit('input', Number(result))
    }
  },
  created: function () {
    console.log('Component Created')
    this.fullName = 'Mat Daemon'
  },
  props: {
    publisher: {
      type: String,
      default: 'SkillBakery',
      required: true
    },
    price: {
      type: Number,
      default: 10,
      validator: function (value) {
        return value > 10
      }
    }
  }
}
</script>
<style scoped>
  .comp {
   font-weight: "bold";
   color:chocolate
 }
</style>