// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import Velocity from 'velocity-animate/velocity.min.js'

/* eslint-disable no-new */
Vue.component('async-comp', function (resolve, reject) {
  setTimeout(function () {
    resolve({
      template: '<div> I will be late for the party</div>'
    })
    console.log('Async')
  }, 3000)
})

new Vue({
  el: '#example'
})

new Vue({
  el: '#app',
  template: '<App/>',
  components: { App }
})

new Vue({
  el: '#my-template',
  template: '#myx-template'
})

new Vue({
  el: '#demoTransition',
  data: {
    show: true
  }
})

new Vue({
  el: '#divCSSTransition',
  data: {
    show: true
  }
})

new Vue({
  el: '#example-Animation',
  data: {
    show: true
  }
})

new Vue({
  el: '#jshooks',
  data: {
    show: false
  },
  methods: {
    beforeEnter: function (el) {
      el.style.opacity = 0
    },
    enter: function (el, done) {
      Velocity(el, { opacity: 1, fontSize: '1.4em' }, { duration: 300 })
      Velocity(el, { fontSize: '1em' }, { complete: done })
    },
    leave: function (el, done) {
      Velocity(el, { translateX: '15px', rotateZ: '50deg' }, { duration: 600 })
      Velocity(el, { rotateZ: '100deg' }, { loop: 2 })
      Velocity(el, {
        rotateZ: '45deg',
        translateY: '30px',
        translateX: '30px',
        opacity: 0
      }, { complete: done })
    }
  }
})

new Vue({
  el: '#switchElements',
  data: {
    show: true
  }
})
