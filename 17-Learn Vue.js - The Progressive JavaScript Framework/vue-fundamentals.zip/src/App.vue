<template>
  <div id="app">
    <!--<input v-model="publisher">
    <img src="./assets/logo.png">-->
    <!-- Basic Binding -->
    <!--
    <Components publisher="Skillbakery Studio"></Components>
    -->
    
    <h1>I'm the App component title</h1>
    <appheader inline-template> 
      <div>
        <p>This is some original content</p>
        <p>This is some more original content</p>
      </div>
    </appheader>
   <!--
    <compA></compA>
    <compB></compB>
    <Components v-bind:publisher="publisher" v-bind:price="11" v-on:addup="addupTotal" v-model="price"></Components>
    <p> Total {{ total }}</p>-->
    <!--
    <select v-model="activeComponent">
      <option>compA</option>
      <option>compB</option>
      <option>Component</option>
    </select>
    <br/>
    <keep-alive>
      <component v-bind:is="activeComponent"></component>
    </keep-alive>
    -->
    <compA ref="acomp"></compA>
    <!--<staticOne></staticOne>-->
    <!-- Transition between Components -->
    <select v-model="activeComponent">
      <option>compA</option>
      <option>compB</option>
    </select>
     <transition name="component-fade" mode="out-in">
          <component v-bind:is="activeComponent"></component>
    </transition>
  </div>
</template>

<script>
import Components from './components/Component'
import compA from './components/compA'
import compB from './components/compB'
import appheader from './components/appheader'
import staticOne from './components/staticOne'
export default {
  name: 'app',
  components: {
    Components,
    compA,
    compB,
    appheader,
    staticOne
  },
  data () {
    return {
      publisher: 'Skillbakery',
      total: 0,
      price: 0,
      activeComponent: 'compA'
    }
  },
  methods: {
    addupTotal: function () {
      this.total += 1
    },
    getChildren: function () {
      var child = this.$refs.acomp
      console.log(child.subject)
    }
  },
  computed: {
    total: function () {
      return ((
        this.price * 100
      ) / 100).toFixed(2)
    }
  },
  mounted: function () {
    this.getChildren()
  }
}
</script>
<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

.component-fade-enter-active, .component-fade-leave-active {
  transition: opacity .3s ease;
}
.component-fade-enter, .component-fade-leave-to
/* .component-fade-leave-active for <2.1.8 */ {
  opacity: 0;
}
</style>
