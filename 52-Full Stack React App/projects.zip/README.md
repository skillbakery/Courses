# Events Project Starter

* Clone the project:
```
npx degit skillbakery/event-starter events
```
* Navigate to the project directory and install dependencies:
```
cd events && npm install
```
* Start the project:
```
npm run dev
```
The app should now be available locally at http://localhost:5173/
