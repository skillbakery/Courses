﻿using ML_IssueClassificationML.Model;
using System;

namespace ML_IssueClassification
{
    class Program
    {
        static void Main(string[] args)
        {
            // Add input data
            var input = new ModelInput();
            input.Title = "ASP.Net Application";
            input.Description = "Learning ASP.Net MVC";
            // Load model and predict output of sample data
            ModelOutput result = ConsumeModel.Predict(input);
            Console.WriteLine(result.Prediction);

        }
    }
}
