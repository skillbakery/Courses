﻿using MLPriceDemoML.Model;
using System;

namespace MLPriceDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            var taxiTripSample = new ModelInput()
            {
                Vendor_id = "VTS",
                Rate_code = 1,
                Passenger_count = 1,
                Trip_time_in_secs = 1140,
                Trip_distance = 3.75f,
                Payment_type = "CRD",
                Fare_amount = 0 // To predict. Actual/Observed = 15.5
            };

            // Load model and predict output of sample data
            ModelOutput result = ConsumeModel.Predict(taxiTripSample);

            Console.WriteLine($"**********************************************************************");
            Console.WriteLine($"Predicted fare: {result.Score:0.####}, actual fare: 15.5");
            Console.WriteLine($"**********************************************************************");

        }
    }
}
