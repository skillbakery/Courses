﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MovieRecommendationConsoleApp.DataStructures
{
    class MovieRatingPrediction
    {
        public float Label;

        public float Score;
    }
}