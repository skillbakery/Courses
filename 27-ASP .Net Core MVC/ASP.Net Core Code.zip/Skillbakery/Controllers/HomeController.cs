﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Skillbakery.Models;

namespace Skillbakery.Controllers
{
    //[Route("course")]
    public class HomeController : Controller
    {
        private readonly SkillbakeryContext _db;
        public HomeController(SkillbakeryContext db)
        {
            _db = db;
        }
        
        public IActionResult Index()
        {
            ViewBag.Title = "Pass data from controller to view";
            var firstCourse = _db.Courses.Take(1).FirstOrDefault();
            var course = new Course();
            course.Title = firstCourse.Title;
            if(firstCourse.PublishedOn.HasValue)
            course.publishedOn = firstCourse.PublishedOn.Value;
            //var course = new Course
            //{
            //    Title = "Skillbakery Courses",
            //    publishedOn = DateTime.Now
            //};
            #region Update and Query
            //Updating db
            //_db.Entry(firstCourse).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            //_db.SaveChanges();

            ////updating a selection
            //var courses = _db.Courses.ToList();
            //courses.Select(c => { c.Author = "Skillbakery Studios"; return c; }).ToList();

            #endregion
            return View(course);
            //return new ContentResult { Content = "ASP.Net Core MVC Course" };
        }
        public IActionResult About()
        {
            return View();
            //return new ContentResult { Content = "ASP.Net Core MVC Course" };
        }
        //[Route("course/{title}/{id:int?}")]
        public IActionResult Courses(string title,int id=0)
        {
            //return View();
            //if(id==null)
            //    return new ContentResult { Content = "ASP.Net Core MVC Course " };
            //else
                return new ContentResult { Content = "ASP.Net Core MVC Course -"+ id + " title "+ title };
        }

        [Authorize]

        public IActionResult Course()
        {
            var course = new CourseViewModel();
            return View(course);
            
        }
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Course(CourseViewModel model)
        {
            if (ModelState.IsValid)
            {
                model.publishedOn = DateTime.Now;

                var course = new Courses();
                course.Author = model.Author;
                course.Title = model.Title;
                course.PublishedOn = model.publishedOn;

                _db.Courses.Add(course);
                _db.SaveChanges();
                return View(model);
            }
            return View();
        }

        public IActionResult SingleFeature()
        {
            var firstCourse = _db.Courses.Take(1).FirstOrDefault();
            var course = new Course();
            course.Title = firstCourse.Title;
            if (firstCourse.PublishedOn.HasValue)
                course.publishedOn = firstCourse.PublishedOn.Value;

            return PartialView("_SingleFeature", course);
        }
    }
}