Alter PROCEDURE usp_GetCustomerShipDates
    @ShipDateStart DateTime,
	@ShipDateEnd DateTime
AS
Select CustomerId,
SalesOrderNumber
From Sales.SalesOrderHeader 
Where ShipDate Between @ShipDateStart and @ShipDateEnd
Option (Recompile)

USE [AdventureWorks2022]
GO
CREATE NONCLUSTERED INDEX IX_ShipDate_ASC
ON [Sales].[SalesOrderHeader] ([ShipDate])
INCLUDE ([SalesOrderNumber],[CustomerID])
GO

DBCC FREEPROCCACHE
SET STATISTICS TIME ON;
SET STATISTICS IO ON;

exec usp_GetCustomerShipDates '2005-07-01','2018-01-01'

DBCC FREEPROCCACHE
SET STATISTICS TIME ON;
SET STATISTICS IO ON;
exec usp_GetCustomerShipDates '2005-07-01','2005-07-31'