USE WideWorldImporters;

SELECT c.CustomerName,
       c1.CustomerName AS SalesRepresentative
FROM Sales.Customers c
JOIN Sales.Customers c1 ON c.PrimaryContactPersonID = c1.CustomerID;


SELECT * FROM Sales.Customers c