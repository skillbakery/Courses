Alter Procedure usp_StudentDetails
@StudentId int = NULL
As
Begin
SET NOCOUNT ON;
IF @StudentId IS NULL
Begin
	SELECT 
	s.FirstName, 
	s.LastName,
	O.OrderId,
	O.OrderDate 
	FROM Students s 
	join Orders O 
	ON s.StudentIId=O.StudentId
	Return
End
SELECT 
s.FirstName, 
s.LastName,
O.OrderId,
O.OrderDate 
FROM Students s 
join Orders O 
ON s.StudentIId=O.StudentId
Where StudentId=@StudentId
End

exec usp_StudentDetails 1001