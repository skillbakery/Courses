UPDATE Students
Set MiddleName='K',Email='chris.e@skillbakery.com'
WHERE StudentIId=1001