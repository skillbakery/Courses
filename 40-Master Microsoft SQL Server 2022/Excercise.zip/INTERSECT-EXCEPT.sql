USE AdventureWorks2022;

-- Using INTERSECT to find distinct order dates common between sales and purchase orders
SELECT OrderDate
FROM Sales.SalesOrderHeader
INTERSECT
SELECT OrderDate
FROM Purchasing.PurchaseOrderHeader;

-- Using EXCEPT to find order dates in sales orders but not in purchase orders
SELECT OrderDate
FROM Sales.SalesOrderHeader
EXCEPT
SELECT OrderDate
FROM Purchasing.PurchaseOrderHeader;
