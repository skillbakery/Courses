BEGIN TRY
    -- Start of the TRY block
	SET IDENTITY_INSERT Orders ON;

    INSERT INTO Orders (OrderID, OrderDate)
    VALUES (1001, '2023-08-09');
    
    PRINT 'Order inserted successfully.';
    
END TRY
BEGIN CATCH
    -- Start of the CATCH block

    PRINT 'An error occurred:';
    PRINT ERROR_MESSAGE();
    
END CATCH;
