/****** Script for SelectTopNRows command from SSMS  ******/
SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT FirstName,LastName,MiddleName
FROM Person.Person
where LastName='Chen'