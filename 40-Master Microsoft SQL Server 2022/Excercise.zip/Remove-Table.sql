USE [SkillBakery]
GO

Drop Table IF EXISTS CourseCategories
Go

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CourseCategories](
	[CategoryId] [int] IDENTITY(1,1) NOT NULL,
	[CategoryName] [varchar](50) NOT NULL,
	[DateAdded] [datetime] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[CategoryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

SET IDENTITY_INSERT [dbo].[CourseCategories] ON 
GO
INSERT [dbo].[CourseCategories] ([CategoryId], [CategoryName], [DateAdded]) VALUES (1, N'Web Development', CAST(N'2023-07-30T22:32:45.237' AS DateTime))
GO
INSERT [dbo].[CourseCategories] ([CategoryId], [CategoryName], [DateAdded]) VALUES (2, N'Desktop Applications', CAST(N'2023-07-30T22:32:45.237' AS DateTime))
GO
SET IDENTITY_INSERT [dbo].[CourseCategories] OFF
GO
