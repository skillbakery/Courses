/****** Script for SelectTopNRows command from SSMS  ******/
SELECT [DepartmentID]
      ,[Name]
      ,[GroupName]
      ,[ModifiedDate]
  FROM [AdventureWorks2022].[HumanResources].[Department]
  --Where GroupName='Executive General and Administration'
  Order By GroupName Desc, DepartmentID