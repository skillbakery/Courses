/****** Script for SelectTopNRows command from SSMS  ******/
SELECT [DepartmentID]
      ,[Name]
      ,[GroupName]
      ,[ModifiedDate]
  FROM [AdventureWorks2022].[HumanResources].[Department]
  WHERE GroupName = 'Research and Development' and DepartmentID=1