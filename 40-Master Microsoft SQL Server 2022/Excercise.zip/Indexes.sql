CREATE NONCLUSTERED INDEX IX_Students_LastName
On dbo.Students (LastName ASC);