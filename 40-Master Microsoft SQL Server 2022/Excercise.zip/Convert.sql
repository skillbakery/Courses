USE AdventureWorks2022;

-- Using CONVERT to convert OrderDate to varchar
SELECT OrderDate AS OriginalOrderDate,
       CONVERT(varchar(20), OrderDate, 105) AS OrderDateAsString
FROM Sales.SalesOrderHeader;
