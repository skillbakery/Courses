/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [CourseID]
      ,[CourseName]
      ,[CoursePrice]
      ,[Publisher]
      ,[AddedOn]
  FROM [SkillBakery].[dbo].[Courses]

INSERT INTO Courses (CourseName, CoursePrice, Publisher, AddedOn)
VALUES
    ('Advanced CSS3 Techniques', 129.99, 'DesignMinds', '2023-07-26 09:15:00'),
    ('Node.js Fundamentals', 179.99, 'DevX Academy', '2023-07-26 13:00:00'),
    ('Database Design with SQL', 149.99, 'DataTech Learning', '2023-07-26 17:30:00');
