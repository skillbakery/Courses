USE AdventureWorks2022;

-- Using UNION to retrieve distinct order dates from sales and purchase orders
SELECT OrderDate
FROM Sales.SalesOrderHeader
UNION
SELECT OrderDate
FROM Purchasing.PurchaseOrderHeader;

-- Using UNION ALL to retrieve all order dates from sales and purchase orders (including duplicates)
SELECT OrderDate
FROM Sales.SalesOrderHeader
UNION ALL
SELECT OrderDate
FROM Purchasing.PurchaseOrderHeader;
