--DECLARE @Counter INT = 1;

WHILE @Counter <= 10
BEGIN
    IF @Counter % 2 = 0
    BEGIN
        PRINT 'First even number found: ' + CAST(@Counter AS NVARCHAR);
        BREAK; -- Exit the loop
    END;
    SET @Counter = @Counter + 1;
END;

DECLARE @Counter INT = 1;
DECLARE @EvenCount INT = 0;

WHILE @Counter <= 10
BEGIN
    IF @Counter % 2 = 0
    BEGIN
        PRINT 'Even number found: ' + CAST(@Counter AS NVARCHAR);
        SET @EvenCount = @EvenCount + 1;

        IF @EvenCount >= 3
        BEGIN
            BREAK; -- Exit the loop when three even numbers are found
        END;
    END
    ELSE
    BEGIN
        -- Skip odd numbers
        SET @Counter = @Counter + 1;
        CONTINUE;
    END;

    SET @Counter = @Counter + 1;
END;
