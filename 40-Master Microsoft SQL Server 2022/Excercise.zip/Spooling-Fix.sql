/****** Script for SelectTopNRows command from SSMS  ******/
SET STATISTICS TIME ON;
SET STATISTICS IO ON;

With Customer As 
(
	Select Year(AccountOpenedDate) [Year],Max(AccountOpenedDate) [AccountOpenedDate]
	from Sales.Customers s 
	Group By Year(AccountOpenedDate)
)
Select CustomerId,CustomerName,Customer.AccountOpenedDate from Sales.Customers p 
inner join 
Customer on p.AccountOpenedDate = Customer.AccountOpenedDate;