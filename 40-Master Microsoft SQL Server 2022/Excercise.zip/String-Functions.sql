/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) 
	   [BusinessEntityID]
      ,[PersonType]
      ,[NameStyle]
      ,[Title]
	  ,LEN([FirstName]) 'Length'
      ,Upper([FirstName]) 'FIRST'
      ,[MiddleName]
      ,Lower([LastName]) 'last'
	  ,LEFT([LastName],2) 'FirstTwo'
	  ,RIGHT([LastName],2) 'LastTwo'
	  ,TRIM([FIRSTNAME]) 'Trimmed'
      ,[Suffix]
      ,[EmailPromotion]
      ,[AdditionalContactInfo]
      ,[Demographics]
      ,[rowguid]
      ,[ModifiedDate]
  FROM [AdventureWorks2022].[Person].[Person]