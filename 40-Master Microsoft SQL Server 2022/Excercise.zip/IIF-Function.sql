/****** Script for SelectTopNRows command from SSMS  ******/
SELECT BusinessEntityId
,SalesYTD
,IIF(SalesYTD>1000000, 'True','False') As SalesStatus
FROM [AdventureWorks2022].[Sales].[SalesPerson]