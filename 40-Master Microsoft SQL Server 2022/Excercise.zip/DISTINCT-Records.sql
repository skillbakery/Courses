/****** Script for SelectTopNRows command from SSMS  ******/
SELECT DISTINCT StateProvinceID,City
FROM [AdventureWorks2022].[Person].[Address]
Order By StateProvinceID