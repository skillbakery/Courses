SELECT p.Name AS ProductName
FROM Production.Product p
WHERE p.ProductID IN (
    SELECT sod.ProductID
    FROM Sales.SalesOrderDetail sod
);

SELECT psc.Name AS SubcategoryName, AVG(p.ListPrice) AS AvgSubcategoryPrice
FROM Production.Product p
JOIN Production.ProductSubcategory psc ON p.ProductSubcategoryID = psc.ProductSubcategoryID
GROUP BY psc.Name
HAVING AVG(p.ListPrice) > (
    SELECT AVG(ListPrice)
    FROM Production.Product
);
