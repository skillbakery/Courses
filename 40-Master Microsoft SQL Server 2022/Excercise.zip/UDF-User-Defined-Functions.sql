USE Skillbakery;


-- Create a user-defined table function to generate a sequence of numbers
CREATE FUNCTION dbo.GenerateNumbers (@start INT, @end INT)
RETURNS TABLE
AS
RETURN
(
    WITH Numbers AS
    (
        SELECT @start AS Number
        UNION ALL
        SELECT Number + 1
        FROM Numbers
        WHERE Number < @end
    )
    SELECT Number
    FROM Numbers
);

SELECT Number
FROM dbo.GenerateNumbers(1, 10);
