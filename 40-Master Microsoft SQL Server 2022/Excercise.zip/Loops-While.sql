Declare @Counter INT = 1
Declare @Product INT = 700

While @Counter <=5
Begin
	Select ProductId, Name, ProductNumber,Color,ListPrice
	From Production.Product
	Where ProductId=@Product

	Set @Counter +=1
	Set @Product +=10
End