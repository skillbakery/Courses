DECLARE @OrderID INT = 43858;
DECLARE @TotalAmount DECIMAL(18, 2);

SELECT @TotalAmount = SUM(UnitPrice * OrderQty)
FROM Sales.SalesOrderDetail
WHERE SalesOrderID = @OrderID;

PRINT 'Total amount for Order ' + CAST(@OrderID AS NVARCHAR) + ': $' + CAST(@TotalAmount AS NVARCHAR);

