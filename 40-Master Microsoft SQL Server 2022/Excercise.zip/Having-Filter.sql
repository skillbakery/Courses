Select * from Production.Product

Select Color,Count(*) ProductCount from Production.Product
Where Color is not null
Group By Color
Having Count(*) > 25