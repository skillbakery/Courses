-- Create a trigger named trg_UpdateLastModified
CREATE TRIGGER trg_UpdateLastModified
ON HumanResources.Employee
AFTER UPDATE
AS
BEGIN
    IF UPDATE (NationalIDNumber) OR UPDATE (JobTitle)
    BEGIN
        UPDATE HumanResources.Employee
        SET ModifiedDate = GETDATE()
        FROM inserted i
        WHERE HumanResources.Employee.BusinessEntityID = i.BusinessEntityID;
    END
END;
