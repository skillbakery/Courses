/*Mathematical Functions*/
SELECT 
UnitPrice
,Round(UnitPrice,2) 'RoundedOff'
,Round(UnitPrice,-2) 'Rounded'
,Ceiling(UnitPrice) Ceil
,Floor(UnitPrice) 'Floor'
FROM [AdventureWorks2022].[Sales].[SalesOrderDetail]
