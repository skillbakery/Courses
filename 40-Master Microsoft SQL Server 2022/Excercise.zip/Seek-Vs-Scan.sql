/****** Script for SelectTopNRows command from SSMS  ******/
select FirstName,LastName,MiddleName 
from Person.Person 

select FirstName,LastName,MiddleName 
from Person.Person 
where FirstName='Kim' and LastName='Abercrombie'