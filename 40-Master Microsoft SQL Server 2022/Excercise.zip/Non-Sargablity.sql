Set Statistics Time On;
Set Statistics IO On;

select FirstName,LastName,MiddleName 
from Person.Person 
where FirstName='Kim' and LastName='ABERCROMBIE'