DECLARE @ProductID INT, @OrderQty INT;

DECLARE ProductCursor CURSOR FOR
SELECT ProductID, OrderQty
FROM Sales.SalesOrderDetail;

OPEN ProductCursor;

FETCH NEXT FROM ProductCursor INTO @ProductID, @OrderQty;

WHILE @@FETCH_STATUS = 0
BEGIN
    -- Perform calculations on the current row
    DECLARE @TotalAmount DECIMAL(18, 2);
    SET @TotalAmount = @OrderQty * (SELECT ListPrice FROM Production.Product WHERE ProductID = @ProductID);
    
    -- Update or process data based on calculations
    -- ...
    Print @TotalAmount;

    FETCH NEXT FROM ProductCursor INTO @ProductID, @OrderQty;
END;

CLOSE ProductCursor;
DEALLOCATE ProductCursor;
