USE WideWorldImporters;

WITH TopSellingProducts AS (
    SELECT
        StockItemID,
        SUM(Quantity * UnitPrice) AS TotalSales
    FROM Sales.OrderLines
    GROUP BY StockItemID
)
SELECT
    p.StockItemName,
    ts.TotalSales
FROM TopSellingProducts ts
JOIN Warehouse.StockItems p ON ts.StockItemID = p.StockItemID
ORDER BY ts.TotalSales DESC;

