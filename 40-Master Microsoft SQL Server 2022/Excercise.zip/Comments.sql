USE AdventureWorks2022;
Go

/*
Multi Line Comment
*/
--

/* Selecting Persons from the Person Table */
SELECT  [BusinessEntityID]
      ,[PersonType]
      ,[NameStyle]
      ,[Title]
      ,[FirstName] As [First Name]
      ,[MiddleName]
      ,[LastName]
      --,[Suffix]
      ,[EmailPromotion]
      ,[AdditionalContactInfo]
      ,[Demographics]
      ,[rowguid]
      ,[ModifiedDate]
  FROM [AdventureWorks2022].[Person].[Person]