DBCC CHECKDB

DBCC CHECKDB('SkillBakery',REPAIR_ALL_Data_Loss)

DBCC CheckFileGroup (0,NoIndex)
With Physical_Only,EstimateOnly