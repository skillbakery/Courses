select compatibility_level 
from  sys.databases 
Where name='AdventureWorks2022'

Alter Database AdventureWorks2022
SET compatibility_level=160;

Select Value from Generate_Series(1,20,2)

Declare @start decimal(2,1) = 0.0
Declare @stop decimal(2,1) = 1.0
Declare @incr decimal(2,1) = 0.1

Select Value from Generate_Series(@start,@stop,@incr)