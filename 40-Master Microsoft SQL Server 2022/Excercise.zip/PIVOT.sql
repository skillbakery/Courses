SELECT p.Name AS ProductName, p.Color, sod.OrderQty
    FROM Production.Product p
    JOIN Sales.SalesOrderDetail sod ON p.ProductID = sod.ProductID

SELECT *
FROM (
    SELECT p.Name AS ProductName, p.Color, sod.OrderQty
    FROM Production.Product p
    JOIN Sales.SalesOrderDetail sod ON p.ProductID = sod.ProductID
) AS SourceTable
PIVOT (
    SUM(OrderQty)
    FOR Color IN ([Black], [Blue], [Silver], [Red], [Yellow],[Multi])
) AS PivotTable;
