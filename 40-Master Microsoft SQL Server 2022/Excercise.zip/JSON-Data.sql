--Converting relational to JSON
SELECT .... FOR JSON {AUTO | PATH}
IsJSON
JSON_VALUE,JSON_Query, and JSON_Modify
Select ... FROM OpenJSON(...)

Select top 10
PersonId,
UserPreferences,
CustomFields
From Application.People

Select top 10
PersonId,
IsJSON(UserPreferences) 'JSONData'
From Application.People

Select Top 10
Application.People.FullName,
Sales.Invoices.InvoiceDate,
CustomerPurchaseOrderNumber
From Sales.Invoices
Inner join Application.People On Sales.Invoices.SalespersonPersonID = Application.People.PersonID
Order by CustomerPurchaseOrderNumber
For JSON AUTO

Select 
PersonId,
JSON_VALUE(UserPreferences, '$.theme') AS Theme
FROM Application.People;

Select 
PersonId,
JSON_Query(UserPreferences, '$.table') AS Theme
FROM Application.People;

UPDATE Application.People
SET UserPreferences = JSON_MODIFY(UserPreferences, '$.theme', 'light')
WHERE PersonID = 1;

UPDATE Application.People
SET UserPreferences = JSON_MODIFY(UserPreferences, '$.newPreference', 'JSON')
WHERE PersonID = 1;

SELECT j.*
FROM Application.People
CROSS APPLY OPENJSON(CustomFields)
WITH (
  Title NVARCHAR(100) '$.Title',
  HireDate DateTime '$.HireDate'
) AS j;