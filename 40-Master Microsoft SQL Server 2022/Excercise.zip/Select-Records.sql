SELECT 100
SELECT GETDATE()
SELECT 'John'

SELECT [Name] 'DepartmentName',
GroupName,
ModifiedDate
From
HumanResources.Department