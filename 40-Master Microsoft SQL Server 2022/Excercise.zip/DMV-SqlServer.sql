-- Retrieve currently executing requests
SELECT * FROM sys.dm_exec_requests;

-- Get performance counter information
SELECT * FROM sys.dm_os_performance_counters;

-- Identify top waiting types
SELECT * FROM sys.dm_os_wait_stats ORDER BY wait_time_ms DESC;

-- Analyze query execution statistics
SELECT TOP 10
    qs.total_worker_time,
    qs.total_physical_reads,
    qs.total_logical_writes,
    qt.text
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS qt
ORDER BY qs.total_worker_time DESC;

-- View cached query plans
SELECT * FROM sys.dm_exec_cached_plans;

-- Retrieve details about a specific query plan
DECLARE @PlanHandle VARBINARY(64);

-- Replace 'YourPlanHandleHere' with the actual plan handle value
SET @PlanHandle = 0x0500FF7F406DF3E7505FFE3C0E02000001000000000000000000000000000000000000000000000000000000

SELECT query_plan
FROM sys.dm_exec_query_plan(@PlanHandle);
