CREATE VIEW dbo.vw_StudentOrders  
AS  
SELECT TOP (100) PERCENT dbo.Courses.CourseName AS [Course Name], dbo.Courses.CoursePrice AS [Course Price], dbo.Courses.Publisher, dbo.Orders.OrderDate, dbo.Orders.Qty, dbo.Students.FirstName AS [First Name],   
                  dbo.Students.LastName AS [Last Name], dbo.Students.Email  
FROM     dbo.Orders INNER JOIN  
                  dbo.Courses ON dbo.Orders.CourseId = dbo.Courses.CourseID INNER JOIN  
                  dbo.Students ON dbo.Orders.StudentId = dbo.Students.StudentIId  
ORDER BY [First Name]  
