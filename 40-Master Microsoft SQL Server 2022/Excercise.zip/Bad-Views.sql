CREATE VIEW BadCustomerOrdersView AS
SELECT
    C.CustomerID,
    C.CustomerName,
    C.CustomerCategoryID,
    O.OrderID,
    O.OrderDate,
    OD.[Description],
    OD.Quantity
FROM
    Sales.Customers C
    JOIN Sales.Orders O ON C.CustomerID = O.CustomerID
    JOIN Sales.OrderLines OD ON O.OrderID = OD.OrderID;


SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT 
CustomerID,
CustomerName,
CustomerCategoryID,
OrderID,
OrderDate,
[Description],
Quantity
FROM BadCustomerOrdersView
WHERE CustomerID = 1005;

CREATE VIEW GoodCustomerOrdersView AS
SELECT
    C.CustomerID,
    C.CustomerName,
    O.OrderID,
    O.OrderDate
FROM
    Sales.Customers C
    JOIN Sales.Orders O ON C.CustomerID = O.CustomerID;

CREATE NONCLUSTERED INDEX IX_CustomerID ON Sales.Customers (CustomerID);
CREATE NONCLUSTERED INDEX IX_OrderCustomerID ON Sales.Orders (CustomerID);

SET STATISTICS TIME ON;
SET STATISTICS IO ON;
SELECT *
FROM GoodCustomerOrdersView
WHERE CustomerID = 1005;