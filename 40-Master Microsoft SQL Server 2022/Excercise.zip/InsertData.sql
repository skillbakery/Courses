Use Skillbakery
Go

INSERT INTO CourseCategories (CategoryName,DateAdded)
VALUES ('Web Development',getDate()),
('Desktop Applications',getDate())