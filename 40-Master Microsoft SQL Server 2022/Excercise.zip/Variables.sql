Declare @FirstName varchar(100)
Set @FirstName='Jack'

/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [StudentIId]
      ,[FirstName]
      ,[LastName]
      ,[MiddleName]
      ,[DateOfBirth]
      ,[Email]
      ,[Address]
      ,[State]
      ,[CreatedDate]
  FROM [SkillBakery].[dbo].[Students]
  Where FirstName=@FirstName


