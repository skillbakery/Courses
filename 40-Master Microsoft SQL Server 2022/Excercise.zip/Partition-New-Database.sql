-- switch the active database
USE PartitionTables;
GO

-- create partition function:
CREATE PARTITION FUNCTION PFYears (smallint)
AS RANGE LEFT
FOR VALUES (2020, 2021, 2022);
GO

-- create partition scheme
CREATE PARTITION SCHEME PSYears
AS PARTITION PFYears
TO (FG_2020, FG_2021, FG_2022, [PRIMARY]);
GO

-- create table within partition scheme
CREATE TABLE dbo.Orders(
    OrderYear smallint NOT NULL,
    OrderID int IDENTITY(1,1) NOT NULL,
    PRIMARY KEY (OrderYear, OrderID))
    ON PSYears(OrderYear);
GO

-- insert values into table
INSERT dbo.Orders
    VALUES  (2020),
            (2020),
            (2021),
            (2022);
GO

SELECT * from dbo.Orders;
GO

-- view the number of records in each partition using a system function
SELECT $PARTITION.PFYears(OrderYear) AS Partition,
    COUNT(*) AS [COUNT] FROM dbo.Orders
    GROUP BY $PARTITION.PFYears(OrderYear)
    ORDER BY Partition;
GO

-- view all of the records on a specified partition (3)
SELECT * FROM dbo.Orders
    WHERE $PARTITION.PFYears(OrderYear) = 3;
GO
