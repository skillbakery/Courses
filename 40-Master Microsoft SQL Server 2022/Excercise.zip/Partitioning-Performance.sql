SET Statistics IO ON;

SELECT [OrderID]
      ,[CustomerID]
      ,[SalespersonPersonID]
      ,[PickedByPersonID]
      ,[ContactPersonID]
      ,[BackorderOrderID]
      ,[OrderDate]
      ,[ExpectedDeliveryDate]
      ,[CustomerPurchaseOrderNumber]
      ,[IsUndersupplyBackordered]
      ,[Comments]
      ,[DeliveryInstructions]
      ,[InternalComments]
      ,[PickingCompletedWhen]
      ,[LastEditedBy]
      ,[LastEditedWhen]
  FROM [WideWorldImporters].[Sales].[Orders]
  Where OrderDate >= Convert(Date,'2013-01-01') and OrderDate <=Convert(Date,'2013-11-30')
  Order by OrderDate Desc

  -- view the number of records in each partition using a system function
SELECT $PARTITION.PFOrderYears(OrderDate) AS Partition,
    COUNT(*) AS [COUNT] FROM [Sales].Orders
    GROUP BY $PARTITION.PFOrderYears(OrderDate)
    ORDER BY Partition;
Go