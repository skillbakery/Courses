Select BusinessEntityId
,VacationHours
,SickLeaveHours
,Greatest(VacationHours,SickLeaveHours) 'Greatest'
,Least(VacationHours,SickLeaveHours) 'Least'
From HumanResources.Employee
