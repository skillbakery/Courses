BACKUP DATABASE [SkillBakery] TO  DISK = N'C:\Program Files\Microsoft SQL Server\MSSQL16.MSSQLSERVER02\MSSQL\Backup\SkillBakery.bak' WITH NOFORMAT, NOINIT,  NAME = N'SkillBakery-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO
