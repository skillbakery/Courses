BEGIN Transaction

UPDATE Warehouse.StockItems
SET QuantityPerOuter = QuantityPerOuter - 10
WHERE StockItemID = 1;

UPDATE Warehouse.StockItems
SET QuantityPerOuter = QuantityPerOuter + 10
WHERE StockItemID = 2;

COMMIT;