select GetDate()

Select BusinessEntityID,
HireDate,
Year(HireDate) Hireyear,
Month(HireDate) MonthHire,
Day(HireDate) DayOfHire,
DateDiff(day,HireDate,GetDate()) 'DaysSinceHire',
DateDiff(YEAR,HireDate,GetDate()) 'DaysSinceHire',
DateADD(Year,10,HireDate) 'Added'
from HumanResources.Employee