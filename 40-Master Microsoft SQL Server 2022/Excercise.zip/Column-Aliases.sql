SELECT Name AS 'ProductName','AdevtureWorks' 'CompanyName',
ListPrice * .80 AS 'SalePrice'
From
Production.Product
Where ListPrice > 0