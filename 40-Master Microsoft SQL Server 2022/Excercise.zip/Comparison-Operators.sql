--Comparison Operators
/*
Standard Operator
1. = Equal To
2. < Less Than
3. > Greater Than
4. >= Greater Than or Equal To
5. <= Less Than or Equal To
6. <> Not Equal To

Non Standard Oerators
1. != Not Equal To
2. !< Not Less Than
3. !> Not Greater Than
*/

SELECT Name,TaxRate
FROM [AdventureWorks2022].[Sales].[SalesTaxRate]
Where TaxRate != 7 
Order By TaxRate