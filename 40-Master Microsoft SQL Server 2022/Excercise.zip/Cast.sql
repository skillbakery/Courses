USE AdventureWorks2022;

-- Using CAST to convert OrderDate to varchar
SELECT OrderDate AS OriginalOrderDate,
       CAST(OrderDate AS varchar(20)) AS OrderDateAsString
FROM Sales.SalesOrderHeader;


