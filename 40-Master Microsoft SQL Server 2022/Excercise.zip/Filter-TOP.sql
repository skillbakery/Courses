/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP 50 PERCENT
       [TaxType]
      ,[TaxRate]
      ,[Name]
  FROM [AdventureWorks2022].[Sales].[SalesTaxRate]
  ORDER BY TaxRate DESC