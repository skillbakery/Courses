Select BusinessEntityID,
Format(HireDate,'dddd,MMMM dd, yyyy')
from HumanResources.Employee