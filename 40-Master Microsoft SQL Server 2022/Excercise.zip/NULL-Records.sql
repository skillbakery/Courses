/****** Script for SelectTopNRows command from SSMS  ******/
SELECT [WorkOrderID]
      ,[ProductID]
      ,[OrderQty]
      ,[StockedQty]
      ,[ScrappedQty]
      ,[StartDate]
      ,[EndDate]
      ,[DueDate]
      ,ISNULL([ScrapReasonID],999) 'ScrapReasonID'
      ,[ModifiedDate]
  FROM [AdventureWorks2022].[Production].[WorkOrder]
  WHERE ScrapReasonID IS NULL