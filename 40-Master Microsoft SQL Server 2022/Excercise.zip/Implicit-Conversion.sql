Set Statistics Time On;
Set Statistics IO On;

Select p.FirstName,
p.LastName,
c.AccountNumber
from
Sales.Customer As c
Inner join
Person.Person p
on c.PersonID = p.BusinessEntityID
Where AccountNumber=N'AW00011394'