SELECT Top 10 WorkOrderID, NEWID() As NewID FROM
Production.WorkOrder
Order By NewID