DELETE FROM Students where StudentIId=1000

DELETE FROM Students where StudentIId=1006