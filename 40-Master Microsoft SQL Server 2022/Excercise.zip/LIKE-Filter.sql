/****** Script for SelectTopNRows command from SSMS  ******/
SELECT 
       [Title]
      ,[FirstName]
FROM [AdventureWorks2022].[Person].[Person]
Where FirstName Like 'A[^D-F]___'