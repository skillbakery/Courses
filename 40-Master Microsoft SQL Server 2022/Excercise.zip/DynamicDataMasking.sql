--Alter table Students
Alter Column Email ADD Masked with (FUNCTION = 'email()');

Grant Select on Schema :: [dbo] to John;

--Default
--ADD MASKED WITH (FUNCTION = 'default()')

--Partial Masking:
--ADD MASKED WITH (FUNCTION = 'partial(prefix_length, suffix_length)')

--Random
--ADD MASKED WITH (FUNCTION = 'random([percentage])')

--Custom String Masking:
--ADD MASKED WITH (FUNCTION = 'custom_string([prefix], replacement, [suffix])')

--Custom Function Masking:
--ADD MASKED WITH (FUNCTION = 'custom_function([expression])')

