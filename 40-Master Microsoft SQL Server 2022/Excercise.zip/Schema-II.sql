Create Schema sales;
Go

Alter Schema sales Transfer dbo.Orders;
Go

select * from Courses
select * from sales.Orders

Grant Insert on Schema :: sales to John;