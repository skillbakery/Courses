SELECT ProductID, Name, ListPrice
FROM Production.Product
ORDER BY ProductID
OFFSET 0 ROWS FETCH NEXT 10 ROWS ONLY;