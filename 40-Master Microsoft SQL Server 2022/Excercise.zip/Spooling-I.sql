/****** Script for SelectTopNRows command from SSMS  ******/
SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT CustomerId,CustomerName,AccountOpenedDate
FROM Sales.Customers S
where AccountOpenedDate in 
(
	Select Max(AccountOpenedDate) from Sales.Customers p 
	where Year(p.AccountOpenedDate)=Year(s.AccountOpenedDate)
	Group By Year(AccountOpenedDate)
)
Order By AccountOpenedDate;