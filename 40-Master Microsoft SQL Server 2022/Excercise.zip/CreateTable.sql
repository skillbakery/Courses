CREATE TABLE CourseCategories (
 CategoryId int Identity(1,1) Not NULL,
 CategoryName varchar(50) Not Null,
 DateAdded datetime Not Null
PRIMARY KEY CLUSTERED 
(
	[CategoryId] ASC
))