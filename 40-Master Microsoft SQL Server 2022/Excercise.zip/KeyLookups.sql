CREATE NONCLUSTERED INDEX IX_Orders_CustomerID_Covering
ON Sales.Orders (CustomerID)
INCLUDE (OrderID, OrderDate);

SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT OrderID, OrderDate
FROM Sales.Orders
WHERE CustomerID = 1001;