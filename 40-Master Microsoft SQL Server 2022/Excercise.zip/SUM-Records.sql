/****** Script for SelectTopNRows command from SSMS  ******/
SELECT *
FROM [AdventureWorks2022].[Sales].[SalesOrderDetail]

SELECT 
	SalesOrderId
	, SUM(LineTotal) 'OrderTotal'
	, SUM(OrderQty) 'TotalItems'
	, COUNT(DISTINCT ProductID) 'Products'
FROM [AdventureWorks2022].[Sales].[SalesOrderDetail]
Group By SalesOrderId
Order by OrderTotal DESC