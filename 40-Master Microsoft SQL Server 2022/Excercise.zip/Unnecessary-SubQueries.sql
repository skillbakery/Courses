SET STATISTICS TIME ON;
SET STATISTICS IO ON;
SELECT s.FirstName,s.LastName,s.Email,s.DateOfBirth,s.Address,s.State 
FROM Students s 
WHERE StudentIId IN (SELECT o.StudentId FROM sales.Orders o);