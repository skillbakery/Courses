SET STATISTICS TIME ON;
SET STATISTICS IO ON;
SELECT s.FirstName,s.LastName,s.Email,s.DateOfBirth,s.Address,s.State 
FROM Students s 
JOIN sales.Orders o ON s.StudentIId = o.StudentId 