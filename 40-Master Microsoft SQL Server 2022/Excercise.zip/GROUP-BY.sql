/****** Script for SelectTopNRows command from SSMS  ******/
SELECT City,StateProvinceID,COUNT(City) 'AddressCount'
FROM [AdventureWorks2022].[Person].[Address]
Group By City,StateProvinceID
Order BY AddressCount DESC