/****** Script for SelectTopNRows command from SSMS  ******/
SELECT 
       [FirstName]
      ,[MiddleName]
      ,[LastName]
	  , FirstName + ' '+MiddleName + ' '+ LastName AS FULLName
	  , CONCAT(FirstName, ' ',MiddleName,' ', LastName) 'FName'
	  , CONCAT_WS(' ', FirstName,MiddleName,LastName) 'Name'
FROM [AdventureWorks2022].[Person].[Person]