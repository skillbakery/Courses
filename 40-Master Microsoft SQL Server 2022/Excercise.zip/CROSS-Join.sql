SELECT 
Department.Name 
FROM HumanResources.Department;

SELECT AddressType.Name
FROM Person.AddressType;

SELECT Department.Name 'Department',
AddressType.Name 'AddressType'
FROM HumanResources.Department
CROSS JOIN Person.AddressType;