-- Create an index on Customer.CustomerID
CREATE NONCLUSTERED INDEX IX_Customer_CustomerID 
ON Sales.Customer (CustomerID);


SET STATISTICS TIME ON;
SET STATISTICS IO ON;
SELECT 
    soh.SalesOrderID,
    c.CustomerID,
    soh.OrderDate
FROM 
    Sales.SalesOrderHeader AS soh
JOIN 
    Sales.Customer AS c
ON 
    soh.CustomerID = c.CustomerID