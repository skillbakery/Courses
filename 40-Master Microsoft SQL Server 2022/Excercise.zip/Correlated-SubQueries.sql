SELECT P.BusinessEntityID
, P.FirstName
, P.LastName
, E.JobTitle
From Person.Person P
INNER JOIN HumanResources.Employee E
ON P.BusinessEntityID = E.BusinessEntityID


SELECT P.BusinessEntityID
, P.FirstName
, P.LastName
, (Select JobTitle From HumanResources.Employee 
	Where BusinessEntityID=P.BusinessEntityID) As JobTitle
From Person.Person P
Where 
(Select JobTitle From HumanResources.Employee 
	Where BusinessEntityID=P.BusinessEntityID) IS Not NULL