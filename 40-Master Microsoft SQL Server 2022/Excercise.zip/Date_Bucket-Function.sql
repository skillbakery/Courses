SELECT DATE_BUCKET(week,1, InvoiceDate) as InvoiceWeek, 
    COUNT(CustomerId) as CustomerCount
  FROM Sales.Invoices
  GROUP BY DATE_BUCKET(week,1, InvoiceDate)
  ORDER BY InvoiceWeek 