/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [OrderId]
      ,[StudentId]
      ,[CourseId]
      ,[OrderDate]
      ,[Qty]
  FROM [SkillBakery].[sales].[Orders]

  Insert into sales.Orders (StudentId,CourseId,OrderDate,Qty) 
  Values (1003,3,'2023-08-10',1)