SELECT 
s.FirstName, 
s.LastName,
O.OrderId,
O.OrderDate 
FROM Students s 
FULL OUTER join Orders O 
ON s.StudentIId=O.StudentId


