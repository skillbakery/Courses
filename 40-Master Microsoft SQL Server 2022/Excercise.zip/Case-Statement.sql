SELECT
    JobTitle,
    CASE
        WHEN JobTitle LIKE '%Manager%' THEN 'Manager'
        WHEN JobTitle LIKE '%Assistant%' OR JobTitle LIKE '%Associate%' THEN 'Staff'
        ELSE 'Other'
    END AS EmployeeCategory
FROM HumanResources.Employee
Order by EmployeeCategory