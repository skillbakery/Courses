﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace AzureCosmos
{
    public static class CosmosDBRepository<T> where T : class
    {
        private static readonly string DatabaseId = ConfigurationManager.AppSettings["database"];
        private static readonly string CollectionId = ConfigurationManager.AppSettings["collection"];
        private static readonly string UserCollection = ConfigurationManager.AppSettings["users"];

        private static DocumentClient client;
        public static async void Initialize()
        {
            client = new DocumentClient(new Uri(ConfigurationManager.AppSettings["endpoint"]), ConfigurationManager.AppSettings["authKey"]);
            //CreateDatabaseIfNotExistsAsync().Wait();
            //CreateCollectionIfNotExistsAsync().Wait();

            //CreateCollectionWithIndexIfNotExistsAsync().Wait();

            //ChangeCollectionThroughput(DatabaseId, UserCollection).Wait();

            //string filePtah = Path.Combine(HttpRuntime.AppDomainAppPath, "App_Data")+"/users.json";
            //AddJsonFromFile(UserCollection, filePtah);
            //var cProfile = await CosmosDBRepository<User>.GetUsersAsync();
            //var cProfile =  await CosmosDBRepository<User>.GetUser();

            // var cProfile = await CosmosDBRepository<User>.GetUser("John");
            //var cProfileOther = await CosmosDBRepository<User>.GetUsersAsync(x => x.FirstName !="John");

            //var cUsers = await CosmosDBRepository<User>.GetUsersFromSP("John");
            //var cUDFProfile =  await CosmosDBRepository<User>.GetUDFUser();
            //var cProfile = await CosmosDBRepository<User>.GetUser("John");
            //cProfile.FirstName = "Johnny";
            //await CosmosDBRepository<User>.UpdateItemAsync(cProfile.Id, cProfile, UserCollection);
            //var cProfile = GetAllUsers();
            //var cProfile = await CosmosDBRepository<User>.GetUsersParallel();
            //var cProfile = await CosmosDBRepository<User>.GetUsersSQLQuerySpec();
            //var cProfile = CosmosDBRepository<User>.GetUserSQLProjection();

            var cProfile = await CosmosDBRepository<User>.GetUser("Delete");
            await CosmosDBRepository<User>.DeleteItemAsync(cProfile.Id,  UserCollection);
        }

        static void AddJsonFromFile(string collectionId, string filePath)
        {
            using (StreamReader file = new StreamReader(filePath))
            {
                string line;
                while ((line = file.ReadLine()) != null)
                {
                    byte[] byteArray = Encoding.UTF8.GetBytes(line);
                    using (MemoryStream stream = new MemoryStream(byteArray))
                    {
                        CreateCollectionFromJson(collectionId, stream).Wait();
                    }
                }
            }
        }

        private static async Task CreateDatabaseIfNotExistsAsync()
        {
            try
            {
                await client.ReadDatabaseAsync(UriFactory.CreateDatabaseUri(DatabaseId));
            }
            catch (DocumentClientException e)
            {
                if (e.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    await client.CreateDatabaseAsync(new Database { Id = DatabaseId });
                }
                else
                {
                    throw;
                }
            }
        }

        private static async Task CreateCollectionIfNotExistsAsync()
        {

            try
            {
                await client.ReadDocumentCollectionAsync(UriFactory.CreateDocumentCollectionUri(DatabaseId, CollectionId));
            }
            catch (DocumentClientException e)
            {
                if (e.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    await client.CreateDocumentCollectionAsync(
                        UriFactory.CreateDatabaseUri(DatabaseId),
                        new DocumentCollection { Id = CollectionId },
                        new RequestOptions { OfferThroughput = 1000 });
                }
                else
                {
                    throw;
                }
            }
        }

        private static async Task CreateCollectionWithIndexIfNotExistsAsync()
        {
            IndexingPolicy indexPol = new IndexingPolicy(new RangeIndex(DataType.String){
                Precision=-1
            });
            indexPol.IndexingMode = IndexingMode.Consistent;
            //indexPol.Automatic = false;
            indexPol.IncludedPaths.Add(new IncludedPath { Path = "/*",
                Indexes = new System.Collections.ObjectModel.Collection<Index>()
                {
                    new RangeIndex(DataType.String){
                        Precision=-1
                    }
                }
            });
            indexPol.ExcludedPaths.Add(new ExcludedPath { Path = "/cars/*" });


            try
            {
                await client.ReadDocumentCollectionAsync(UriFactory.CreateDocumentCollectionUri(DatabaseId, UserCollection));
            }
            catch (DocumentClientException e)
            {
                if (e.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    await client.CreateDocumentCollectionAsync(
                        UriFactory.CreateDatabaseUri(DatabaseId),
                        new DocumentCollection { Id = UserCollection, IndexingPolicy = indexPol },
                        new RequestOptions { OfferThroughput = 1000, ConsistencyLevel = ConsistencyLevel.Session });
                }
                else
                {
                    throw;
                }
            }
        }

        private static async Task ChangeCollectionThroughput(string databaseId, string collectionId)
        {
            DocumentCollection collection = await client.ReadDocumentCollectionAsync(UriFactory.CreateDocumentCollectionUri(databaseId, collectionId));
            
            Offer offer = client.CreateOfferQuery().Where(x => x.ResourceLink == collection.SelfLink).AsEnumerable().Single();

            Offer newOffer = await client.ReplaceOfferAsync(new OfferV2(offer, 1100));

            offer = client.CreateOfferQuery().Where(x => x.ResourceLink == collection.SelfLink).AsEnumerable().Single();
            OfferV2 offerV2 = (OfferV2)offer;
        }

        #region Insert Records to Collection
        public static async Task<Document> CreateItemAsync(T item, string CollectionId)
        {
            client = new DocumentClient(new Uri(ConfigurationManager.AppSettings["endpoint"]), ConfigurationManager.AppSettings["authKey"]);

            RequestOptions rOptions = new RequestOptions
            {
                PreTriggerInclude = new List<String> { "AddCreatedDate" }
                //,IndexingDirective = IndexingDirective.Exclude,
                //, IndexingDirective = IndexingDirective.Include
            };
            return await client.CreateDocumentAsync(UriFactory.CreateDocumentCollectionUri(DatabaseId, CollectionId), item, rOptions);
        }

        public static async Task<Document> CreateCollectionFromJson(string CollectionId, Stream stream)
        {
            client = new DocumentClient(new Uri(ConfigurationManager.AppSettings["endpoint"]), ConfigurationManager.AppSettings["authKey"]);
            var collection = await client.ReadDocumentCollectionAsync(UriFactory.CreateDocumentCollectionUri(DatabaseId, CollectionId));

            collection.Resource.IndexingPolicy.IndexingMode = IndexingMode.Lazy;

            collection.Resource.IndexingPolicy = new IndexingPolicy(new RangeIndex(DataType.Number)
            {
                Precision = -1
            });

            Document document = await client.CreateDocumentAsync(collection.Resource.SelfLink, Resource.LoadFrom<Document>(stream));

            return document;
        }
        #endregion

        #region Read from a Collection
        public static async Task<T> GetUser()
        {
            try
            {
                client = new DocumentClient(new Uri(ConfigurationManager.AppSettings["endpoint"]), ConfigurationManager.AppSettings["authKey"]);
                var query = "select * from c";
                var response = client.CreateDocumentQuery(UriFactory.CreateDocumentCollectionUri(DatabaseId, UserCollection), query).ToList();
                var document = (Document)(dynamic)response.First();
                return (T)(dynamic)document;
            }
            catch (DocumentClientException e)
            {
                if (e.StatusCode == HttpStatusCode.NotFound)
                {
                    return null;
                }
                else
                {
                    throw;
                }
            }

        }

        public static async Task<T> GetUser(string firstname)
        {
            try
            {
                client = new DocumentClient(new Uri(ConfigurationManager.AppSettings["endpoint"]), ConfigurationManager.AppSettings["authKey"]);
                var query = "select * from c where c.FirstName ='" + firstname + "'";
                var response = client.CreateDocumentQuery(UriFactory.CreateDocumentCollectionUri(DatabaseId, UserCollection), query).ToList();
                var document = (Document)(dynamic)response.First();
                return (T)(dynamic)document;
            }
            catch (DocumentClientException e)
            {
                if (e.StatusCode == HttpStatusCode.NotFound)
                {
                    return null;
                }
                else
                {
                    throw;
                }
            }

        }
        public static async Task<IEnumerable<T>> GetUsersAsync()
        {
            client = new DocumentClient(new Uri(ConfigurationManager.AppSettings["endpoint"]), ConfigurationManager.AppSettings["authKey"]);

            IDocumentQuery<T> query = client.CreateDocumentQuery<T>(
                UriFactory.CreateDocumentCollectionUri(DatabaseId, UserCollection))
                .AsDocumentQuery();

            List<T> results = new List<T>();
            while (query.HasMoreResults)
            {
                results.AddRange(await query.ExecuteNextAsync<T>());
            }

            return results;
        }

        public static async Task<IEnumerable<T>> GetUsersAsync(Expression<Func<T, bool>> predicate)
        {
            client = new DocumentClient(new Uri(ConfigurationManager.AppSettings["endpoint"]), ConfigurationManager.AppSettings["authKey"]);

            IDocumentQuery<T> query = client.CreateDocumentQuery<T>(
                UriFactory.CreateDocumentCollectionUri(DatabaseId, UserCollection))
                .Where(predicate)
                .AsDocumentQuery();

            List<T> results = new List<T>();
            while (query.HasMoreResults)
            {
                results.AddRange(await query.ExecuteNextAsync<T>());
            }

            return results;
        }


        #endregion

        #region Querying
        public static List<User> GetAllUsers()
        {
            client = new DocumentClient(new Uri(ConfigurationManager.AppSettings["endpoint"]), ConfigurationManager.AppSettings["authKey"]);

            //var users = from user in client.CreateDocumentQuery<User>(
            //            UriFactory.CreateDocumentCollectionUri(DatabaseId, UserCollection),
            //            new FeedOptions { EnableCrossPartitionQuery = true })
            //            select user;

            var users = client.CreateDocumentQuery<User>(
                      UriFactory.CreateDocumentCollectionUri(DatabaseId, UserCollection),
                      new FeedOptions { EnableCrossPartitionQuery = true });


            return users.ToList();
        }

        public static async Task<IEnumerable<User>> GetUsersParallel()
        {
            client = new DocumentClient(new Uri(ConfigurationManager.AppSettings["endpoint"]), ConfigurationManager.AppSettings["authKey"]);
            var options = new FeedOptions
            {
                MaxDegreeOfParallelism = 10,
                MaxBufferedItemCount = 2,
                EnableCrossPartitionQuery = true
            };
            IDocumentQuery<User> query = client.CreateDocumentQuery<User>(
                UriFactory.CreateDocumentCollectionUri(DatabaseId, UserCollection), options)
                .AsDocumentQuery();

            List<User> results = new List<User>();

            while (query.HasMoreResults)
            {
                foreach (User user in await query.ExecuteNextAsync())
                {
                    results.Add(user);
                }
            }

            return results;
        }

        public static async Task<IEnumerable<User>> GetUsersSQLQuerySpec()
        {
            client = new DocumentClient(new Uri(ConfigurationManager.AppSettings["endpoint"]), ConfigurationManager.AppSettings["authKey"]);
            var options = new SqlQuerySpec
            {
                QueryText = "select * from Users c where (c.FirstName = @name) and (c.LastName=@lname)",
                Parameters = new SqlParameterCollection()
               {
                   new SqlParameter("@name","Matt"),
                   new SqlParameter("@lname","Dormont")
               }
            };
            var query = client.CreateDocumentQuery<User>(
                UriFactory.CreateDocumentCollectionUri(DatabaseId, UserCollection), options, new FeedOptions { EnableScanInQuery=true , EnableCrossPartitionQuery = true })
                .ToList();

            return query;
        }

        public static IEnumerable<User> GetUserSQLProjection()
        {
            client = new DocumentClient(new Uri(ConfigurationManager.AppSettings["endpoint"]), ConfigurationManager.AppSettings["authKey"]);


            var users = (from u in client.CreateDocumentQuery<User>(UriFactory.CreateDocumentCollectionUri(DatabaseId, UserCollection),
                new FeedOptions { EnableCrossPartitionQuery = true })
                         where u.Balance >= 3000 //!= "Matt" 
                         select new User { FirstName = u.FirstName, LastName = u.LastName }).ToList();

            var results = client.CreateDocumentQuery<User>(UriFactory.CreateDocumentCollectionUri(DatabaseId, UserCollection),
                new FeedOptions { EnableCrossPartitionQuery = true }).Where(x => x.Balance >= 3000)
                .Select(x => new User { FirstName = x.FirstName, LastName = x.LastName }).ToList();

            var query = client.CreateDocumentQuery<User>(UriFactory.CreateDocumentCollectionUri(DatabaseId, UserCollection),
                "select u.FirstName, u.LastName from users u where u.Balance >= 3000", new FeedOptions { EnableCrossPartitionQuery = true }).ToList();

            return results;
        }

        #endregion

        #region Stored Procedure
        public static async Task<IEnumerable<User>> GetUsersFromSP(string param)
        {
            try
            {
                client = new DocumentClient(new Uri(ConfigurationManager.AppSettings["endpoint"]), ConfigurationManager.AppSettings["authKey"]);
                String[] procedureParams = new String[1] { param };
                var response = await client.ExecuteStoredProcedureAsync<string>(UriFactory.CreateStoredProcedureUri(DatabaseId, UserCollection, "GetUsers"), procedureParams);
                List<User> user = new List<User>();
                if (!string.IsNullOrEmpty(response.Response))
                {
                    JObject o = JObject.Parse(response.Response);
                    JArray a = (JArray)o["feed"];
                    user = a.ToObject<List<User>>();
                }

                return user;
            }
            catch (DocumentClientException e)
            {
                if (e.StatusCode == HttpStatusCode.NotFound)
                {
                    return null;
                }
                else
                {
                    throw;
                }
            }
        }
        #endregion

        #region UDF
        public static async Task<T> GetUDFUser()
        {
            try
            {
                client = new DocumentClient(new Uri(ConfigurationManager.AppSettings["endpoint"]), ConfigurationManager.AppSettings["authKey"]);
                DocumentCollection collection = await client.ReadDocumentCollectionAsync(UriFactory.CreateDocumentCollectionUri(DatabaseId, UserCollection));

                UserDefinedFunction userDefinedFunction =
                client.CreateUserDefinedFunctionQuery(collection.UserDefinedFunctionsLink)
                    .Where(udf => udf.Id == "GetName")
                    .AsEnumerable()
                    .FirstOrDefault();

                var query = "select udf.GetName(c) as FullName from c";
                var response = client.CreateDocumentQuery(UriFactory.CreateDocumentCollectionUri(DatabaseId, UserCollection), query,
                    new FeedOptions { EnableCrossPartitionQuery = true }).ToList();
                var document = (Document)(dynamic)response.First();
                return (T)(dynamic)document;
            }
            catch (DocumentClientException e)
            {
                if (e.StatusCode == HttpStatusCode.NotFound)
                {
                    return null;
                }
                else
                {
                    throw;
                }
            }
        }
        #endregion

        #region Update Collection
        public static async Task<Document> UpdateItemAsync(string id, T item, string CollectionId)
        {
            client = new DocumentClient(new Uri(ConfigurationManager.AppSettings["endpoint"]), ConfigurationManager.AppSettings["authKey"]);
            return await client.ReplaceDocumentAsync(UriFactory.CreateDocumentUri(DatabaseId, CollectionId, id), item);
        }

        #endregion

        #region Delete Collection
        public static async Task<Document> DeleteItemAsync(string id, string CollectionId)
        {
            client = new DocumentClient(new Uri(ConfigurationManager.AppSettings["endpoint"]), ConfigurationManager.AppSettings["authKey"]);
            return await client.DeleteDocumentAsync(UriFactory.CreateDocumentUri(DatabaseId, CollectionId,id));
        }
        #endregion
    }
}