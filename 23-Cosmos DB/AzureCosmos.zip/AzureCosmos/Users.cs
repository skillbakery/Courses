﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AzureCosmos
{
    public class User
    {
        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }
        [JsonProperty(PropertyName = "FirstName")]

        public string FirstName { get; set; }

        [JsonProperty(PropertyName = "LastName")]

        public string LastName { get; set; }

        public string FullName { get; set; }
        [JsonProperty(PropertyName = "Balance")]
        public int Balance { get; set; }
      

    }
}