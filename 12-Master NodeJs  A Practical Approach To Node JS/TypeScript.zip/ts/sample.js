function greet() {
    console.log("Hello World");
}
function doubleUp(n) {
    return n * 2;
}
doubleUp(2);
