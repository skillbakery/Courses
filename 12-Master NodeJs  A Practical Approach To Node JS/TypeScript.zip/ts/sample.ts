function greet(){
 console.log("Hello World");
}
function doubleUp(n : number){
    return n*2;
}

doubleUp(2);