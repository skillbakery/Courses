// TypeScript
var Shape;
(function (Shape) {
    var pi = 3.14;
    var RectArea = (function () {
        function RectArea() {
        }
        return RectArea;
    })();
    Shape.RectArea = RectArea;
    function returnPi() {
        return pi;
    }
    Shape.returnPi = returnPi;
})(Shape || (Shape = {}));
var Shape;
(function (Shape) {
    var CircleArea = (function () {
        function CircleArea() {
        }
        return CircleArea;
    })();
    Shape.CircleArea = CircleArea;
})(Shape || (Shape = {}));
var Shape;
(function (Shape) {
    var RectArea = (function () {
        function RectArea() {
        }
        return RectArea;
    })();
    Shape.RectArea = RectArea;
    var CircleArea = (function () {
        function CircleArea() {
        }
        return CircleArea;
    })();
    Shape.CircleArea = CircleArea;
})(Shape || (Shape = {}));
