// TypeScript
class Course {
 name:Course.Subjects;
}

module Course {
 export class Subjects{
    name:string;
    constructor(name:string){
    this.name=name;
    }
 };
}

var obj=new Course();
var sub=new Course.Subjects("Master TypeScript");
obj.name=sub;
console.log(obj.name);