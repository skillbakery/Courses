var student;
student = {
    name: "John",
    rollNumber: 1,
    course: "Master TypeScript"
};
console.log(student);
console.log(student.course);
var data = (function () {
    var x = function () { };
    x.printContent = function (content) {
        return content;
    };
    return x;
});
var obj = data();
console.log(obj.printContent("Hello World"));
