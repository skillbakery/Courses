// TypeScript
var Size;
(function (Size) {
    Size[Size["S"] = 38] = "S";
    Size[Size["M"] = 39] = "M";
    Size[Size["L"] = 40] = "L";
    Size[Size["XL"] = 42] = "XL";
    Size[Size["XXL"] = 44] = "XXL";
})(Size || (Size = {}));
var Size;
(function (Size) {
    function getSize(size) {
        if (size == "small")
            return Size.S;
        if (size == "medium")
            return Size.M;
        if (size == "large")
            return Size.L;
        if (size == "extra large")
            return Size.XL;
        if (size == "extra extra large")
            return Size.XXL;
    }
    Size.getSize = getSize;
})(Size || (Size = {}));
console.log(Size.getSize("small"));
