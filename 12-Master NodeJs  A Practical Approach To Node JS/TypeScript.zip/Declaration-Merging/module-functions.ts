// TypeScript
function greetMessage(name:string):string {
    return greetMessage.prefix + name;
}

module greetMessage {
 export var prefix ="Hello ";
}

console.log(greetMessage("John"));