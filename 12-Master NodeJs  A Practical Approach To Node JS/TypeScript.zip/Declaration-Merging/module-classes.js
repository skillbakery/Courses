// TypeScript
var Course = (function () {
    function Course() {
    }
    return Course;
})();
var Course;
(function (Course) {
    var Subjects = (function () {
        function Subjects(name) {
            this.name = name;
        }
        return Subjects;
    })();
    Course.Subjects = Subjects;
    ;
})(Course || (Course = {}));
var obj = new Course();
var sub = new Course.Subjects("Master TypeScript");
obj.name = sub;
console.log(obj.name);
