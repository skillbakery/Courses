// TypeScript
function greetMessage(name) {
    return greetMessage.prefix + name;
}
var greetMessage;
(function (greetMessage) {
    greetMessage.prefix = "Hello ";
})(greetMessage || (greetMessage = {}));
console.log(greetMessage("John"));
