// TypeScript
interface Student {
 name:string;
 rollNumber:number;
}

interface Student {
course:string;
}

var student : Student;
student = {
name:"John",
rollNumber:1,
course:"Master TypeScript"
};

console.log(student);
console.log(student.course);

interface print {
     printContent(content:any) : any;
}

interface print {
     printContent(content:number) : number;
}

interface print {
     printContent(content:string) : string;
}

var data = ((): print=>{
  var x:any = function(){};
          x.printContent = function(content:string){
              return content;
          }
  return x;
});

var obj=data();
console.log(obj.printContent("Hello World"));