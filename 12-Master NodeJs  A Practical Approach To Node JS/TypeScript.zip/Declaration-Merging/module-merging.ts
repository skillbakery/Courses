// TypeScript
module Shape {
  var pi=3.14;
  export class RectArea {}
  export function returnPi {
   return pi;
  }
}

module Shape {
 export interface dimension { length:number,breadth:number }
 export class CircleArea{}
}

module Shape {
 export class RectArea {}
 export interface dimension { length:number,breadth:number }
 export class CircleArea{}
}