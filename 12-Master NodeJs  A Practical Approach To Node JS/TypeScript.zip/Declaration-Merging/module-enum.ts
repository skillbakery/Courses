// TypeScript
enum Size {
 S=38,
 M=39,
 L=40,
 XL=42,
 XXL=44
}

module Size {
 export function getSize(size:string){
    if(size=="small")
        return Size.S;
    if(size=="medium")
        return Size.M;
    if(size=="large")
        return Size.L;
    if(size=="extra large")
        return Size.XL;
    if(size=="extra extra large")
        return Size.XXL;
    }
}

console.log(Size.getSize("small"));