// TypeScript
/*
class Person{
 name:string;
 private unique_id:string;
 constructor(name:string){
  this.name=name;
  this.unique_id="XYS";

 }
 talk(to:string){
  console.log(this.name+" talking to "+ to+" "+this.unique_id);
 }
}
*/

class Person{
 
 constructor(public name:string,private unique_id:string){
  this.name=name;
  this.unique_id=unique_id;
 }
 talk(to:string){
  console.log(this.name+" talking to "+ to+" "+this.unique_id);
 }
}

var person = new Person("Mathews","XYS");
person.talk("Person");
console.log(person.name);
//console.log(person.unique_id);