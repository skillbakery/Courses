// TypeScript
class Course{
name:string;
publisher:string;
constructor(publisher:string,name:string){
  this.publisher=publisher;
  this.name=name;
 }
 logCourseInfo(){
   console.log("Course Created "+this.name);
 }
}

var course=new Course("SkillBakery","Master TypeScript");
course.logCourseInfo();