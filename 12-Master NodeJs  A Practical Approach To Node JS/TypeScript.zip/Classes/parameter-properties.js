// TypeScript
/*
class Person{
 name:string;
 private unique_id:string;
 constructor(name:string){
  this.name=name;
  this.unique_id="XYS";

 }
 talk(to:string){
  console.log(this.name+" talking to "+ to+" "+this.unique_id);
 }
}
*/
var Person = (function () {
    function Person(name, unique_id) {
        this.name = name;
        this.unique_id = unique_id;
        this.name = name;
        this.unique_id = unique_id;
    }
    Person.prototype.talk = function (to) {
        console.log(this.name + " talking to " + to + " " + this.unique_id);
    };
    return Person;
})();
var person = new Person("Mathews", "XYS");
person.talk("Person");
console.log(person.name);
//console.log(person.unique_id); 
