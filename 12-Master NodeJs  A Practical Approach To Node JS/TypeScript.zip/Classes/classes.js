// TypeScript
var Course = (function () {
    function Course(publisher, name) {
        this.publisher = publisher;
        this.name = name;
    }
    Course.prototype.logCourseInfo = function () {
        console.log("Course Created " + this.name);
    };
    return Course;
})();
var course = new Course("SkillBakery", "Master TypeScript");
course.logCourseInfo();
