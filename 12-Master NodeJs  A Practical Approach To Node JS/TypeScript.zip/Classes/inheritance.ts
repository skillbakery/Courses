// TypeScript
class Person{
 name:string;
 constructor(name:string){
  this.name=name;
 }
 talk(to:string){
  console.log(this.name+" talking to "+ to);
 }
}

class Student extends Person{
 constructor(name:string) {
    super(name);
 }
  rollNumber:number;
  course:string;
  talk(to:string){
    console.log("Student Talk Function");
    super.talk(to);
  }

}

var student = new Student("John");
student.rollNumber=1;
student.course="Master TypeScript";
student.talk("Teacher");