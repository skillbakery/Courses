// TypeScript
//creating get and set accessors
/*
class Person {
    name: string;
}

var person = new Person();
person.name = "John";
console.log(person.name);
*/
var Person = (function () {
    function Person() {
    }
    Object.defineProperty(Person.prototype, "name", {
        get: function () {
            return this._name;
        },
        set: function (name) {
            this._name = name;
        },
        enumerable: true,
        configurable: true
    });
    return Person;
})();
var person = new Person();
person.name = "John";
console.log(person.name);
