// TypeScript
var Circle = (function () {
    function Circle() {
    }
    Circle.prototype.area = function (radius) {
        return radius * radius * Circle.pie;
    };
    Circle.prototype.getPie = function () {
        return Circle.pie;
    };
    Circle.pie = 3.14;
    return Circle;
})();
var circle;
circle = new Circle();
console.log("Area of Circle " + circle.area(4));
console.log("Value of Pie " + circle.getPie());
