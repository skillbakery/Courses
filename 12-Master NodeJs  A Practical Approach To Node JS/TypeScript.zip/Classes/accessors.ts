// TypeScript
//creating get and set accessors
/*
class Person {
    name: string;
}

var person = new Person();
person.name = "John";
console.log(person.name);
*/
class Person {
    private _name: string;

    get name(): string {
        return this._name;
    }
	
    set name(name: string) {
            this._name = name;
    }
}

var person = new Person();
person.name = "John";
console.log(person.name);