var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
// TypeScript
var Person = (function () {
    function Person(name) {
        this.name = name;
        this.unique_id = "XYS";
    }
    Person.prototype.talk = function (to) {
        console.log(this.name + " talking to " + to + " " + this.unique_id);
    };
    return Person;
})();
var Student = (function (_super) {
    __extends(Student, _super);
    function Student(name) {
        _super.call(this, name);
    }
    Student.prototype.talk = function (to) {
        console.log("Student Talk Function");
        _super.prototype.talk.call(this, to);
    };
    return Student;
})(Person);
var person = new Person("Mathews");
//person.unique_id="XYSG12";
var student = new Student("John");
student.rollNumber = 1;
//student.unique_id="KYSXG10";
student.course = "Master TypeScript";
student.talk("Teacher");
