// TypeScript
class Person{
 name:string;
 private unique_id:string;
 constructor(name:string){
  this.name=name;
  this.unique_id="XYS";

 }
 talk(to:string){
  console.log(this.name+" talking to "+ to+" "+this.unique_id);
 }
}

class Student extends Person{
 constructor(name:string) {
    super(name);
 }
  rollNumber:number;
  course:string;
  talk(to:string){
    console.log("Student Talk Function");
    super.talk(to);
  }

}
var person = new Person("Mathews");
//person.unique_id="XYSG12";
var student = new Student("John");
student.rollNumber=1;
//student.unique_id="KYSXG10";
student.course="Master TypeScript";
student.talk("Teacher");