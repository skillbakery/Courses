// TypeScript
class Circle {
 static pie = 3.14;
 area(radius:number){
   return radius * radius * Circle.pie;
 }
 getPie(){
  return Circle.pie;
 }
}

var circle : Circle;
circle=new Circle();

console.log("Area of Circle "+circle.area(4));
console.log("Value of Pie "+circle.getPie());