// TypeScript
interface Registry<T> {
}
var r: Registry<number>;
var g: Registry<string>;

r = g;  // okay, g matches structure of r

interface NewRegistry<T> {
 register:T;
}

var s=NewRegistry<number>;
var b=NewRegistry<string>;

s=b;  // s and b are not compatible


var original = function<T>(o: T): T { 
    // ...
}

var copy = function<U>(c: U): U {
    // ...
}

original = copy;  // Okay because (o: any)=>any matches (c: any)=>any