// TypeScript
enum Status { Development, Production };
enum Publisher { Udemy, SkillBakery };

var status = Status.Production;
//status = Publisher.SkillBakery;  //error

console.log(status);