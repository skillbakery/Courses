var Subject = (function () {
    function Subject() {
    }
    return Subject;
})();
var subject;
subject = new Subject();
subject.name = "Master TypeScript";
var p;
var q = { name: "John", course: "Master TypeScript" };
p = q;
function wish(n) {
    console.log(n.name);
}
wish(q);
