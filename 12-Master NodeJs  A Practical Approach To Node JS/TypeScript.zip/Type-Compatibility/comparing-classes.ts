// TypeScript
class Course {
    name: string;
    price:number;
    constructor(name: string, price: number) { }
}

class Subject {
    name: string;
    constructor(name: number) { }
}

var course: Course;
var subject: Subject;

//course = subject;  //OK
subject = course;  //OK