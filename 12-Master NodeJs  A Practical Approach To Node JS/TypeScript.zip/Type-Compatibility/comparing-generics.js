var r;
var g;
r = g; // okay, g matches structure of r
