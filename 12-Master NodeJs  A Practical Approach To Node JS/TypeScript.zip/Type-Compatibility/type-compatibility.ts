// TypeScript
interface Course {
 name: string;}

class Subject {
 name:string;
}
var subject:Course;
subject = new Subject();
subject.name="Master TypeScript";

interface Person {
 name : string;
}

var p : Person;

var q = {name : "John", course : "Master TypeScript"};

p=q;

function wish(n:Person){
  console.log(n.name);
}

wish(q);