// TypeScript
var Course = (function () {
    function Course(name, price) {
    }
    return Course;
})();
var Subject = (function () {
    function Subject(name) {
    }
    return Subject;
})();
var course;
var subject;
//course = subject;  //OK
subject = course; //OK
