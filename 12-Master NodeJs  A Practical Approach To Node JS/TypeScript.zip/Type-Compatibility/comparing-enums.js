// TypeScript
var Status;
(function (Status) {
    Status[Status["Development"] = 0] = "Development";
    Status[Status["Production"] = 1] = "Production";
})(Status || (Status = {}));
;
var Publisher;
(function (Publisher) {
    Publisher[Publisher["Udemy"] = 0] = "Udemy";
    Publisher[Publisher["SkillBakery"] = 1] = "SkillBakery";
})(Publisher || (Publisher = {}));
;
var status = Status.Production;
//status = Publisher.SkillBakery;  //error
console.log(status);
