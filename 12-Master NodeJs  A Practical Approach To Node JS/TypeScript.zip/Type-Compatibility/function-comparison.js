// TypeScript
//comparing function on their argument type and size
var compute = function (param) {
    return param;
};
var sum = function (x, y) {
    return x + y;
};
sum = compute; //ok
//compute=sum; //error
// comparing functions on their return type
var sample = function () {
    return { name: "John" };
};
var def = function () {
    return { name: "John", course: "Master TypeScript" };
};
sample = def; //ok - as def has name
//def=sample; //error - as sample is missing course 
