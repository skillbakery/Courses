function HelloWorld() {
    console.log("Hello World");
}
function greet() {
    console.log("Hello World");
}
