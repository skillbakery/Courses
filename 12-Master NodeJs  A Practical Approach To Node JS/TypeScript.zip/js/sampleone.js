function greet() {
    console.log("Hello World");
}
function HelloWorld() {
    console.log("Hello World");
}
