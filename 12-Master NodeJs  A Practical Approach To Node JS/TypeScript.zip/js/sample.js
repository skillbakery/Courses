function greet() {
    console.log("Hello World");
}
