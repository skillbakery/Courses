// TypeScript
//anonymous functions
var greet=function (greet="Hello",name?:string) : string {
    return greet+" "+name;
}

console.log(greet("Hello"));