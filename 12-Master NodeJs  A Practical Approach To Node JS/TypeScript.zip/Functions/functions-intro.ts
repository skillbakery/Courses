// TypeScript
var z:number=10;
function sum(a:number,b:number) :number {
    return a+b+z;
}

console.log(sum(10,20));