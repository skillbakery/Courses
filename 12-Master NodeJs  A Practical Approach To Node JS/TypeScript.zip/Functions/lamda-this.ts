// TypeScript

var timetable = {
 courses : ["Master TypeScript","Master JavaScript"],
 taughtBy: "SkillBakery",
 getCourse : function (){
   return () => {
     var Publisher = this.taughtBy;
     var courseName = this.courses[Math.floor(Math.random()*2)];

     return {Publisher,courseName};
   }
 }
}

var course=timetable.getCourse();
var current_course = course();
console.log(current_course.courseName);
console.log(current_course.Publisher);