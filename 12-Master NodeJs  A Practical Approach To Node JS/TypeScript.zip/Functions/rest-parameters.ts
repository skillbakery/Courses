// TypeScript
function students(courseName: string, ...students: string[]) {
	return courseName + " enrolled students are - " + students.join(",");
}


var studentList= students("Master TypeScript","John","Mac","Eliza");
console.log(studentList);
