// TypeScript
function students(courseName) {
    var students = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        students[_i - 1] = arguments[_i];
    }
    return courseName + " enrolled students are - " + students.join(",");
}
var studentList = students("Master TypeScript", "John", "Mac", "Eliza");
console.log(studentList);
