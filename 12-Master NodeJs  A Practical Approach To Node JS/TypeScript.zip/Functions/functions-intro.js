// TypeScript
var z = 10;
function sum(a, b) {
    return a + b + z;
}
console.log(sum(10, 20));
