// TypeScript
//anonymous functions
var greet = function (greet, name) {
    if (greet === void 0) { greet = "Hello"; }
    return greet + " " + name;
};
console.log(greet("Hello"));
