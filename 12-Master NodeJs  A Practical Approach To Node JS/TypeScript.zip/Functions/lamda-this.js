// TypeScript
var timetable = {
    courses: ["Master TypeScript", "Master JavaScript"],
    taughtBy: "SkillBakery",
    getCourse: function () {
        var _this = this;
        return function () {
            var Publisher = _this.taughtBy;
            var courseName = _this.courses[Math.floor(Math.random() * 2)];
            return { Publisher: Publisher, courseName: courseName };
        };
    }
};
var course = timetable.getCourse();
var current_course = course();
console.log(current_course.courseName);
console.log(current_course.Publisher);
