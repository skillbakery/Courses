function add(x, y) {
    if (typeof (x) == "number" && typeof (y) == "number") {
        return x + y;
    }
    else if (typeof (x) == "string" && typeof (y) == "string") {
        return x + " " + y;
    }
}
/*
function add(x:number,y?:number) : number {
   if(y==undefined){
    return x;
   }
   else
    return x+y;
}
*/
/*
function add(x:string,y:string) : string {
  return x+y;
}

console.log(add(1,2));
console.log(add("Will","Smith"));
*/
//console.log(add(1,2));
//console.log(add(1));
console.log(add(1, 2));
console.log(add("Will", "Smith"));
