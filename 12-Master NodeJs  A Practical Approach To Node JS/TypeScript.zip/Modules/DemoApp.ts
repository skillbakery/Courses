// TypeScript
// DemoApp.ts file
import Base = require("Base");
 
class DemoApp extends Base {
 
    private _title:string = 'TypeScript Demo';
 
    constructor() {
        super();
    }
 
    public createObject():void {
 
    }
 
}
 
export = DemoApp;