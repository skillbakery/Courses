// TypeScript
module Circle {
 
 export function area(radius:number){
   return radius * radius * 3.14;
 }
 function diameter(radius:number){
  return radius * 2;
 }

 
}
//using aliases
import area = Circle.area;