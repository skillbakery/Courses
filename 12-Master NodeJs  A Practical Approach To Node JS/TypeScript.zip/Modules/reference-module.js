// TypeScript
/// <reference path="external-module.ts" />
console.log("Area of Circle " + area(4));
