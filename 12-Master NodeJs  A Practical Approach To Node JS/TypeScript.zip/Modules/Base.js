// TypeScript
// Base.ts file
var Base = (function () {
    function Base() {
    }
    Base.prototype.createObject = function () {
    };
    return Base;
})();
module.exports = Base;
