// TypeScript
/// <reference path="scripts/require.d.ts" />
/// <reference path="scripts/jquery.d.ts" />
///<reference path='config.ts'/>
///<reference path='DemoApp.ts'/>
 
/**
 * Main entry point for RequireJS
 */
require(
    [
        'DemoApp',
        'jquery'
    ],
    (DemoApp, $) => {
        'use strict';
 
        $(document).ready(function () {
            var app = new DemoApp();
            console.log(app);
        });
    }
);