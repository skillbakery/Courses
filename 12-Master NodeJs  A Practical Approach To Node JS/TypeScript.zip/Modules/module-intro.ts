// TypeScript
module Circle {
 
 export function area(radius:number){
   return radius * radius * 3.14;
 }
 function diameter(radius:number){
  return radius * 2;
 }

 
}


console.log("Area of Circle "+Circle.area(4));
//console.log("Area of Circle "+Circle.diameter(4));