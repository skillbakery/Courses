// TypeScript
require.config({
    paths: {
        //main libraries
        jquery: '../vendor/jquery/jquery-1.11.3.min'
    },
    shim: {
        jquery: {
            exports: '$'
        }
    }
});
