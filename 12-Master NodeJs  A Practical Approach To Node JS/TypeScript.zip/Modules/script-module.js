var Circle;
(function (Circle) {
    function area(radius) {
        return radius * radius * 3.14;
    }
    Circle.area = area;
    function diameter(radius) {
        return radius * 2;
    }
})(Circle || (Circle = {}));

console.log("Area of Circle " + Circle.area(4));
