// TypeScript
// Base.ts file
class Base {
 
    constructor() {
    }
 
    public createObject():void {
 
    }
}
 
export = Base;