// TypeScript
var age: number=10;
var name: string="skillbakery.com";
var isValid:boolean = true;
var courses:string[] =["JavaScript","AngularJS"];
var otherCourses:Array<string>=["ES6","EmberJS"];

//TypeScript - Types introduced By TypeScript
enum feedback {Poor=1,Average=3,Good=2,Best=4};
var opinion:feedback = feedback.Best;
var take:string = feedback[2];

console.log(take);

var unknown:any = "skillbakery.com";
function errorMsg():void {
  console.log("Error Occurred");
}

errorMsg();