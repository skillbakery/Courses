// TypeScript
var age = 10;
var name = "skillbakery.com";
var isValid = true;
var courses = ["JavaScript", "AngularJS"];
var otherCourses = ["ES6", "EmberJS"];
//TypeScript - Types introduced By TypeScript
var feedback;
(function (feedback) {
    feedback[feedback["Poor"] = 1] = "Poor";
    feedback[feedback["Average"] = 3] = "Average";
    feedback[feedback["Good"] = 2] = "Good";
    feedback[feedback["Best"] = 4] = "Best";
})(feedback || (feedback = {}));
;
var opinion = feedback.Best;
var take = feedback[2];
console.log(take);
var unknown = "skillbakery.com";
function errorMsg() {
    console.log("Error Occurred");
}
errorMsg();
