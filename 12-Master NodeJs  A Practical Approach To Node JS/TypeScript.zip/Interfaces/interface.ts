// TypeScript
var course={
    name:"Master TypeScript",
    publisher:"SkillBakery",
    price:49,
    isPublished:false
};

interface CourseI {
    name:string;
    publisher:string;
    price:number;
    isPublished:boolean;

    //optional properties
    author?:string;
}

var courseObj:CourseI = { name:"Master Typescript",
    publisher:"SkillBakery",
    price:49,
    isPublished:false,
    author:"SkillBakery.com"
};

console.log(courseObj.name);
//console.log(courseObj.Author);

function coursePrice(courseObj : {price:number}){
    console.log(courseObj.price);
}

coursePrice(courseObj);