// TypeScript

interface CourseI{
 courseName:string;
 coursePrice:number;
 setPrice(price:number);
}

class Course implements CourseI {
  
  courseName:string;
  coursePrice:number;

  setPrice(price:number){
    this.coursePrice=price;
  }
  
}

var courseObj=new Course();

courseObj.courseName="Master TypeScript";
courseObj.setPrice(49);

console.log(courseObj.courseName+"-"+courseObj.coursePrice);


interface SubjectI{
    new(subjectName:string)
}

class Subject {
    subjectName:string;
    constructor(subjectName:string){
      this.subjectName=subjectName;
    }
}

var subClass:SubjectI=Subject;

var obj=new subClass("Master TypeScript");
console.log(obj);
console.log(obj.subjectName);