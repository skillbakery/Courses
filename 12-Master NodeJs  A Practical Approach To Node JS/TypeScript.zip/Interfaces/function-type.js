var summary;
summary = function (id, publisher) {
    if (id == 1)
        return publisher + " Price 59 USD";
    else
        return publisher + " Price N/A";
};
console.log(summary(1, "SkillBakery"));
