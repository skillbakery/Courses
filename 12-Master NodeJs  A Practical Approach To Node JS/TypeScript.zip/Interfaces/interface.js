// TypeScript
var course = {
    name: "Master TypeScript",
    publisher: "SkillBakery",
    price: 49,
    isPublished: false
};
var courseObj = { name: "Master Typescript",
    publisher: "SkillBakery",
    price: 49,
    isPublished: false,
    author: "SkillBakery.com"
};
console.log(courseObj.name);
//console.log(courseObj.Author);
function coursePrice(courseObj) {
    console.log(courseObj.price);
}
coursePrice(courseObj);
