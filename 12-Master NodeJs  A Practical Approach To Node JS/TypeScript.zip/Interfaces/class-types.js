// TypeScript
var Course = (function () {
    function Course() {
    }
    Course.prototype.setPrice = function (price) {
        this.coursePrice = price;
    };
    return Course;
})();
var courseObj = new Course();
courseObj.courseName = "Master TypeScript";
courseObj.setPrice(49);
console.log(courseObj.courseName + "-" + courseObj.coursePrice);
var Subject = (function () {
    function Subject(subjectName) {
        this.subjectName = subjectName;
    }
    return Subject;
})();
var subClass = Subject;
var obj = new subClass("Master TypeScript");
console.log(obj);
console.log(obj.subjectName);
