var studentObj = {};
studentObj.name = "John";
studentObj.rollNumber = 1;
console.log(studentObj.name);
