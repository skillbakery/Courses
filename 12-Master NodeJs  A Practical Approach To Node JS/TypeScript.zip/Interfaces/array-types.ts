// TypeScript
interface courseArray {
     [index:number]:string;
}

var courses:courseArray=["Master TypeScript","Master AngularJS","Master ReactJS"];
console.log(courses[0]);

interface priceArray {
     [index:string]:number;
}

var coursePrice : priceArray ={};
coursePrice["Master TypeScript"]=49;
coursePrice["Master AngularJS"]=59;

console.log(courses);
console.log(coursePrice);
console.log(coursePrice["Master AngularJS"]);