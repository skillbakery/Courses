function studentObj() {
    var student = function (name) {
        if (name == "John")
            return 1;
        else
            return -1;
    };
    student.name = "John";
    student.getAttendance = function (rollNumber) {
        return 100;
    };
    return student;
}
;
var getStudent = studentObj();
console.log(getStudent("John"));
console.log(getStudent.getAttendance(1));
