var courses = ["Master TypeScript", "Master AngularJS", "Master ReactJS"];
console.log(courses[0]);
var coursePrice = {};
coursePrice["Master TypeScript"] = 49;
coursePrice["Master AngularJS"] = 59;
console.log(courses);
console.log(coursePrice);
console.log(coursePrice["Master AngularJS"]);
