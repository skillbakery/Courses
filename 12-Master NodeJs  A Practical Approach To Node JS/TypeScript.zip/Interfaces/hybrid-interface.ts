// TypeScript
interface StudentI {
    name:string;
    getAttendance(rollNumber:number): number;
    (name: string): number;
}

function studentObj():StudentI { 
  
    var student = <StudentI>function(name :string ) {
                              if(name=="John")
                                return 1;
                              else
                                return -1;
                        };
    student.name="John";
    student.getAttendance=function(rollNumber:number){
        return 100;
    };
    return student;
};

var getStudent=studentObj();
console.log(getStudent("John"));
console.log(getStudent.getAttendance(1));