/// <reference path="SkillBakery.Application.Product.ts" />
/// <reference path="SkillBakery.Util.MathLib.ts" />
/// <reference path="SkillBakery.Util.Web.ts" />
/// <reference path="TS\jquery.d.ts" />

/*
    SkillBakery 'Cart' Demo

    Classes for shopping cart

*/


module SkillBakery.Application.Cart {

    //
    // Class to hold a single Cart item
    //
    export class CartItem {
        Course: Course;
        Quantity: number;

        // constructor requires a course and quantity
        constructor (
            course: Course,
            quantity: number) {
            // ensure qty is integer
            this.Quantity = Math.round(quantity);

            // validate quantity field
            if (quantity <= 0) throw ("Invalid quantity");
            /// check product is valid
            if (!course.CanBePurchased()) throw ("Course " + course.Name + " cannot be sold");

            this.Course = course;
        }

        // calc QTY x PRICE
        public SubTotal() {
            return (this.Course.Price * this.Quantity);
        }

        // return subtotal as a formatted html currency value
        public SubTotalHtml() {
            return SkillBakery.Util.MathLib.ToCurrency(this.SubTotal());
        }

        public ChangeQuantityBy(units: number) {
            var qty = Math.round(units);
            if ((qty + this.Quantity) < 0)
                throw ("Invalid change: there are only " + this.Quantity + " items");
            if ((qty + this.Quantity) == 0)
                throw ("Invalid change: would result in zero units. Remove from the cart instead");

            this.Quantity += qty;
        }



        // generate a cart Html table row
        public GetHtmlRow() {
             
            return "<tr>" +
                Util.Web.GetTD(Util.Web.HtmlEncode(this.Course.Name),false,false) +
                Util.Web.GetTD(this.Course.PriceHtml(), true,false) +
                Util.Web.GetTD(this.Quantity.toString(),false,true) +
                Util.Web.GetTD(this.SubTotalHtml(), true,false) + "</tr>";
        }



    }

}