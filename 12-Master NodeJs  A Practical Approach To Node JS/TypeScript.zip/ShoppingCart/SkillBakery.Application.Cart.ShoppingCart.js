/// <reference path="SkillBakery.Application.Cart.CartItem.ts" />
/// <reference path="SkillBakery.Application.Product.ts" />
/// <reference path="SkillBakery.Util.MathLib.ts" />
/// <reference path="SkillBakery.Util.Web.ts" />
/// <reference path="TS\jquery.d.ts" />
/*
    SkillBakery 'Cart' Demo

    Classes for shopping cart

*/
var SkillBakery;
(function (SkillBakery) {
    var Application;
    (function (Application) {
        var Cart;
        (function (Cart) {
            var ShoppingCart = (function () {
                function ShoppingCart() {
                    this.items = new Array();
                }
                // add a new course + quantity
                ShoppingCart.prototype.Add = function (course, quantity) {
                    // clean up Quantity
                    var intQty = Math.round(quantity);
                    // is this permitted?
                    if (!course.CanBePurchased()) {
                        alert("Course " + course.Name + " is not permitted");
                        throw ("Attempted purchase of invalid: " + course.Name);
                    }
                    // check cart for existing
                    var tmpItem = this.GetItemFromCart(course);
                    // check for not found
                    if (tmpItem == null) {
                        // add a new item
                        tmpItem = new Cart.CartItem(course, intQty);
                        this.items[tmpItem.Course.Id] = tmpItem;
                    }
                    else {
                        // increment the existing entry
                        tmpItem.ChangeQuantityBy(intQty);
                    }
                };
                // Search cart to see if there is an existing item
                // for this product
                ShoppingCart.prototype.GetItemFromCart = function (course) {
                    if (this.IsCourseInCart(course.Id)) {
                        // use product code as Key
                        return this.items[course.Id];
                    }
                    else {
                        return null;
                    }
                };
                ShoppingCart.prototype.IsCourseInCart = function (code) {
                    var match = this.items.filter(function (c, i, a) {
                        return (c.Course.Id == code);
                    });
                    return (match.length > 0);
                };
                ShoppingCart.prototype.IsEmpty = function () { return (this.items.length == 0); };
                ShoppingCart.prototype.GetCartTable = function () {
                    // is it empty?
                    if (this.IsEmpty())
                        return "<b>Your shopping cart is currently empty</b>";
                    // define header
                    var cartHtml = " <table><tbody><tr><th style='min-width: 150px;'>Course</th><th>Price</th><th class='text-center'>Quantity</th><th class='text-right'>Subtotal</th></tr>";
                    // add cart items
                    this.items.forEach(function (c, i, a) {
                        cartHtml = cartHtml + c.GetHtmlRow();
                    });
                    // add footer with total
                    cartHtml = cartHtml + "<tr class='theme-color'><td class='text-bold' colspan='2'>Total Price:</td>" +
                        "<td style='text-align: right!important;' class='total-text'>" + SkillBakery.Util.Web.GetTD(SkillBakery.Util.MathLib.ToCurrency(this.GetCartTotal()), true, false) + "</td>" +
                        "</tr></table>";
                    cartHtml = cartHtml + this.GetTotalItemsText();
                    return cartHtml;
                };
                ShoppingCart.prototype.GetTotalItemsText = function () {
                    var total = this.GetTotalItems();
                    if (total == 1)
                        return "There is 1 item in your cart.";
                    else
                        return "There are " + total.toString() +
                            " items in your shopping cart.";
                };
                ShoppingCart.prototype.GetCartTotal = function () {
                    var total = 0;
                    this.items.forEach(function (c) { total = total + c.SubTotal(); });
                    return total;
                };
                ShoppingCart.prototype.GetTotalItems = function () {
                    var total = 0;
                    this.items.forEach(function (c) { total = total + c.Quantity; });
                    return total;
                };
                return ShoppingCart;
            })();
            Cart.ShoppingCart = ShoppingCart;
        })(Cart = Application.Cart || (Application.Cart = {}));
    })(Application = SkillBakery.Application || (SkillBakery.Application = {}));
})(SkillBakery || (SkillBakery = {}));
