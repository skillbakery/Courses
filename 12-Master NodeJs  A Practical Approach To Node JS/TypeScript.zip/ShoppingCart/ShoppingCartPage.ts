/// <reference path="TS\jquery.d.ts" />
/// <reference path="SkillBakery.Application.Product.ts" />
/// <reference path="SkillBakery.Application.Cart.CartItem.ts" />
/// <reference path="SkillBakery.Application.Cart.ShoppingCart.ts" />


module ShoppingCartPage {

    var repository: SkillBakery.Application.CourseRepository;

    var myCart: SkillBakery.Application.Cart.ShoppingCart;

    // initalise the products and cart
    $(document).ready(
        function () {
            // create repository
            repository = new SkillBakery.Application.CourseRepository();

            // create the cart
            myCart = new SkillBakery.Application.Cart.ShoppingCart();

            // show products
            UpdateProducts();
            UpdateCart();
            ErrMessage("");
        });

    // called by input button on the product table
    export function AddCourseToCart(productCode: number, qty: number) {
        // clear current error
        ErrMessage("");

        // get product
        var product = repository.GetCourseByCode(productCode);
        if (product == null) {
            ErrMessage("Unable to find product " + productCode.toString());
        }
        else {
            // add this product to cart
            myCart.Add(product, qty);
            UpdateCart();
            ErrMessage("Added " + product.NameHtml());
        }
    }

    export function ErrMessage(msg: string) {
        $("#cartError").text(msg);
    }

    function UpdateProducts() {
        $("#courses").html(repository.GetCourseTable());
    }

    export function UpdateCart() {
        $("#cart").html(myCart.GetCartTable());
    }

}
