/// <reference path="SkillBakery.Application.Product.ts" />
/// <reference path="SkillBakery.Util.MathLib.ts" />
/// <reference path="SkillBakery.Util.Web.ts" />
/// <reference path="TS\jquery.d.ts" />
/*
    SkillBakery 'Cart' Demo

    Classes for shopping cart

*/
var SkillBakery;
(function (SkillBakery) {
    var Application;
    (function (Application) {
        var Cart;
        (function (Cart) {
            //
            // Class to hold a single Cart item
            //
            var CartItem = (function () {
                // constructor requires a course and quantity
                function CartItem(course, quantity) {
                    // ensure qty is integer
                    this.Quantity = Math.round(quantity);
                    // validate quantity field
                    if (quantity <= 0)
                        throw ("Invalid quantity");
                    /// check product is valid
                    if (!course.CanBePurchased())
                        throw ("Course " + course.Name + " cannot be sold");
                    this.Course = course;
                }
                // calc QTY x PRICE
                CartItem.prototype.SubTotal = function () {
                    return (this.Course.Price * this.Quantity);
                };
                // return subtotal as a formatted html currency value
                CartItem.prototype.SubTotalHtml = function () {
                    return SkillBakery.Util.MathLib.ToCurrency(this.SubTotal());
                };
                CartItem.prototype.ChangeQuantityBy = function (units) {
                    var qty = Math.round(units);
                    if ((qty + this.Quantity) < 0)
                        throw ("Invalid change: there are only " + this.Quantity + " items");
                    if ((qty + this.Quantity) == 0)
                        throw ("Invalid change: would result in zero units. Remove from the cart instead");
                    this.Quantity += qty;
                };
                // generate a cart Html table row
                CartItem.prototype.GetHtmlRow = function () {
                    return "<tr>" +
                        SkillBakery.Util.Web.GetTD(SkillBakery.Util.Web.HtmlEncode(this.Course.Name), false, false) +
                        SkillBakery.Util.Web.GetTD(this.Course.PriceHtml(), true, false) +
                        SkillBakery.Util.Web.GetTD(this.Quantity.toString(), false, true) +
                        SkillBakery.Util.Web.GetTD(this.SubTotalHtml(), true, false) + "</tr>";
                };
                return CartItem;
            })();
            Cart.CartItem = CartItem;
        })(Cart = Application.Cart || (Application.Cart = {}));
    })(Application = SkillBakery.Application || (SkillBakery.Application = {}));
})(SkillBakery || (SkillBakery = {}));
