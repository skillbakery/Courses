/// <reference path="SkillBakery.Application.Cart.CartItem.ts" />
/// <reference path="SkillBakery.Application.Product.ts" />
/// <reference path="SkillBakery.Util.MathLib.ts" />
/// <reference path="SkillBakery.Util.Web.ts" />
/// <reference path="TS\jquery.d.ts" />

/*
    SkillBakery 'Cart' Demo

    Classes for shopping cart

*/


module SkillBakery.Application.Cart {

    export class ShoppingCart {

        // internal list of cart items
        items: CartItem[];

        constructor () {
            this.items = new Array<CartItem>();
        }

        // add a new course + quantity
        public Add(course: Course, quantity: number) {
            // clean up Quantity
            var intQty = Math.round(quantity);

            // is this permitted?
            if (!course.CanBePurchased()) {
                alert("Course " + course.Name + " is not permitted");
                throw ("Attempted purchase of invalid: " + course.Name);
            }

            // check cart for existing
            var tmpItem = this.GetItemFromCart(course);

            // check for not found
            if (tmpItem == null) {
                // add a new item
                tmpItem = new CartItem(course, intQty);
                this.items[tmpItem.Course.Id] = tmpItem;
            }
            else {
                // increment the existing entry
                tmpItem.ChangeQuantityBy(intQty);
            }

        }


        // Search cart to see if there is an existing item
        // for this product
        private GetItemFromCart(course: Course) {
            if (this.IsCourseInCart(course.Id)) {
                // use product code as Key
                return this.items[course.Id];
            }
            else {
                return null;
            }
        }

        private IsCourseInCart(code: number) {
            var match = this.items.filter ((c: CartItem, i: number, a: CartItem[]) => {
                return (c.Course.Id == code);
            });
            return (match.length > 0);
        }

        public IsEmpty() { return (this.items.length == 0); }

        public GetCartTable() {
            // is it empty?
            if (this.IsEmpty())
                return "<b>Your shopping cart is currently empty</b>";

            // define header
            var cartHtml = " <table><tbody><tr><th style='min-width: 150px;'>Course</th><th>Price</th><th class='text-center'>Quantity</th><th class='text-right'>Subtotal</th></tr>";
            // add cart items
            this.items.forEach  (
                (c: CartItem, i: number, a: CartItem[]) => {
                    cartHtml = cartHtml + c.GetHtmlRow();
                });
            // add footer with total
                              
            cartHtml = cartHtml + "<tr class='theme-color'><td class='text-bold' colspan='2'>Total Price:</td>" +
                                    "<td style='text-align: right!important;' class='total-text'>"+Util.Web.GetTD(Util.MathLib.ToCurrency(this.GetCartTotal()), true,false) +"</td>"+
                                 "</tr></table>";

            cartHtml = cartHtml + this.GetTotalItemsText();
            return cartHtml;
        }

        private GetTotalItemsText() {
            var total = this.GetTotalItems();
            if (total==1)
                return "There is 1 item in your cart.";
            else
                return "There are " + total.toString() + 
                    " items in your shopping cart.";
        }

        public GetCartTotal() {
            var total = 0;
            this.items.forEach  (
                (c: CartItem) => { total = total + c.SubTotal(); });
            return total;
        }

        public GetTotalItems() {
            var total = 0;
            this.items.forEach  (
                (c: CartItem) => { total = total + c.Quantity; });
            return total;

        }
    }

}
