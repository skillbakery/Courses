/// <reference path="SkillBakery.Util.MathLib.ts" />
/// <reference path="SkillBakery.Util.Web.ts" />

/*
    Product class
*/

module SkillBakery.Application {

    export class Course {
        Id:number;
        Name: string;
        Price: number;
        IsActive: boolean;
        Description: string;
        Image:string;
        constructor (
            id:number,
            name: string,
            price: number,
            isActive: boolean = true,
            description:string,
            image:string) {

            if (name == "") throw ("Course Name must be not be blank");
            if (price <= 0) throw ("Course Price must be higher than zero");
            this.Id=id;
            this.Name = name.trim();
            this.Price = SkillBakery.Util.MathLib.Round(price, 2);
            this.IsActive = isActive;
            this.Description=description;
            this.Image=image;
        }

        public CanBePurchased() {

            return (this.IsActive);
        }

        // price as currency html
        PriceHtml() { return SkillBakery.Util.MathLib.ToCurrency(this.Price); }
        
        //description encoded as html
        DescHtml() {return SkillBakery.Util.Web.HtmlEncode(this.Description); }
        
        // name encoded as html
        NameHtml() { return SkillBakery.Util.Web.HtmlEncode(this.Name); }

    }

    /// <summary>Course repository</summary>
    export class CourseRepository {
        // list of products
        CourseList: Course[];

        constructor () {
            // initalize list
            this.CourseList = new Array<Course>();
            
            // create some products - in a real application
            // we would probably get the data via JSON AJAX call
            this.Add(new Course(1,"JavaScript ES6",49, true, "Learn the all new cool features of ES6 - EcmaScript version 6 and see how it enhances JavaScript furthermore.", "img/es6.png"));
            this.Add(new Course(2,"Master KnockoutJS",69, true, "Learn KnockoutJS - JavaScript implementation of the MVVM-Model View View Model with easy to understand examples.", "img/knockout.jpg"));
            this.Add(new Course(3,"Amazon Web Services",49, true, "This course helps you in creating a Linux instance and installing PHP,MySQL and more stuff on Amazon EC2 instance.", "img/amazon.jpg"));
            this.Add(new Course(4,"Master EmberJS",149, true, "Learn to demystify the EmberJS JavaScript framework by learning all the core concepts of it and building a real web app", "img/ember.jpg"));
        }

        public Add(course: Course) {
            // check for duplicate course id
            if (this.CourseCodeExists(course.Id)) {
                alert("Cannot add " + course.Id + ", already added");
                //throw ("Duplicate course " + course.Id);
            }
            this.CourseList[course.Id] = course;
        }

        // get course using course id
        public GetCourseByCode(code: number) {
            if (this.CourseCodeExists(code)) {
                return this.CourseList[code];
            }
            else
                return null;
        }

        // see if course exists
        public CourseCodeExists(courseCode: number) {
            var match = this.CourseList.filter ((c: Course, i: number) => {
                return (c.Id == courseCode);
            });
            var len = match.length;
            return (len > 0);
            //return (match == null);
        }

        public GetCourseTable() {
        var result="";
            this.CourseList.forEach  (
                (c: Course, index: number, array: Course[]) => {
                    result=result.concat(this.GetInitialDiv());    
                    result=result.concat(this.GetCourseImage(c));  
                    result=result.concat(this.GetCourseInfo(c));  
                    result = result.concat("</div>");
                });
                console.log(result);
          return result;
        }

        private GetInitialDiv(){
            return '<div class="row line">';
        }
        private GetCourseImage(c:Course){
            return  '<div class="col-sm-4">'+
                        '<img src="'+c.Image.toString()+'" class="img-responsive">'+
                    '</div>';
        }
        private GetCourseInfo(c:Course){

           return '<div class="col-sm-8" id="course-details">'+
                    '<div class="form-group">'+
                        '<h3>'+c.NameHtml()+'</h3>'+
                         '<p>'+c.DescHtml()+'</p>'+
                    '</div>'+
                    '<div class="form-group">'+
                        '<div class="row">'+
                            '<div class="col-sm-6">'+
                                '<h4><span>Price</span>' + c.PriceHtml() + '</h4>'+
                            '</div>'+
                            '<div class="col-sm-6">'+
                                this.GetAddControl(c)+
                            '</div>'+
                        '</div>'+
                    '</div>'+
                '</div>';
        }

        private GetAddControl(c: Course) {
            // input control ID, if we can sell this!
            if (c.CanBePurchased()) {
                var codeText = c.Id.toString();
                return '<a href="javascript:void(0);" class="add-to-cart pull-right" onclick="ShoppingCartPage.AddCourseToCart(' + codeText + ', 1);"><i class="fa fa-shopping-cart"></i> add to cart</a>';
            }
            // not for sale
            return "<i>Sorry,This course is not on sale</i>";
        }
    }
}
