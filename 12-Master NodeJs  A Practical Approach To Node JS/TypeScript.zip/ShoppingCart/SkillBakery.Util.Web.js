/// <reference path="TS\jquery.d.ts" />
/*
    Web utility
*/
var SkillBakery;
(function (SkillBakery) {
    var Util;
    (function (Util) {
        var Web;
        (function (Web) {
            /// html encode a string using jQuery
            function HtmlEncode(value) {
                // not best practice but it will do for a demo
                return $('<div/>').text(value).html();
            }
            Web.HtmlEncode = HtmlEncode;
            /// html decode a string using jQuery
            function HtmlDecode(value) {
                // not best practice but it will do for a demo
                return $('<div/>').html(value).text();
            }
            Web.HtmlDecode = HtmlDecode;
            function GetTD(text, alignRight, alignCenter) {
                if (alignCenter)
                    return "<td  class='text-center'>" + text + "</td>";
                else
                    return "<td " + (alignRight ? " style='text-align:right;'>" : ">") + text + "</td>";
            }
            Web.GetTD = GetTD;
        })(Web = Util.Web || (Util.Web = {}));
    })(Util = SkillBakery.Util || (SkillBakery.Util = {}));
})(SkillBakery || (SkillBakery = {}));
