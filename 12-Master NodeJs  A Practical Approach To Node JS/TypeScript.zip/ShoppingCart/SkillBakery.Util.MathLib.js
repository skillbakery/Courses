/*
    MathLib library

*/
var SkillBakery;
(function (SkillBakery) {
    var Util;
    (function (Util) {
        var MathLib;
        (function (MathLib) {
            ///<summary>Round a number to N places</summary>
            function Round(value, places) {
                if (places === void 0) { places = 2; }
                var multiplier = Math.pow(10, Math.round(places));
                return Math.round(value * multiplier) / multiplier;
            }
            MathLib.Round = Round;
            // Write a number as 
            function ToCurrency(value) {
                return "$" + value.toFixed(2);
            }
            MathLib.ToCurrency = ToCurrency;
        })(MathLib = Util.MathLib || (Util.MathLib = {}));
    })(Util = SkillBakery.Util || (SkillBakery.Util = {}));
})(SkillBakery || (SkillBakery = {}));
