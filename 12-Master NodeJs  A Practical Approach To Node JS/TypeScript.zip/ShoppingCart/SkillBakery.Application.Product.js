/// <reference path="SkillBakery.Util.MathLib.ts" />
/// <reference path="SkillBakery.Util.Web.ts" />
/*
    Product class
*/
var SkillBakery;
(function (SkillBakery) {
    var Application;
    (function (Application) {
        var Course = (function () {
            function Course(id, name, price, isActive, description, image) {
                if (isActive === void 0) { isActive = true; }
                if (name == "")
                    throw ("Course Name must be not be blank");
                if (price <= 0)
                    throw ("Course Price must be higher than zero");
                this.Id = id;
                this.Name = name.trim();
                this.Price = SkillBakery.Util.MathLib.Round(price, 2);
                this.IsActive = isActive;
                this.Description = description;
                this.Image = image;
            }
            Course.prototype.CanBePurchased = function () {
                return (this.IsActive);
            };
            // price as currency html
            Course.prototype.PriceHtml = function () { return SkillBakery.Util.MathLib.ToCurrency(this.Price); };
            //description encoded as html
            Course.prototype.DescHtml = function () { return SkillBakery.Util.Web.HtmlEncode(this.Description); };
            // name encoded as html
            Course.prototype.NameHtml = function () { return SkillBakery.Util.Web.HtmlEncode(this.Name); };
            return Course;
        })();
        Application.Course = Course;
        /// <summary>Course repository</summary>
        var CourseRepository = (function () {
            function CourseRepository() {
                // initalize list
                this.CourseList = new Array();
                // create some products - in a real application
                // we would probably get the data via JSON AJAX call
                this.Add(new Course(1, "JavaScript ES6", 49, true, "Learn the all new cool features of ES6 - EcmaScript version 6 and see how it enhances JavaScript furthermore.", "img/es6.png"));
                this.Add(new Course(2, "Master KnockoutJS", 69, true, "Learn KnockoutJS - JavaScript implementation of the MVVM-Model View View Model with easy to understand examples.", "img/knockout.jpg"));
                this.Add(new Course(3, "Amazon Web Services", 49, true, "This course helps you in creating a Linux instance and installing PHP,MySQL and more stuff on Amazon EC2 instance.", "img/amazon.jpg"));
                this.Add(new Course(4, "Master EmberJS", 149, true, "Learn to demystify the EmberJS JavaScript framework by learning all the core concepts of it and building a real web app", "img/ember.jpg"));
            }
            CourseRepository.prototype.Add = function (course) {
                // check for duplicate course id
                if (this.CourseCodeExists(course.Id)) {
                    alert("Cannot add " + course.Id + ", already added");
                }
                this.CourseList[course.Id] = course;
            };
            // get course using course id
            CourseRepository.prototype.GetCourseByCode = function (code) {
                if (this.CourseCodeExists(code)) {
                    return this.CourseList[code];
                }
                else
                    return null;
            };
            // see if course exists
            CourseRepository.prototype.CourseCodeExists = function (courseCode) {
                var match = this.CourseList.filter(function (c, i) {
                    return (c.Id == courseCode);
                });
                var len = match.length;
                return (len > 0);
                //return (match == null);
            };
            CourseRepository.prototype.GetCourseTable = function () {
                var _this = this;
                var result = "";
                this.CourseList.forEach(function (c, index, array) {
                    result = result.concat(_this.GetInitialDiv());
                    result = result.concat(_this.GetCourseImage(c));
                    result = result.concat(_this.GetCourseInfo(c));
                    result = result.concat("</div>");
                });
                console.log(result);
                return result;
            };
            CourseRepository.prototype.GetInitialDiv = function () {
                return '<div class="row line">';
            };
            CourseRepository.prototype.GetCourseImage = function (c) {
                return '<div class="col-sm-4">' +
                    '<img src="' + c.Image.toString() + '" class="img-responsive">' +
                    '</div>';
            };
            CourseRepository.prototype.GetCourseInfo = function (c) {
                return '<div class="col-sm-8" id="course-details">' +
                    '<div class="form-group">' +
                    '<h3>' + c.NameHtml() + '</h3>' +
                    '<p>' + c.DescHtml() + '</p>' +
                    '</div>' +
                    '<div class="form-group">' +
                    '<div class="row">' +
                    '<div class="col-sm-6">' +
                    '<h4><span>Price</span>' + c.PriceHtml() + '</h4>' +
                    '</div>' +
                    '<div class="col-sm-6">' +
                    this.GetAddControl(c) +
                    '</div>' +
                    '</div>' +
                    '</div>' +
                    '</div>';
            };
            CourseRepository.prototype.GetAddControl = function (c) {
                // input control ID, if we can sell this!
                if (c.CanBePurchased()) {
                    var codeText = c.Id.toString();
                    return '<a href="javascript:void(0);" class="add-to-cart pull-right" onclick="ShoppingCartPage.AddCourseToCart(' + codeText + ', 1);"><i class="fa fa-shopping-cart"></i> add to cart</a>';
                }
                // not for sale
                return "<i>Sorry,This course is not on sale</i>";
            };
            return CourseRepository;
        })();
        Application.CourseRepository = CourseRepository;
    })(Application = SkillBakery.Application || (SkillBakery.Application = {}));
})(SkillBakery || (SkillBakery = {}));
