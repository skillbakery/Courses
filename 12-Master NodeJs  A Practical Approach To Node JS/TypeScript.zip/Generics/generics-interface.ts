// TypeScript
/*
interface genericInterface {
    <T>(arg: T): T;
}
*/
interface genericInterfaceII<T> {
    (arg: T): T;
}


function gImpl<T>(arg: T): T {
    return arg;
}

//var result: genericInterface = gImpl;
var result: genericInterfaceII<number> = gImpl;
console.log(result(10));

//var result=  gImpl;
//console.log(result(10));