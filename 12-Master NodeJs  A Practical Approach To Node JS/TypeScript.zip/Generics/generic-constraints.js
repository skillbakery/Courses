// TypeScript
//For implementing generic constraints we will be creating an interface 
/*
function getDetails<T>(arg:T):T {
    
}
*/
function getDetails(arg) {
    console.log(arg.length);
    return arg;
}
var video = {
    length: 190,
    name: "Introduction-to-typescript.mp4"
};
var course = {
    name: "Master TypeScript",
    publisher: "SkillBakery"
};
console.log(getDetails(video));
//console.log(getDetails(course)); 
