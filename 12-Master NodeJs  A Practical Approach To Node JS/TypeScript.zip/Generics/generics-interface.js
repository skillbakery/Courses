function gImpl(arg) {
    return arg;
}
//var result: genericInterface = gImpl;
var result = gImpl;
console.log(result(10));
//var result=  gImpl;
//console.log(result(10)); 
