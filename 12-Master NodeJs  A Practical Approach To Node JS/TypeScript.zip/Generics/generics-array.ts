// TypeScript
function printArray<t>(arg:t[]) {
  for(var i=0;i<arg.length;i++){
   console.log(arg[i]);
  }
}

var courses=["Master TypeScript","Master JavaScript & jQuery"];
printArray<string>(courses);

printArray(courses);