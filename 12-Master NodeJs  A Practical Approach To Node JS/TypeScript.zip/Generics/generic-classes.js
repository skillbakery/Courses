var output;
output = function (arg) {
    return arg;
};
console.log(output(10));
var genericClass = (function () {
    function genericClass() {
    }
    return genericClass;
})();
var obj = new genericClass();
obj.genericProp = "Hello";
obj.genericFn = function (arg) {
    return arg;
};
console.log(obj.genericFn("World"));
