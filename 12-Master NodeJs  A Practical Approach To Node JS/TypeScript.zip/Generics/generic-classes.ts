// TypeScript
interface genericInterfaceII<T> {
    (arg: T): T;
}

var output : genericInterfaceII<number>;

output=function(arg:number){
return arg;
}

console.log(output(10));

class genericClass<T>{
  genericProp : T;
  genericFn:(arg:T) => T;
}

var obj=new genericClass<string>();
obj.genericProp="Hello";
obj.genericFn=function(arg) {
 return arg;
}

console.log(obj.genericFn("World"));