// TypeScript
function echoN(param) {
    return param;
}
//The above function will only allow number to be passed 
//as parameter and the return type of this function will be number
function echo(param) {
    return param;
}
//using "any" datatype we can create a general echo function but 
//we can not determine the return type of the function in this case
function echoGeneric(param) {
    return param;
}
//using generics we can resolve the above issue and 
//can capture the return type of the function for that we make use of Type Variable
var result = echoGeneric("Hello! TypeScript");
var result_another = echoGeneric("Hello! TypeScript");
console.log(result);
console.log(result_another);
//var result_number=echoGeneric<string>(1);
