<?php
require "predis/autoload.php";
try {
	Predis\Autoloader::register();
    $redis = new Predis\Client();

    $redis->del("languages");

    $redis->rpush("languages", "c#"); // [c#]
    $redis->rpush("languages", "PHP"); // [c#, PHP]

    $redis->lpush("languages", "Python"); // [Python, c#, PHP]
    $redis->lpush("languages", "Java"); // [Java, Python, c#, PHP]

    echo $redis->lpop("languages"); // [Python, c#, PHP], prints Java
    echo "<br/>";
    echo $redis->rpop("languages"); // [Python, c#], prints PHP
    echo "<br/>";
    echo $redis->llen("languages"); // 2
    echo "<br/>";
    print_r($redis->lrange("languages", 0, -1)); // returns all elements
    
    print_r($redis->lrange("languages", 0, 1)); // [Python, c#]
}
catch (Exception $e) {
	die($e->getMessage());
}
?>