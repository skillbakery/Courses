<?php
require "predis/autoload.php";
try {
	Predis\Autoloader::register();
    $redis = new Predis\Client();

    $redis->zadd("sorted_set:languages", 1, "PHP");
    $redis->zadd("sorted_set:languages", 2, "C#");
    $redis->zadd("sorted_set:languages", 3, "Java");

    print_r($redis->zcard("sorted_set:languages")); //3
    echo "<br/>";
    print_r($redis->zcount("sorted_set:languages",1,2)); //2
    echo "<br/>";
    print_r($redis->zrange("sorted_set:languages", 0, -1, "withscores"));
    $redis->zrem("sorted_set:languages", "Java");
    echo "<br/>";
    print_r($redis->zrange("sorted_set:languages", 0, -1, "withscores"));
    echo "<br/>";
    print_r($redis->zrank("sorted_set:languages", "C#")); //1 [0 based index]
    echo "<br/>";
    print_r($redis->zrevrank("sorted_set:languages", "C#")); //0 [0 based index]
    echo "<br/>";
    print_r($redis->zscore("sorted_set:languages", "C#")); //2
    echo "<br/>";
    print_r($redis->zrangebyscore("sorted_set:languages", 1,1,array('withscores' => true)));
}
catch (Exception $e) {
	die($e->getMessage());
}
?>