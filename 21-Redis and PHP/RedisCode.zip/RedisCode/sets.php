<?php
require "predis/autoload.php";
try {
	Predis\Autoloader::register();
    $redis = new Predis\Client();

    $key = 'Languages';

    $redis->sadd($key, 'PHP');
    $redis->sadd($key, ['C#', 'Ruby', 'Java']);   
    $redis->sadd($key, 'PHP');

    $redis->srem($key, ['C#', 'Ruby']);
    echo $redis->sismember($key, 'C#'); // false

    print_r($redis->smembers($key));
}
catch (Exception $e) {
	die($e->getMessage());
}
?>