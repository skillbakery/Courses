<?php
require "predis/autoload.php";
try {
	Predis\Autoloader::register();
	$redis = new Predis\Client();
	 //print_r($redis);
	 // This connection is for a remote server
		// $redis = new Predis\Client(array(
		//     "scheme" => "tcp",
		//     "host" => "54.235.207.116",
		//     "port" => 6379
		// ));
		//print_r($redis);0
	 //set or store
	 $redis->set('publisher','SkillBakery');
	 //check
	if($redis->exists('publisher')){
		//retrieve
		$publisher = $redis->get('publisher');
		echo "Publisher is $publisher";
		echo "<br/>";
	}

	$redis->set("counter", 0);

	$redis->incr("counter"); // 1
	$counter = $redis->get('counter');
	echo "Counter is $counter";
	echo "<br/>";
	$redis->incr("counter"); // 2
	$counter = $redis->get('counter');
	echo "Counter is $counter";
	echo "<br/>";
	$redis->decr("counter"); // 1
	$counter = $redis->get('counter');
	echo "Counter is $counter";
	echo "<br/>";

	$redis->incrby("counter", 15); // 16
	$counter = $redis->get('counter');
	echo "Counter is $counter";
	echo "<br/>";
	$redis->incrby("counter", 5);  // 21
	$counter = $redis->get('counter');
	echo "Counter is $counter";
	echo "<br/>";
	$redis->decrby("counter", 10); // 11
	$counter = $redis->get('counter');
	echo "Counter is $counter";
	echo "<br/>";
}
catch (Exception $e) {
	die($e->getMessage());
}
?>