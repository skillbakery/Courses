<?php
require "predis/autoload.php";
try {
	Predis\Autoloader::register();
    $redis = new Predis\Client();

    if (isset($_POST['fName'])) {
        $fName = $_POST['fName'];
        $redis->set('firstname',$fName);
    }

}catch (Exception $e) {
    echo "Couldn't connected to Redis";
    echo $e->getMessage();
}
?>
<!DOCTYPE html>
<html>
<head>
     <title>Working with forms and Redis</title>
</head>
<body>
	<strong>A Simple Form</strong>
	<br />
	<form action="form.php" method="post">
	<input type="text" name="fName" />
	<input type="submit" value="Submit" />
</form>
<?php
	$redis_name = $redis->get('firstname');
    echo  "this is reading from the Redis Database: " . $redis_name;
    ?>
</body>
</html>