<?php
require "predis/autoload.php";
try {
	Predis\Autoloader::register();
    $redis = new Predis\Client();

    $key = 'John Matthew';

    $redis->hset($key, 'age', 35);
    $redis->hset($key, 'country', 'United State of America');   
    $redis->hset($key, 'occupation', 'software engineer');

    $redis->hset($key, 'delete', 'Data will be deleted');
    
    echo $redis->hGet($key, 'age'); // 35
    echo "<br/>";
    echo $redis->hGet($key, 'country'); // United State of America
    echo "<br/>";
    $redis->del($key, 'delete');
    $redis->del($key, 'age');
    
    echo $redis->hIncrBy($key, 'age', 35); // 35
    echo "<br/>";
    echo $redis->hIncrBy($key, 'age', 10); // 45
    echo "<br/>";
    $redis->hmset($key, [
        'age' => 35,
        'country' => 'United State of America',
        'occupation' => 'software engineer',
    ]);

    $data = $redis->hgetall($key);
    print_r($data);
}
catch (Exception $e) {
	die($e->getMessage());
}
?>