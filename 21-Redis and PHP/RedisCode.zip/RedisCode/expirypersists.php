<?php
require "predis/autoload.php";
try {
	Predis\Autoloader::register();
    $redis = new Predis\Client();

    $key = "expire in 1 hour";
    $redis->expire($key, 3600); // expires in 1 hour
    $redis->expireat($key, time() + 3600); // expires in 1 hour

    $redis->ttl($key);

    $redis->persist($key); // this will never expire.

}
catch (Exception $e) {
	die($e->getMessage());
}
?>